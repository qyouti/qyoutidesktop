import socket
import asyncore
import websocket
import json

class WebSocketHandler(websocket.dispatcher):
	clients = []
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
		self.username = None
		self.status = 'online'
	def emit(self, data):
		for client in WebSocketHandler.clients:
			client.snd(data)
	def onmessage(self, data):
		try:
			print data
			data = json.loads(data, encoding='utf-8')
			print data
			{'login': self.request_login,
			 'publicmessage': self.request_publicmessage,
			 'changestatus': self.request_changestatus}[data['request']](data)
		except ValueError:
			self.snd('{"request": "errormessage", "message": "invalid json object"}')
		except KeyError:
			self.snd('{"request": "errormessage", "message": "invalid request"}')
	def onopen(self):
		WebSocketHandler.clients.append(self)
	def onclose(self):
		if self in WebSocketHandler.clients:
			WebSocketHandler.clients.remove(self)
			self.emit('{"request": "logout", "username": "%s"}'%(self.username))
	def request_login(self, data):
		try:
			data['username']
			for client in WebSocketHandler.clients:
				if data['username'] == client.username:
					raise ValueError()
		except KeyError:
			self.snd('{"request": "errormessage", "message": "invalid request: requested username not specified"}')
		except ValueError:
			self.snd('{"request": "errormessage", "message": "invalid request: requested username already in use"}')
		else:
			self.username = data['username']
			self.snd('{"request": "loginok"}')

			# send online users to the recently connected user
			users = []
			for client in WebSocketHandler.clients:
				users.append({'username': client.username, 'status': client.status})
			self.snd('{"request": "refreshuserlist", "users": %s}'%(json.dumps(users)))

			WebSocketHandler.clients.append(self)

			#send everybody the new user
			self.emit('{"request": "login", "username": "%s", "status": "%s"}'%(self.username, self.status))

	def request_publicmessage(self, data):
		try:
			data['message']
			for client in WebSocketHandler.clients:
				client.snd('{"request": "publicmessage", "username": "%s", "message": "%s"}' % (self.username, data['message']))
		except KeyError:
			self.snd('{"request": "errormessage", "message": "invalid request"}')
	def request_changestatus(self, data):
		try:
			data['status']
			for client in WebSocketHandler.clients:
				client.snd('{"request": "changestatus", "username": "%s", "status": "%s"}' % (self.username, data['status']))
		except KeyError:
			self.snd('{"request": "errormessage", "message": "invalid request"}')


class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def handle_accept(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

		
WebSocketServer(('',8001))
asyncore.loop(use_poll=True)

