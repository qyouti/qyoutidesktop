import signal
import socket
import asyncore
import websocket
import signal_dispatcher


class SignalHandler(asyncore.signal_dispatcher):
	counter = 0
	def __init__(self):
		asyncore.signal_dispatcher.__init__(self)
		self.register_signal(signal.SIGALRM, self.signal_sigalrm)
		signal.alarm(1)
	def signal_sigalrm(self, signalnum, frame):
		SignalHandler.counter+=1
		for client in WebSocketHandler.clients:
			client.snd('sending ping...')
			client.ping()
		signal.alarm(1)

class WebSocketHandler(websocket.dispatcher):
	clients = []
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
		WebSocketHandler.clients.append(self)
	def onmessage(self, data):
		print 'onmessage: %s'%(data)
		self.snd('counter: %s' % (SignalHandler.counter))
	def onclose(self):
		WebSocketHandler.clients.remove(self)
		print 'onclose'
	def onpong(self):
		self.snd('pong received')

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

SignalHandler()
WebSocketServer(('',8000))
asyncore.loop(use_poll=True)

