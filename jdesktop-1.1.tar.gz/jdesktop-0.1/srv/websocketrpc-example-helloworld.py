import json
import socket
import asyncore
import websocket

schema = [
	{
		'method': 'signIn',
		'side': 'server',
		'params': [
			{'description': '', 'type': 'string'},
			{'description': '', 'type': 'string'}
		]
	},
	{
		'method': 'signInResult',
		'side': 'client',
		'params': [
			{'description': '', 'type': 'boolean'}
		]
	},
	{
		'method': 'publicmessage',
		'side': 'client',
		'params': [
			{'description': '', 'type': 'boolean'}
		]
	}
]

class WebSocketHandler(websocket.dispatcher):
	def __init__(self, sock=None, schema=None):
		websocket.dispatcher.__init__(self, sock=sock)
		self.schema = schema
	def onmessage(self, data):
		print data
		#print 'onmessage: len:%s'%(len(data))
		#self.snd('reply(%s):%s'%(self.fileno(), len(data)))
		pass
	def onclose(self):
		print 'onclose'
	def onopen(self):
		print 'connection established'
		self.__send(self.schema)
	def __send(self, obj):
		print 'sending schema'
		self.snd(json.dumps(obj))
	def signIn(self, username, password):
		pass

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.schema = schema
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock, schema=self.schema)

		
WebSocketServer(('',8000))
asyncore.loop(use_poll=True)

