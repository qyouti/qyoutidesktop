import signal
import socket
import asyncore
import websocket
import signal_dispatcher


class SignalHandler(asyncore.signal_dispatcher):
	counter = 0
	def __init__(self):
		asyncore.signal_dispatcher.__init__(self)
		self.register_signal(signal.SIGALRM, self.signal_sigalrm)
		signal.alarm(1)
	def signal_sigalrm(self, signalnum, frame):
		for client in WebSocketHandler.clients_to_close:
			client.counter -= 1
			if client.counter>0:
				client.snd(str('%s seconds to close'%(client.counter)))
			else:
				client.close()
		signal.alarm(1)

class WebSocketHandler(websocket.dispatcher):
	clients_to_close = []
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
	def onmessage(self, data):
		if data=='please close me in 10 seconds':
			self.counter = 10
			WebSocketHandler.clients_to_close.append(self)
		elif data=='please ping me':
			self.ping()
			self.snd('ping has been sent to you')
		else:			
			self.snd('reply: %s' % (data))
	def onclose(self):
		if self in WebSocketHandler.clients_to_close:
			WebSocketHandler.clients_to_close.remove(self)
	def onpong(self):
		self.snd('pong received from you')

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

SignalHandler()
WebSocketServer(('',8000))
asyncore.loop(use_poll=True)

