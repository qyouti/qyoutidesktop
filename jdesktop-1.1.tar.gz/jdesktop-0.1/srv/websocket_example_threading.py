import socket
import asyncore
import websocket
import signal_dispatcher
import threading
import time


class thread(threading.Thread):
	def __init__ (self, websocket):
		threading.Thread.__init__(self)
		self.websocket = websocket
	def run(self):
		for i in range(0, 10):
			time.sleep(1)
			self.websocket.snd('Thread message: id=%s counter=%s' % (self.id, i))
		self.websocket.snd('Thread finished: id=%s' % (self.id))

class WebSocketHandler(websocket.dispatcher):
	clients = []
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
		WebSocketHandler.clients.append(self)
	def onmessage(self, data):
		for i in range(0, 100):
			newthread = thread(self)
			newthread.start()
			newthread.id = i
			self.snd('Thread started with id%s'%(i))
	def onclose(self):
		WebSocketHandler.clients.remove(self)

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

WebSocketServer(('',8000))
asyncore.loop(use_poll=True)

