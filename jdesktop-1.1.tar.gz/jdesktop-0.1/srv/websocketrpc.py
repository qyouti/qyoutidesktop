import socket
import asyncore
import websocket

class dispatcher(websocket.dispatcher):
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
	def onmessage(self, data):
		#print 'onmessage: len:%s'%(len(data))
		self.snd('reply(%s):%s'%(self.fileno(), len(data)))
		pass



