import asyncore
import fcntl
import os
import signal

class signal_dispatcher(asyncore.file_dispatcher):
	def __init__(self):
		self.read, self.write = os.pipe()
		flags = fcntl.fcntl(self.write, fcntl.F_GETFL, 0)
		flags = flags | os.O_NONBLOCK
		fcntl.fcntl(self.write, fcntl.F_SETFL, flags)
		old_wakeup = signal.set_wakeup_fd(self.write)
		asyncore.file_dispatcher.__init__(self, self.read)

		self.__handlers = {}
	def writable(self):
		return False
	def readable(self):
		return True
	def handle_read(self):
		self.recv(1)
		signalnum = ord(self.recv(1))
		if self.__handlers.has_key(signalnum):
			self.__handlers[signalnum](signalnum, False)
	def register_signal(self, signalnum, handler):
		self.__handlers[signalnum] = handler
		signal.signal(signalnum, self.__signal)
	def __signal(self, signalnum, frame):
		os.write(self.write, chr(signalnum))

asyncore.signal_dispatcher = signal_dispatcher

