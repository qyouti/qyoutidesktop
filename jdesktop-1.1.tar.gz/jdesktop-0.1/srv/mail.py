import socket
import asyncore
import websocket
import json
import mailbox
import email
import datetime
import time

class WebSocketHandler(websocket.dispatcher):
	clients = []
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
		self.username = None
	def emit(self, data):
		for client in WebSocketHandler.clients:
			client.snd(data)
	def onmessage(self, data):
		try:
			data = json.loads(data, encoding='utf-8')
			print data
			getattr(self, data['method'])(*data['arguments'])
		except ValueError:
			self.snd('{"request": "errormessage", "message": "invalid json object"}')
		except KeyError:
			self.snd('{"request": "errormessage", "message": "invalid request"}')
	def onopen(self):
		WebSocketHandler.clients.append(self)
	def onclose(self):
		if self in WebSocketHandler.clients:
			WebSocketHandler.clients.remove(self)
	def request_login(self, username, password):
		try:
			pass
		except Exception:
			self.response_login(False)
		else:
			self.response_login(True)
	def response_login(self, p1):
		data = {}
		data['method'] = 'response_login'
		data['arguments'] = [p1]
		self.snd(json.dumps(data))
	def request_getmessagelist(self):
		try:
			messagelist = []
			mbox = mailbox.mbox('/var/spool/mail/jde')
			print mbox.keys()
			for mail in mbox:
				message = {}
				message['From'] = mail['From']
				message['To'] = mail['To']
				message['Date'] = datetime.datetime.fromtimestamp(time.mktime(email.utils.parsedate(mail['Date']))).isoformat()
				message['Subject'] = mail['Subject']
				messagelist.append(message)
		except Exception:
			self.response_getmessagelist([])
		else:
			self.response_getmessagelist(messagelist)
	def response_getmessagelist(self, p1):
		data = {}
		data['method'] = 'response_getmessagelist'
		data['arguments'] = [p1]
		self.snd(json.dumps(data))

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def handle_accept(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

		
WebSocketServer(('',8002))
asyncore.loop(use_poll=True)

