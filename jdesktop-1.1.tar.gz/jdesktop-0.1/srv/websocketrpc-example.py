import socket
import asyncore
import websocketrpc



class WebSocketRPCHandler(websocketrpc.dispatcher):
	def __init__(self, sock=None):
		websocketrpc.dispatcher.__init__(self, sock=sock)
	def onclose(self):
		print 'onclose'

class WebSocketRPCServer(websocketrpc.dispatcher):
	def __init__(self, addr):
		websocketrpc.dispatcher.__init__(self)
		self.schema = schema
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

		
WebSocketRPCServer(('',8000))
asyncore.loop(use_poll=True)

