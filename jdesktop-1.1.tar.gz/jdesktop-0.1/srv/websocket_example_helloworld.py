import socket
import asyncore
import websocket

class WebSocketHandler(websocket.dispatcher):
	def __init__(self, sock=None):
		websocket.dispatcher.__init__(self, sock=sock)
	def onmessage(self, data):
		self.snd('reply(%s):%s'%(self.fileno(), len(data)))
		pass
	def onopen(self):
		print 'onopen'
	def onclose(self):
		print 'onclose'

class WebSocketServer(websocket.dispatcher):
	def __init__(self, addr):
		websocket.dispatcher.__init__(self)
		self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
		self.set_reuse_addr()
		self.bind(addr)
		self.listen(5)
	def onconnect(self):
		sock, addr = self.accept()
		print 'new connection from %s' % repr(addr)
		WebSocketHandler(sock=sock)

		
WebSocketServer(('',8000))
asyncore.loop(use_poll=True)

