new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		/* example not yet implemented */

		var table = this.appendChild( new DataTable({
			'rows': 30,
			'cells': 5,
			'type': 'application',
			'contenteditable': 'true',
			'style': 'position: absolute; top: 10px; left: 10px; right: 300px; bottom: 10px;'
		}) );
		
		table.range(0, 0, 0, 4).type = 'string';
		
		table.cells[0][0].value = 'Date';
		
		for (var i=1; i<30; i++) {
			table.cells[i][0].value = new Date(2010, 0, i).format('fullDate');
		}
				
		table.range(1, 1, 29, 1).onchange = function() {
			table.cells[0][1].value = 'Sum: '+table.range(1, 1, 29, 1).sum();
		}

		table.range(1, 2, 29, 2).onchange = function() {
			table.cells[0][2].value = 'Average: '+table.range(1, 2, 29, 2).avg();
		}

		table.range(1, 3, 29, 3).onchange = function() {
			table.cells[0][3].value = 'Maximum: '+table.range(1, 3, 29, 3).max();
		}
		
		table.range(1, 4, 29, 4).onchange = function() {
			table.cells[0][4].value = 'Minimum: '+table.range(1, 4, 29, 4).min();
		}

		table.range(1, 1, 29, 4).format = '0.#';		
		table.range(1, 1, 29, 4).type = 'number';
		table.range(1, 1, 29, 4).value = '0';
		
		var controls = this.appendChild( new Fieldset({
			'style': 'position: absolute; top: 10px; right: 10px; width: 280px; bottom: 10px;',
			'legend': 'Controls'
		}) );

		controls.appendChild( new Checkbox({
			'label': 'Fixed Header',
			'checked': table.fixedheader,
			'onchange': function(event) {
				table.fixedheader = event.target.checked;
			}
		}) );

		controls.appendChild( new Checkbox({
			'label': 'Resizeable',
			'checked': table.resizeable,
			'onchange': function(event) {
				table.resizeable = event.target.checked;
			}
		}) );

		controls.appendChild( new Checkbox({
			'label': 'Contenteditable',
			'checked': table.contenteditable,
			'onchange': function(event) {
				if (event.target.checked) {
					table.range(1, 0, 29, 4).editable =  true;
				} else {
					table.range(1, 0, 29, 4).editable =  false;
				}
			}
		}) );

		controls.appendChild( new Checkbox({
			'label': 'Selectable',
			'checked': table.selectable,
			'onchange': function(event) {
				table.selectable = event.target.checked;
			}
		}) );

/*		controls.appendChild( new Checkbox({
			'label': 'Sortable (NYI)',
			'checked': table.selectable,
			'onchange': function(event) {
				table.sortable = event.target.checked;
			}
		}) );
*/

	}
}))();
