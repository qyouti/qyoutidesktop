new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		this.imageOffsetX = 0;
		this.imageOffsetY = 0;

		this.imageview = this.appendChild( new ImageView({
			'style': 'float: left; margin-right: 1.5em;',
			'width': '640',
			'height': '480'
		}) );

		this.fieldset = this.appendChild( new Fieldset({
			'legend': 'Image URL'
		}) );

		this.image_url = this.fieldset.appendChild( new Textbox({'text': 'img/example-controls-canvas/dsc03435.jpg', 'style': 'width: 100%;margin-bottom: 0.5em;'}) );
		this.fieldset.appendChild( new Div() );
		this.fieldset.appendChild( new Button({'text': 'Load Image from URL', 'icon': 'view-refresh', 'onclick': this.loadimage.bind(this)}) );
		this.fieldset.appendChild( new Button({'text': 'Load Image from local drive', 'icon': 'view-refresh', 'onclick': this.loadimage.bind(this)}) );

		this.fieldset_controls = this.appendChild( new Fieldset({
			'legend': 'Apply Effect'
		}) );

		this.fieldset_controls.appendChild( new Button({'text': 'greyscale', 'onclick': this.applyeffect.bind(this, 'greyscale')}) );
		this.fieldset_controls.appendChild( new Button({'text': 'invert', 'onclick': this.applyeffect.bind(this, 'invert')}) );
		this.fieldset_controls.appendChild( new Button({'text': 'sepia', 'onclick': this.applyeffect.bind(this, 'sepia')}) );
		this.fieldset_controls.appendChild( new Button({'text': 'lighten', 'onclick': this.applyeffect.bind(this, 'lighten')}) );


		this.loadimage();
	},
	applyeffect: function(event, effect) {
		this.imageview['effects_'+effect]();
	},
	loadimage: function() {
		this.imageview.loadImage(this.image_url.text);
	}
}))();


