new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		var controls = this.appendChild( new Fieldset({'legend': 'Controls'}) );
		controls.appendChild( new Button({'text': 'Open Websocket', 'onclick': this.test_open.bind(this)}) );
		controls.appendChild( new Button({'text': 'Send 1KByte', 'onclick': this.test_send1k.bind(this)}) );
		controls.appendChild( new Button({'text': 'Send 10kByte', 'onclick': this.test_send10k.bind(this)}) );
		controls.appendChild( new Button({'text': 'Send 100kByte', 'onclick': this.test_send100k.bind(this)}) );
		controls.appendChild( new Button({'text': 'Ping test', 'onclick': this.test_ping.bind(this)}) );
		controls.appendChild( new Button({'text': 'Close Websocket', 'onclick': this.test_close.bind(this)}) );

		this.address = this.appendChild( new Textbox({
			'text': 'ws://$:8000'.$(top.location.host),
			'style': 'width: 100%; margin-top: 10px'
		}) );

		this.logs = this.appendChild( new Div({
			'style': 'overflow: auto; border: solid lightgrey 1px; height: 300px; margin-top: 10px;'
		}) );

		/* a div for reference element */
		this.logs.appendChild( new Div() );

	},
	log: function(msg) {
		var div = new Div({
			'text': '$: $'.$(new Date().format('hh:mm:ss'), msg),
			'style': 'color: green;'
		});

		this.logs.insertBefore(div, this.logs.firstChild);

		div.style.transition = 'all 1s linear';
		div.style.WebkitTransition = 'all 1s linear';

		Timer.setTimeout(function() {
			div.style.color = 'black';
		}, 50);
	},
	websocket_onopen: function() {
		this.log('websocket.onopen');
		this.log('websocket.readyState=$'.$(this.websocket.readyState));
	},
	websocket_onmessage: function(data) {
		this.log('websocket.onmessage(data)');
		this.log('websocket.readyState=$'.$(this.websocket.readyState));
		this.log('data.data.length=$'.$(data.data.length));
	},
	websocket_onerror: function() {
		this.log('websocket.error');
		this.log('websocket.readyState=$'.$(this.websocket.readyState));
	},
	websocket_onclose: function() {
		this.log('websocket.onclose');
		this.log('websocket.readyState=$'.$(this.websocket.readyState));
	},
	test_open: function() {
		this.log('Connecting to websocket server at $'.$(this.address.text));
		this.websocket = new WebSocket(this.address.text);
		this.websocket.onopen = this.websocket_onopen.bind(this);
		this.websocket.onclose = this.websocket_onclose.bind(this);
		this.websocket.onerror = this.websocket_onerror.bind(this);
		this.websocket.onmessage = this.websocket_onmessage.bind(this);
		this.log('websocket.readyState=$'.$(this.websocket.readyState));
	},
	test_send1k: function() {
		this.websocket.send( new Array(1024+1).join('a') );
	},
	test_send10k: function() {
		this.websocket.send( new Array(1024*10+1).join('a') );
	},
	test_send100k: function() {
		this.websocket.send( new Array(1024*100+1).join('a') );
	},
	test_ping: function() {
		/* ask the server to ping us */
		this.websocket.send('pingtest');
	},
	test_close: function() {
		this.websocket.close();
	}
}))();

