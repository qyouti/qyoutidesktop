new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		var fm = this.appendChild( new FileMenu() );

		var filemenu = fm.appendChild( new FileMenu.Item({'text': 'File'}) );
		var editmenu = fm.appendChild( new FileMenu.Item({'text': 'Edit'}) );
		var helpmenu = fm.appendChild( new FileMenu.Item({'text': 'Help'}) );

		filemenu = filemenu.appendChild( new DropdownMenu() );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-new', 'text': 'New', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-open', 'text': 'Open...', 'shortcut': 'Ctrl+O', 'onclick': this.document_open.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'download', 'text': 'Download', 'title': 'Download application for offline usage', 'shortcut': 'Ctrl+D', 'onclick': this.download.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'application-exit', 'text': 'Quit', 'title': 'Quit the application', 'shortcut': 'Ctrl+Q', 'onclick': this.close.bind(this)}) );

		editmenu = editmenu.appendChild( new DropdownMenu() );
		var preferences = editmenu.appendChild( new DropdownMenu.Item({'icon': 'preferences-activities', 'text': 'Preferences'}) );

		helpmenu = helpmenu.appendChild( new DropdownMenu() );
		helpmenu.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		preferences = preferences.appendChild( new DropdownMenu() );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		var im = this.appendChild( new IconMenu() );
		im.appendChild( new Button({'type': 'flat', 'icon': 'document-new', 'onclick': this.document_new.bind(this)}) );
		im.appendChild( new Button({'type': 'flat', 'text': 'Open', 'icon': 'document-open'}) );
		im.appendChild( new Button({'type': 'flat', 'text': 'Save', 'icon': 'document-save'}) );

		var tab = this.appendChild( new Tab({'style': 'height: 100%'}) );

		var item = tab.appendChild( new Tab.Item({
			'caption': 'Empty Tab',
			'text': 'This is the content of your first tab'
		}) );

		/* inptus */
		var item = tab.appendChild( new Tab.Item({
			'caption': 'Inputs'
		}) );

		item.appendChild( new Fieldset({'legend': 'Textbox'}) ).appendChild( new Textbox() );
		item.appendChild( new Fieldset({'legend': 'Password'}) ).appendChild( new Password() );
		item.appendChild( new Fieldset({'legend': 'NumberPicker'}) ).appendChild( new NumberPicker({'value': 10}) );
		item.appendChild( new Fieldset({'legend': 'Checkbox'}) ).appendChild( new Checkbox() );

		/* Progress */
		var item = tab.appendChild( new Tab.Item({
			'caption': 'Progress'
		}) );

		var progressbar = item.appendChild( new Fieldset({'legend': 'Progress'}) ).appendChild( new Progressbar() );
		Timer.setInterval(function(progressbar) {
			if (progressbar.value == 100) {
				progressbar.value = 0;
			}
			progressbar.value+=1;
		}.bind(this, progressbar), 100);

		/* Dialogs */
		var item = tab.appendChild( new Tab.Item({
			'caption': 'Dialogs',
			'closable': true
		}) );

		item.appendChild( new Fieldset({'legend': 'Dialog'}) ).appendChild( new Button({
			'text': 'Show dialog',
			'onclick': function(event) {
				var dialog = new Dialog({
					'caption': 'Example Dialog',
					'text': 'this is the content of your dialog',
					'buttons': 'Ok Cancel',
					'onchange': function(event, button) {
						dialog.close();
					}
				});
				dialog.show();
			}.bind(this)
		}) );

		var fieldset = item.appendChild( new Fieldset({'legend': 'Dialog'}) );

		fieldset.appendChild( new Button({
			'text': 'Information Dialog',
			'onclick': function(event) {
				new Dialog.information({
					'caption': 'Information Dialog',
					'text': 'This is an information in general!'
				}).show();
			}.bind(this)
		}) );

		fieldset.appendChild( new Button({
			'text': 'Warning Dialog',
			'onclick': function(event) {
				new Dialog.warning({
					'caption': 'Warning Dialog',
					'text': 'This is a warning message!'
				}).show();
			}.bind(this)
		}) );

		fieldset.appendChild( new Button({
			'text': 'Error Dialog',
			'onclick': function(event) {
				new Dialog.error({
					'caption': 'Error Dialog',
					'text': 'This is an error message!'
				}).show();
			}.bind(this)
		}) );

		fieldset.appendChild( new Button({
			'text': 'Dialog Loader',
			'onclick': function(event) {
				var dialog = new Dialog.loader({
					'caption': 'Processing...',
					'text': 'Please wait while your request is being processed...',
					'onchange': function(event) {
						dialog.close();
					}
				}).show();
			}.bind(this)
		}) );

		fieldset.appendChild( new Button({
			'text': 'Dialog FileBrowser',
			'onclick': function(event) {
				var dialog = new Dialog.fileBrowser({
					'caption': 'Select a file',
					'onchange': function(event) {
						dialog.close();
					}
				}).show();
			}.bind(this)
		}) );


		item.appendChild( new Fieldset({'legend': 'Dialog'}) ).appendChild( new Button({
			'text': 'Password',
			'onclick': function(event) {
				var dialog = new Dialog.password({
					'onchange': function(event, which) {
						/* send authentication information to server */
						/* dialog.password;                          */
						/* dialog.username;                          */
						dialog.close();
					}.bind(dialog)
				}).show();
			}.bind(this)
		}) );

		/* Views */
		var item = tab.appendChild( new Tab.Item({
			'caption': 'TreeView'
		}) );

		var tw = item.appendChild( new TreeView() );

		var subdir = new TreeView.RootItem({'text': 'msdos', 'icon': 'places folder'});
		subdir.appendChild( new TreeView.ListItem({'text': 'msdos.com', 'icon': 'mimetypes application-x-executable'}) );
		subdir.appendChild( new TreeView.ListItem({'text': 'chkdsk.exe', 'icon': 'mimetypes application-x-executable'}) );

		var subdir3 = new TreeView.RootItem({'text': 'system', 'icon': 'places folder-important'});
		subdir3.appendChild( new TreeView.ListItem({'text': 'rundll.dll', 'icon': 'mimetypes application-x-executable'}) );
		subdir3.appendChild( new TreeView.ListItem({'text': 'system.dll', 'icon': 'mimetypes application-x-executable'}) );
		subdir3.appendChild( new TreeView.ListItem({'text': 'config.txt', 'icon': 'mimetypes text-plain'}) );

		var subdir2 = new TreeView.RootItem({'text': 'windows', 'icon': 'places folder'});
		subdir2.appendChild( subdir3 );
		subdir2.appendChild( new TreeView.ListItem({'text': 'win.com', 'icon': 'mimetypes application-x-executable'}) );
		subdir2.appendChild( new TreeView.ListItem({'text': 'calculator.exe', 'icon': 'mimetypes application-x-executable'}) );
		subdir2.appendChild( new TreeView.ListItem({'text': 'explorer.exe', 'icon': 'mimetypes application-x-executable'}) );

		var root = tw.appendChild( new TreeView.RootItem({'text': 'root', 'icon': 'places folder-red'}) );
		root.appendChild( subdir );
		root.appendChild( subdir2 );
		root.appendChild( new TreeView.ListItem({'text': 'autoexec.bat', 'icon': 'mimetypes application-x-executable-script'}) );
		root.appendChild( new TreeView.ListItem({'text': 'config.sys', 'icon': 'mimetypes text-plain'}) );
		root.appendChild( new TreeView.ListItem({'text': 'image.bmp', 'icon': 'mimetypes image-x-generic'}) );

	},
	download: function(event) {
	},
	document_new: function(event) {
		new this.constructor();
	},
	document_open: function(event) {
	}
}))();
