new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		this.textbox = this.appendChild( new Textbox({
			'text': ''
		}) );

		this.appendChild( new Div({'style': 'margin-top: 5px;'}) );

		this.password = this.appendChild( new Password({
			'text': ''
		}) );

		this.appendChild( new Div({'style': 'margin-top: 5px;'}) );

		this.numberpicker = this.appendChild( new NumberPicker({
			'value': 10,
			'onchange': this.numberpicker_onchange.bind(this)
		}) );

		this.appendChild( new Div({'style': 'margin-top: 5px;'}) );

		this.checkbox = this.appendChild( new Checkbox({
			'checked': false,
			'onchange': this.checkbox_onchange.bind(this)
		}) );

		this.appendChild( new Div({'style': 'margin-top: 5px;'}) );

		this.select = this.appendChild( new Select({
			'onchange': this.select_onchange.bind(this)
		}) );

		this.select.appendChild( new Option({
			'text': 'Option #1'
		}) );

		this.select.appendChild( new Option({
			'text': 'Option #2'
		}) );

		this.select.appendChild( new Option({
			'text': 'Option #3'
		}) );
	},
	numberpicker_onchange: function() {
		this.textbox.text = this.numberpicker.value;
	},
	checkbox_onchange: function() {
		this.textbox.disabled = this.checkbox.checked;
	},
	select_onchange: function() {
		this.textbox.text = this.select.childNodes[this.select.selectedIndex].text;
	}
}))();
