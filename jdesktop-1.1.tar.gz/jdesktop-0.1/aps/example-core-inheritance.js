/* LESSON 4: inheritance, method override            */
/* DOM elements can easily be extended, check bellow */

var MyDiv = Div.extend({
	init: function(p) {
		/* call base constructor */
		Div.prototype.init.call(this, p);

		/* give some style to me */
		this.style.width = '50px';
		this.style.height = '50px';
		this.style.float = 'left';
		this.style.marginRight = '8px';

		/* if we would have called                                                    */
		/* Div.prototype.init.call(this, {                                            */
		/*	'style': 'width: 50px; height: 50px; float: left; margin-right: 8px;' */
		/* });                                                                        */
		/* we would have done the same thing                                          */
	},
	click_handler: function(event) {
		this.color = 'red';
	},
	color: {
		set: function(value) {
			this.style.backgroundColor = value;
		}
	}
});

var MyMyDiv = MyDiv.extend({
	init: function(p) {
		/* never forget to call base constructor */
		MyDiv.prototype.init.call(this, p);
	},
	/* here we override the base onclick handler */
	click_handler: function(event) {
		this.color = 'blue';
		/* if we happen to need the base onclick handler */
		/* just call:                                    */
		/* MyDiv.prototype.onclick.call(this, event);    */
	}
});

new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		/* new we append our two new nodes */

		/* this one will turn into red when you click on it */
		var mydiv = this.appendChild( new MyDiv({
			'color': 'green',
			'text': 'Click ME'
		}) );

		/* this one will turn into blue when you click on it                */
		/* because we redifined the onclick handler in MyMyDiv's definition */
		var mymydiv = this.appendChild( new MyMyDiv({
			/* in MyDiv class we defined a 'color' propery      */
			/* MyMyDiv inherited it                             */
			/* so you can set it if you pass it to the instance */
			'color': 'green',
			'text': 'Click ME'
		}) );


		/* of course color property can be set this way too */
		/* mymydiv.color = 'green'; */
	}
}))();
