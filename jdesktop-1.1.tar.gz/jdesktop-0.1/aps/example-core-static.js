/* LESSON 5: static constructor, variables, methods and properties */

var Person = Div.extend({
	static: {
		init: function() {
			/* this is our static constructor                               */
			/* static constructor gets called when your class is being made */
			/* 'this' keyword refers to Person class                        */
		},
		end_of_work: function() {
			while (Person.persons.length) {
				Person.persons[0].gohome();
			}
		},
		/* static properties can be accessed like non static properties */
		/* alert(Person.population);                                    */
		population: {
			get: function() {
				return(this.persons.length);
			}
		},
		/* static variables can be accessed: Person.variable */
		persons: []
	},
	init: function(content) {
		this.content = content;
		Div.prototype.init.call(this);

		/* jDesktop follows the freedesktop icon naming standard                          */
		/* http://standards.freedesktop.org/icon-naming-spec/icon-naming-spec-latest.html */
		/* check our css file either: http://jdesktop.com/css/icons.css                   */
		this.addClassName('icon');
		this.setAttribute('context', 'actions');
		this.setAttribute('size', '48');
		this.setAttribute('name', 'im-user');

		this.style.float = 'left';
		this.style.display = 'inline-block';
		this.style.marginRight = '8px';
		this.style.marginTop = '8px';

		Person.persons.push(this);
		this.content.world.appendChild(this);
		this.content.fieldset.text = 'In office: $\n'.$(Person.population);
	},
	gohome: function() {
		this.content.world.removeChild(this);
		Person.persons.remove(this);
		this.content.fieldset.text = 'In office: $\n'.$(Person.population);
	},
	click_handler: function(event) {
		this.gohome();
	}
});

new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		/* let's create the layout */
		this.content = this.appendChild( new Div({
			'style': 'position: absolute; top: 0px; left: 0px; right: 0px; bottom: 2em; overflow: auto;'
		}) );

		this.buttons = this.appendChild( new Div({
			'style': 'position: absolute; left: 0px; right: 0px; bottom: 0px; height: 1.75em;'
		}) );

		this.content.world = this.content.appendChild( new Div({
			'style': 'position: absolute; top: 0px; left: 0px; bottom: 0px; right: 200px;'
		}) );

		this.content.fieldset = this.content.appendChild( new Fieldset({
			/* fieldset class has a legend property */
			'legend': 'Information',
			'text': 'Click person to remove',
			'style': 'position: absolute; top: 0px; right: 0px; bottom: 0px; width: 200px;'
		}) );

		this.buttons.appendChild( new Button({
			style: 'float: right',
			icon: 'application-exit',
			text: 'Close',
			onclick: this.close.bind(this)
		}) );

		this.buttons.appendChild( new Button({
			style: 'float: right',
			icon: 'im-user',
			text: 'New Person',
			onclick: this.addperson.bind(this)
		}) );

		this.buttons.appendChild( new Button({
			style: 'float: right',
			icon: 'im-kick-user',
			text: 'end of work',
			onclick: Person.end_of_work
		}) );


	},
	addperson: function() {
		new Person(this.content);
	}
}))();
