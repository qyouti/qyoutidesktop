new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		this.progressbar = this.appendChild( new Progressbar() )
		this.appendChild( new Button({
			'text': 'Start',
			'style': 'position: absolute; right: 0px; bottom: 0px;',
			'onclick': this.timeout.bind(this)
		}) );
	},
	timeout: function() {
		if (this.progressbar.value!=100) {
			this.progressbar.value = ++this.progressbar.value;
			Timer.setTimeout(this.timeout.bind(this), 25);
		}
	}
}))();
