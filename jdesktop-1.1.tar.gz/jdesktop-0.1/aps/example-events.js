new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		this.handlers = {};
		this.fieldset = this.appendChild( new Fieldset({'legend': 'Events'}) );
		this.fieldset2 = this.appendChild( new Fieldset({'legend': 'Event Properties'}) );
		this.events.forEach(function(event) {
			var div = this.fieldset.appendChild( new Div() );
			var checkbox = div.appendChild( new Checkbox({'id': event}) );
			checkbox.addEventListener('change', this.checkbox_change.bind(this, checkbox, event), false);
			div.appendChild( new Label({'for': event, 'text': event}) );
		}, this);
		this.appendChild( new Button({
			'text': 'Close',
			'style': 'position: absolute; right: 0px; bottom: 0px;',
			'onclick': this.close.bind(this)
		}) );
	},
	checkbox_change: function(event, checkbox, event) {
		if (checkbox.checked) {
			this.handlers[event] = this.handler.bind(this);
			this.addEventListener(event, this.handlers[event], false);
		} else {			
			this.removeEventListener(event, this.handlers[event]);
		}
	},
	handler: function(event) {
		while (this.fieldset2.hasChildNodes())
			this.fieldset2.removeChild(this.fieldset2.firstChild);
		for (key in event) {
			this.fieldset2.appendChild( new Div({'text': 'event.$: $'.$(key, event[key])}) );
		}
	},
	events: [
		'mousedown',
		'mouseup',
		'mousemove',
		'mousewheel',
		'keydown',
		'keyup',
		'keypress'
	]
}))();
