new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		var btn1 = this.appendChild( new Button({
			'icon': 'dialog-ok',
			'text': 'Press Me',
			'onclick': function() {
				btn1.icon = 'dialog-cancel';
			}
		}) );

		this.appendChild( new Div() );

		var btn2 = this.appendChild( new Button.RefreshButton({
			'text': 'Refresh view',
			'onclick': function() {
				btn2.loading = !btn2.loading;
				btn2.text = btn2.loading?'Cancel request':'Refresh view';
			}
		}) );

		this.appendChild( new Div() );

		var btn3 = this.appendChild( new Button.DatePicker({
			'text': 'Select date',
			'onchange': function() {
				btn3.text = 'Selected date: ' + btn3.selectedDate.format('yyyy-mm-dd');
			}
		}) );

	}
}))();
