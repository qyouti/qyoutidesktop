var Land = Canvas.extend({
	init: function(p) {
		var p=p?p:{};
		p.width = '800';
		p.height = '600';
		Canvas.prototype.init.call(this, p);
		this.ctx = this.getContext('2d');
	},
	render: function() {
		this.ctx.clearRect(0, 0, 800, 600);

		this.ctx.fillStyle = 'black';
		Cell.Cells.forEach(function(cell) {
			this.ctx.fillRect(cell.x, cell.y, 1, 1);
		},this);

		this.ctx.fillStyle = 'green';
		Nutritient.Nutritients.forEach(function(nutritient) {
			this.ctx.fillRect(nutritient.x, nutritient.y, 1, 1);
		},this);

	}
});


var Nutritient = Class.extend({
	static: {
		Nutritients: []
	},
	init: function() {
		this.x = parseInt(Math.random()*800);
		this.y = parseInt(Math.random()*600);
		Nutritient.Nutritients.push(this);
	},
	x: 0,
	y: 0
})


var Cell = Class.extend({
	static: {
		Cells: []
	},
	init: function() {
		Cell.Cells.push(this);
		this.tick();
	},
	divide: function() {
		var cell = new Cell();
		cell.x = this.x+1*(-1*Math.round(Math.random()));
		cell.y = this.y+1*(-1*Math.round(Math.random()));
	},
	tick: function() {
		this.age++;
		if (this.age == 10) {
			this.divide();
		}
		Timer.setTimeout(arguments.callee.bind(this), 100);
	},
	age: 0,
	x: 0,
	y: 0,
	/* */
	slots_nutritient: function() {
	}
});


new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);
		var land = this.appendChild( new Land({'style': 'float: left;'}) );
		var cell = new Cell();
		cell.x=400;
		cell.y = 300;

		for (var i=0; i<500; i++) {
			new Nutritient();
		}
		
		Timer.setInterval(function() {
			land.render();
		}, 100);

		Timer.setInterval(function() {
			this.text = 'Number of cells: ' + Cell.Cells.length;
		}.bind(this.appendChild( new Div({'text': 'Number of cells:'}) )), 100);
	}
}))();


