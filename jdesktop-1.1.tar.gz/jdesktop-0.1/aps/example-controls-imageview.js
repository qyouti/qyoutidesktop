new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		this.resizeTo(650, 600);
		
		var fieldset = this.appendChild( new Fieldset({'style': 'width: 640px; clear:right; margin-bottom: 5px;', 'legend': 'Controls'}) );

		this.imageview = this.appendChild( new ImageView({
			'width': '640', 'height': '480', 'style': 'float: left;'
		}) );
		this.imageview.loadImage('img/example-controls-canvas/match.jpg');

		fieldset.appendChild( new Button({'text': 'GreyScale', 'onclick': this.imageview.effects_greyscale.bind(this.imageview)}) );
		fieldset.appendChild( new Button({'text': 'Inver', 'onclick': this.imageview.effects_invert.bind(this.imageview)}) );
		fieldset.appendChild( new Button({'text': 'Sepia', 'onclick': this.imageview.effects_sepia.bind(this.imageview)}) );
		fieldset.appendChild( new Button({'text': 'Lighten', 'onclick': this.imageview.effects_lighten.bind(this.imageview)}) );
		var btn = fieldset.appendChild( new Button.RefreshButton({'text': 'Reload image', 'onclick': function(event) {
			this.imageview.loadImage('img/example-controls-canvas/match.jpg');
		}.bind(this) }) );
	}
}))();
