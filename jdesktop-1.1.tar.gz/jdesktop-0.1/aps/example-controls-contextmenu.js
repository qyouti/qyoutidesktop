new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		this.appendChild( new Div({'style': 'margin-top: 0.5em;'}) );

		this.chart = this.appendChild( new Chart({
			'style': 'float: left',
			'width': '600',
			'height': '500',
			/* Dyncamic context menu: a function returning the items of the contextmenu */
			'contextmenu': function() { return([
				{'icon': this.series.type=='line'?'dialog-ok-apply':'', 'text': 'Line Chart', 'onclick': this.changetype.bind(this, 'line')},
				{'icon': this.series.type=='area'?'dialog-ok-apply':'', 'text': 'Area Chart', 'onclick': this.changetype.bind(this, 'area')},
				{'icon': this.series.type=='bar'?'dialog-ok-apply':'', 'text': 'Bar Chart', 'onclick': this.changetype.bind(this, 'bar')},
				{'icon': this.series.type=='pie'?'dialog-ok-apply':'', 'text': 'Pie Chart', 'onclick': this.changetype.bind(this, 'pie')}
			]) }.bind(this)
		}) );

		this.chart.label.text = 'Right click on the chart';
		this.chart.legend.values = ['Powerplant #1'];
		this.chart.xaxis.values = ['2008', '2009', '2010', '2011', '2012', '2013'];
		this.chart.xaxis.label = 'Month';
		this.chart.xaxis.angel = -45;
		this.chart.yaxis.maximum = 100;
		this.chart.yaxis.steps = 11;
		this.chart.yaxis.format = '0';
		this.chart.yaxis.label = 'Production [MW]';
		this.chart.draw();

		this.series = this.chart.appendChild( new Chart.Series({
			'values': [10, 50, 60, 70, 69, 65]
		}) );

		this.chart.draw();

		this.button = this.appendChild( new Button({
			'text': 'Randomize values',
			'icon': 'view-refresh',
			/* Static context menu */
			'contextmenu': [
				{'text': 'item1', 'icon': 'dialog-ok', 'onclick': function() {}.bind(this)},
				{'text': 'item2', 'icon': 'dialog-ok-apply', 'onclick': function() {}.bind(this)}
			],
			'onclick': function() {
				this.series.values = this.series.values.map(function(e) {
					return(Math.random()*100);
				});
				this.chart.draw();
			}.bind(this)
		}) );
	},
	changetype: function(event, type) {
		if (type=='pie')
			this.chart.legend.values = this.chart.xaxis.values;
		else
			this.chart.legend.values = ['Company #1'];
		this.series.type = type;
		this.chart.draw();
	}
}))();
