new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		/* not yet implemented */
		
	}
}))();
