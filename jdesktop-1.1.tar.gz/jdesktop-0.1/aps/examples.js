new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		this.setAttribute('id', 'examples');
		CSS.load('css/examples.css');

		var fm = this.appendChild( new FileMenu() );

		var filemenu = fm.appendChild( new FileMenu.Item({'text': 'File'}) );
		var helpmenu = fm.appendChild( new FileMenu.Item({'text': 'Help'}) );

		filemenu = filemenu.appendChild( new DropdownMenu() );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'application-exit', 'text': 'Quit', 'title': 'Quit the application', 'shortcut': 'Ctrl+Q', 'onclick': this.close.bind(this)}) );

		helpmenu = helpmenu.appendChild( new DropdownMenu() );
		helpmenu.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.about.bind(this)}) );

		var table = this.appendChild( new Div({'class': 'table', 'style': 'height: 100%;'}) );
		var row = table.appendChild( new Div() );


		var lmenu = row.appendChild( new Div({'class': 'mymenu'}) );
		row.appendChild( new Div({'class': 'myresizer'}) );
		row.appendChild( new Div({'class': 'mycontent'}) );

		var accordion = lmenu.appendChild( new Accordion() );

		var core = accordion.appendChild( new Accordion.Item({'caption': 'Core'}) );
		var buttons = accordion.appendChild( new Accordion.Item({'caption': 'Buttons'}) );

	},
	about: function() {
		var dialog = new Dialog.information({
			'style': 'width: 500px;',
			'caption': 'About examples',
			'html': '<center><font style="font-weight: bold; font-size: x-large;">jDesktop</font><br>examples.js is a small web application that collect the available examples based on jDesktop JavaScript library<br><br>Copyright c 2011 Guttmann Krisztián<br><br><a target="_blank" href="http://www.jdesktop.com">http://www.jdesktop.com</a></center>'
		});
		dialog.show();
	}
}))();
