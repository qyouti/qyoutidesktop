new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		this.tab = this.appendChild( new Tab({
			'style': 'height: 100%;'
		}) );

		var tabitem1 = this.tab.appendChild( new Tab.Item({'caption': 'tabitem.text', 'text': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'}) );

		var tabitem2 = this.tab.appendChild( new Tab.Item({'caption': 'tabitem.html', 'html': '<b>Lorem ipsum</b><br><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'}) );

		var tabitem3 = this.tab.appendChild( new Tab.Item({'caption': 'tabitem.appendChild', 'html': '<b>Lorem ipsum</b><br><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'}) );
		tabitem3.appendChild( new Button({
			'text': 'Jump to first tab',
			'style': 'clear: left',
			'onclick': function() {
				tabitem1.select();
			}
		}) );

		tabitem3.appendChild( new Button({
			'text': 'Jump to second tab',
			'onclick': function() {
				tab.childNodes[1].select();
			}
		}) );

		var tabitem4 = this.tab.appendChild( new Tab.Item({
			'caption': 'tabitem.closable',
			'closable': true,
			'text': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'
		}) );

		this.tabitem5 = this.tab.appendChild( new Tab.Item({
			'caption': 'Tab.onchange'
		}) );

		this.tabitem5.style.overflow = 'auto';

		this.tab.onchange = this.tab_onchange.bind(this);
	},
	tab_onchange: function() {
		this.tabitem5.html += '$: $. was selected<br>'.$(new Date().format('hh:mm:ss'), this.tab.selectedIndex);
	}
}))();
