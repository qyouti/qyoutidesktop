/* http://classic.battle.net/war2/units/peasant.shtml */
/* http://artho.com/warcraft/wcart.html */
/* http://www.geocities.co.jp/Playtown-Domino/8007/images.html */

var Entity = Div.extend({
	init: function() {
		Div.prototype.init.call(this);
	},
	moveTo: function(left, top) {
		var oldLeft = parseInt(this.offsetLeft-this.offsetWidth/2);
		var oldTop = parseInt(this.offsetTop-this.offsetHeight/2);

		var newLeft = parseInt(left-this.offsetWidth/2);
		var newTop = parseInt(top-this.offsetHeight/2);

		var angel = Math.atan2(newTop-oldTop, newLeft-oldLeft);
		var d = Math.sqrt(Math.pow(oldLeft-newLeft, 2) + Math.pow(oldTop-newTop, 2));
		var s = d/this.speed;

		this.style.transition = 'top '+s+'s linear, left '+s+'s linear, rotate 1s linear';
		this.style.transform = 'rotate('+angel+'rad)';


		this.style.left = newLeft+'px';
		this.style.top = newTop+'px';
	}
});

var Catapult = Entity.extend({
	init: function() {
		Entity.prototype.init.call(this);
		this.addClassName('catapult');
		this.setAttribute('id', 'wait');
	},
	speed: 60,
	health: 1
});


new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);
		CSS.load('css/jcraft.css');
		this.addClassName('jcraft');

		var ground = this.appendChild( new Div({
			'class': 'ground',
			'onclick': function(event) {
				catapult.moveTo(event.offsetX, event.offsetY);
			}.bind(this)
		}) );

		var grass = ground.appendChild( new Div({'class': 'grass'}) );

		var catapult = ground.appendChild( new Catapult() );
	}
}))();

