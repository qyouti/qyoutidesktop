new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		
		this.calendar = this.appendChild( new Calendar() );
		this.appendChild( new Div({'style': 'margin-top: 1em;'}) );
		this.textbox = this.appendChild( new Textbox() );
		this.calendar.onchange = this.calendar_onchange.bind(this);
	},
	calendar_onchange: function() {
		this.textbox.text = this.calendar.selectedDate.format('yyyy-mm-dd');
	}
}))();
