/* LESSON 3: events */

new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		/* Add a message box to our application's body */
		this.coordinates = this.appendChild( new Div() );

		/* an event handler can be defined this way */
		/* this.addEventListener('mousemove', this.mousemove_handler.bind(this), false); */

		/* this way */
		/* this.onmousemove = this.mousemove_handler.bind(this) */

		this.appendChild( new Button({
			text: 'Close',
			style: 'position: absolute; right: 0px; bottom: 0px;',
			/* event handlers can be defined this way either */
			onclick: function(event) {
				/* our application will be closed */
				this.close();
			}.bind(this)
		}) );
	},
	/* if you define a property with the name convention of [name of the event]_handler     */
	/* then the constructor of the element class will attach the appropritate event handler */
	/* to the element                                                                       */
	mousemove_handler: function(event) {
		/* html property parses html tags in the given string         */
		/* text property does not parse html tags in the given string */
		/* try to modify the code                                            */
		this.coordinates.html = 'event.offsetX: ' + event.offsetX + '<br>event.offsetY: ' + event.offsetY;
	}
}))();
