new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		this.highlightarea = this.appendChild( new Highlightarea({
			'style': 'width: 100%; height: 100%;'
		}) );

		this.highlightarea.text = '(function() {\n\talert("hy there!");\n}.bind(this))();';
	}
}))();
