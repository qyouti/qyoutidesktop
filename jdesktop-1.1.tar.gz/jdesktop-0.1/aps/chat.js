var User = Div.extend({
	init: function(parent, client) {
		Div.prototype.init.call(this);
		this.addClassName('user');
		var icon = this.appendChild( new Div({'class': 'facewrap'}) );
		icon.appendChild( new Div({'class': 'icon face', 'context': 'emotes', 'size': '48', 'name': 'face-smile'}) );
		this.appendChild( new Div({'class': 'name', 'text': client.username}) );

		this.status = this.appendChild( new Div({'class': 'icon status', 'context': 'status', 'size': '16', 'name': 'user-$'.$(client.status)}) );


		if (parent.username !== client.username) return;
		var status = this.appendChild( new Select({'onchange': function(event) {
			parent.websocket.send('{"request": "changestatus", "status": "$"}'.$(status.options[status.selectedIndex].text));
		}.bind(this) }) );

		status.appendChild( new Option({'text': 'online'}) );
		status.appendChild( new Option({'text': 'away'}) );
		status.appendChild( new Option({'text': 'busy'}) );
	}
});

new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		this.loader = Dialog.loader({
			'caption': 'Connecting...',
			'text': 'Please wait while the connection is established to the chat server at ws://$:8001'.$(top.location.host),
			'onchange': function() {
				this.close();
			}.bind(this)
		});

		this.loader.show();

		CSS.load('css/chat.css');
		this.setAttribute('name', 'chat');

		this.websocket = new WebSocket('ws://$:8001'.$(top.location.host));
		this.websocket.onopen = this.websocket_onopen.bind(this);
		this.websocket.onerror = this.websocket_onerror.bind(this);
		this.websocket.onclose = this.websocket_onclose.bind(this);
		this.websocket.onmessage = this.websocket_onmessage.bind(this);

		this.userlist = this.appendChild( new Div({
			'class': 'userlist'
		}) );

		this.messages = this.appendChild( new Div({
			'class': 'messages'
		}) );

		this.toolbar = this.appendChild( new Div({
			'class': 'toolbar'
		}) );

		this.toolbar.appendChild( new Controls({'buttons': ['bold', 'italic', 'underline', 'strikeThrough', 'verticalRuler', 'undo', 'redo']}) );

		/* */
		this.textbox = this.appendChild( new Div({
			'class': 'textbox'
		}) );

		this.textbox.appendChild( new Button({
			'text': 'Üzenetküldés',
			'type': 'flat',
			'onclick': this.sendmessage.bind(this)
		}) );

		this.textbox = this.textbox.appendChild( new Div({
			'class': 'messagearea'
		}) );

		this.textbox = this.textbox.appendChild( new Div({
			'style': 'width: 100%; height: 100%; padding: 5px; border: dotted black 1px;',
			'contenteditable': 'true'
		}) );

	},
	onkeydown: function(event) {
		if (document.activeElement==this.textbox&&event.which==13) {
			if (event.altKey) {
				var evt = document.createEvent("KeyEvents");
				event.altKey = false;
				evt.initEvent(event, true, true); // event type,bubbling,cancelable
				this.textbox.dispatchEvent(evt);
			} else {
				this.sendmessage();
				event.preventDefault();
				event.stopPropagation();
			}
		}
	},
	websocket_onmessage: function(data) {
		data = JSON.parse(data.data);
		switch (data['request']) {
			case 'loginok':
				this.request_loginok();
				break;
			case 'refreshuserlist':
				this.request_refreshuserlist(data['users']);
				break;
			case 'publicmessage':
				this.request_publicmessage(data);
				break;
			case 'changestatus':
				this.request_changestatus(data);
				break;
			case 'login':
				this.request_login(data);
				break;
			case 'logout':
				this.request_logout(data);
				break;
			case 'errormessage':
				new Dialog.error({
					text: data['message']
				}).show();
				break;
			default:
				new Dialog.error({
					text: 'Invalid request from server'
				}).show();
				break;
		}
	},
	websocket_onopen: function(data) {
		this.loader.close();

		this.dialog = new Dialog.password({
			onchange: this.do_login.bind(this)
		});
		this.dialog.show();
	},
	websocket_onerror: function(data) {
		this.loader.close();

		this.dialog = new Dialog.error({
			'caption': 'Connection failed',
			'text': 'The connection was aborted $'.$(this.websocket.url)
		});
		this.dialog.show();
	},
	websocket_onclose: function(data) {
		this.loader.close();

		this.dialog = new Dialog.error({
			'caption': 'Connection failed',
			'html': '<b>Could not connect to server at $</b><br><br>Your browser may not support the required WebSocket version (version 8 or higher)'.$(this.websocket.url)
		});
		this.dialog.show();
	},
	do_login: function(event, which) {
		if (which=='Ok') {
			this.username = this.dialog.username;
			this.websocket.send('{"request": "login", "username": "$"}'.$(this.dialog.username));
		} else {
			this.close();
		}
	},
	request_loginok: function(userlist) {
		this.dialog.close();
	},
	request_refreshuserlist: function(userlist) {
		userlist.forEach(function(client) {
			this.clients[client.username] = this.userlist.appendChild( new User(this, client) );
		}, this);
	},
	request_publicmessage: function(data) {
		this.messages.appendChild( new Div({
			'html': '<span>$: </span><span>$</span>'.$(data.username, data.message)
		}) );
		this.messages.scrollTop = this.messages.scrollHeight;
	},
	request_changestatus: function(data) {
		this.clients[data.username].status.setAttribute('name', 'user-$'.$(data.status));
	},
	request_login: function(client) {
		this.clients[client.username] = this.userlist.appendChild( new User(this, client) );
	},
	request_logout: function(client) {
		this.userlist.removeChild( this.clients[client.username] );
		delete this.clients[client.username];
	},
	sendmessage: function(event) {
		this.websocket.send('{"request": "publicmessage", "message": "$"}'.$(this.textbox.html));
		this.textbox.text='';
		this.textbox.focus();
	},
	clients: {}
}))();


