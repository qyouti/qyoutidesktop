new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		this.appendChild( new Button({
			'text': 'Information Dialog',
			'onclick': function(event) {
				new Dialog.information({
					'caption': 'Information Dialog',
					'text': 'This is an information in general!'
				}).show();
			}.bind(this)
		}) );

		this.appendChild( new Button({
			'text': 'Warning Dialog',
			'onclick': function(event) {
				new Dialog.warning({
					'caption': 'Warning Dialog',
					'text': 'This is a warning message!'
				}).show();
			}.bind(this)
		}) );

		this.appendChild( new Button({
			'text': 'Error Dialog',
			'onclick': function(event) {
				new Dialog.error({
					'caption': 'Error Dialog',
					'text': 'This is an error message!'
				}).show();
			}.bind(this)
		}) );

		this.appendChild( new Button({
			'text': 'Dialog Loader',
			'onclick': function(event) {
				var dialog = new Dialog.loader({
					'caption': 'Processing...',
					'text': 'Please wait while your request is being processed...',
					'onchange': function(event) {
						dialog.close();
					}
				}).show();
			}.bind(this)
		}) );

		this.appendChild( new Button({
			'text': 'Dialog FileBrowser',
			'onclick': function(event) {
				var dialog = new Dialog.fileBrowser({
					'caption': 'Select a file',
					'onchange': function(event) {
						dialog.close();
					}
				}).show();
			}.bind(this)
		}) );


		this.appendChild( new Button({
			'text': 'Password',
			'onclick': function(event) {
				var dialog = new Dialog.password({
					'onchange': function(event, which) {
						/* send authentication information to server */
						/* dialog.password;                          */
						/* dialog.username;                          */
						dialog.close();
					}.bind(dialog)
				}).show();
			}.bind(this)
		}) );
	}
}))();


