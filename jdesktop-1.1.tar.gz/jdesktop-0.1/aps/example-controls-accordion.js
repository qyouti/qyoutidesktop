new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		var accordion = this.appendChild( new Accordion({
			'style': 'width: 500px;',
			'onchange': function() {
				if (accordion.selectedIndex==3) {
					var item = accordion.childNodes[accordion.selectedIndex];
					item.counter++;
					item.text = 'you have selected this item $ times'.$(item.counter);
				}
			}
		}) );

		var item1 = accordion.appendChild(new Accordion.Item({'caption': 'Static content', 'html' : '<b>Lorem ipsum</b><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'}) );
		var item2 = accordion.appendChild(new Accordion.Item({'caption': 'Static content', 'html' : '<b>Lorem ipsum</b><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'}) );
		var item3 = accordion.appendChild(new Accordion.Item({'caption': 'Dynamic content'}) );
		var item4 = accordion.appendChild(new Accordion.Item({'caption': 'Events'}) );
		var item5 = accordion.appendChild(new Accordion.Item({'caption': 'Important to know', 'html': 'If you add some content to an accordion item with an event listener and then you modify the content of it with the <i>.text</i> or <i>.html</i> property then all the event listerers will be cancelled!'}) );

		item2.caption += ' with later modification';
		item2.html += '<br><br><b>Lorem ipsum</b><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.';



		var datepicker = item3.appendChild( new Button.DatePicker({
			'text': 'Select Date',
			'onchange': function() {
				div.text = '$ is the $. week of the year'.$(datepicker.selectedDate.format('yyyy-mm-dd'), datepicker.selectedDate.getWeek());
			}
		}) );
		var div = item3.appendChild( new Div() );

		item4.counter = 0;
		item4.appendChild( new Div({'text': 'you have selected this item 0 times'}) );


		item5.appendChild( new Div({
			'style': 'width: 100px; height: 50px; background-color: blue;',
			'text': 'click me',
			'onclick': function() {
				alert('this event will not fire');
			}
		}) );

		item5.html += '<br>extra content';

	}
}))();

