new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		CSS.load('css/developer.css');
		this.setAttribute('id', 'developer');

		var fm = this.appendChild( new FileMenu() );

		var filemenu = fm.appendChild( new FileMenu.Item({'text': 'File'}) );
		var examplesmenu = fm.appendChild( new FileMenu.Item({'text': 'Examples'}) );
		var helpmenu = fm.appendChild( new FileMenu.Item({'text': 'Help'}) );

		filemenu = filemenu.appendChild( new DropdownMenu() );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-new', 'text': 'New', 'title': 'Create new empty document', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		//filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-new', 'text': 'New', 'title': 'Create new visual design document', 'onclick': this.visual_new.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'application-exit', 'text': 'Quit', 'title': 'Quit the application', 'shortcut': 'Ctrl+Q', 'onclick': this.close.bind(this)}) );

		examplesmenu = examplesmenu.appendChild( new DropdownMenu() );

		var coreexamples = examplesmenu.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'Core'}) );
		coreexamples = coreexamples.appendChild( new DropdownMenu() );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'jDesktop application', 'onclick': this.loadlesson.bind(this, 'aps/example-helloworld.js')}) );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'Methods, variables, properties', 'onclick': this.loadlesson.bind(this, 'aps/example-core-methods.js')}) );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'Events', 'onclick': this.loadlesson.bind(this, 'aps/example-core-events.js')}) );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'Inheritance, method override', 'onclick': this.loadlesson.bind(this, 'aps/example-core-inheritance.js')}) );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'Static consturctor, method, variable, property', 'onclick': this.loadlesson.bind(this, 'aps/example-core-static.js')}) );
		coreexamples.appendChild( new DropdownMenu.Item({'icon': 'system-run', 'text': 'instanceof keyword', 'onclick': this.loadlesson.bind(this, 'aps/example-core-instanceof.js')}) );

		var controls = examplesmenu.appendChild( new DropdownMenu.Item({'icon': 'insert-button', 'text': 'Controls'}) );
		controls = controls.appendChild( new DropdownMenu() );
		controls.appendChild( new DropdownMenu.Item({'icon': 'insert-button', 'text': 'Button', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-button.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'text-field', 'text': 'Input', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-input.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'text-field', 'text': 'Progressbar', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-progressbar.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'format-text-color', 'text': 'Highlightarea', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-highlightarea.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'tab-new', 'text': 'Tabs', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-tab.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'view-list-tree', 'text': 'TreeView', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-treeview.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'page-simple', 'text': 'Accordion', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-accordion.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'color-picker', 'text': 'Colorpicker', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-colorpicker.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'view-calendar', 'text': 'Calendar', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-calendar.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'view-preview', 'text': 'ImageView', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-imageview.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'view-form-table', 'text': 'DataTable', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-datatable.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'show-menu', 'text': 'Menu', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-menu.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'help-contextual', 'text': 'Contextmenu', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-contextmenu.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'text-speak', 'text': 'Audio', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-audio.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'tool-animator', 'text': 'Video', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-video.js')}) );
		controls.appendChild( new DropdownMenu.Item({'icon': 'window-duplicate', 'text': 'Dialog', 'onclick': this.loadlesson.bind(this, 'aps/example-controls-dialog.js')}) );

		var visiulization = examplesmenu.appendChild( new DropdownMenu.Item({'icon': 'office-chart-pie', 'text': 'Visualization'}) );
		visiulization = visiulization.appendChild( new DropdownMenu() );
		visiulization.appendChild( new DropdownMenu.Item({'icon': 'office-chart-pie', 'text': 'Chart', 'onclick': this.loadlesson.bind(this, 'aps/example-visualization-chart.js')}) );

		var communication = examplesmenu.appendChild( new DropdownMenu.Item({'icon': 'network-connect', 'text': 'Communication'}) );
		communication = communication.appendChild( new DropdownMenu() );
		communication.appendChild( new DropdownMenu.Item({'icon': 'quickopen', 'text': 'Ajax', 'onclick': this.loadlesson.bind(this, 'aps/example-communication-ajax.js')}) );
		communication.appendChild( new DropdownMenu.Item({'icon': 'network-connect', 'text': 'WebSocket', 'onclick': this.loadlesson.bind(this, 'aps/example-communication-websocket.js')}) );
		communication.appendChild( new DropdownMenu.Item({'icon': 'network-connect', 'text': 'WebSocket RPC', 'onclick': this.loadlesson.bind(this, 'aps/example-communication-websocketrpc.js')}) );
		communication.appendChild( new DropdownMenu.Item({'icon': 'network-connect', 'text': 'SOAP', 'onclick': this.loadlesson.bind(this, 'aps/example-communication-soap.js')}) );

		var storage = examplesmenu.appendChild( new DropdownMenu.Item({'icon': new Icon({'context': 'places', 'size': '16', 'name': 'server-database'}), 'text': 'Storage'}) );
		storage = storage.appendChild( new DropdownMenu() );
		storage.appendChild( new DropdownMenu.Item({'icon': 'preferences-activities', 'text': 'Session storage', 'onclick': this.loadlesson.bind(this, 'aps/example-storage-session.js')}) );
		storage.appendChild( new DropdownMenu.Item({'icon': new Icon({'context': 'devices', 'size': '16', 'name': 'computer'}), 'text': 'Local storage', 'onclick': this.loadlesson.bind(this, 'aps/example-storage-local.js')}) );
		storage.appendChild( new DropdownMenu.Item({'icon': new Icon({'context': 'places', 'size': '16', 'name': 'server-database'}), 'text': 'Database', 'onclick': this.loadlesson.bind(this, 'aps/example-storage-database.js')}) );
		storage.appendChild( new DropdownMenu.Item({'icon': 'download', 'text': 'Application Cache', 'onclick': this.loadlesson.bind(this, 'aps/example-storage-cache.js')}) );


		var computation = examplesmenu.appendChild( new DropdownMenu.Item({'icon': 'fork', 'text': 'Computation'}) );
		computation = computation.appendChild( new DropdownMenu() );
		computation.appendChild( new DropdownMenu.Item({'icon': 'mail-queue', 'text': 'Timer', 'onclick': this.loadlesson.bind(this, 'aps/example-computation-timer.js')}) );
		computation.appendChild( new DropdownMenu.Item({'icon': 'fork', 'text': 'Web Worker', 'onclick': this.loadlesson.bind(this, 'aps/example-computation-webworker.js')}) );


		helpmenu = helpmenu.appendChild( new DropdownMenu() );
		helpmenu.appendChild( new DropdownMenu.Item({
			'icon': 'help-about',
			'text': 'About jDeskop Developer',
			'onclick': this.about.bind(this)
		}) );

		var im = this.appendChild( new IconMenu() );
		im.appendChild( new Button({'icon': 'arrow-right', 'text': 'Run application', 'onclick': this.run.bind(this)}) );
		//im.appendChild( new Vr() );
		//im.appendChild( new this.DraggableButton({'icon': 'insert-button', 'control-object': 'Button', 'onclick': this.run.bind(this)}) );


		this.tab = this.appendChild( new Tab({'style': 'width: 100%; height: 100%;'}) );

		this.loadlesson(null, 'aps/example-helloworld.js');
	},
	DraggableButton: Button.extend({
		init: function(p) {
			Button.prototype.init.call(this, p);
			this.setAttribute('draggable', 'true');
		},
		dragstart_handler: function(event) {
			event.dataTransfer.effectAllowed = 'move';
			event.dataTransfer.setData('text/html', this.getAttribute('control-object'));
		}
	}),
	loadlesson: function(event, path) {
		new Ajax({
			onload: function(data) {
				var item = this.tab.appendChild( new Tab.Item({
					'caption': FileHandler.splitpath(path).filename,
					'closable': 'true',
					'title': 'Path: $'.$(path)
				}) );
				var highlightarea = item.appendChild( new Highlightarea({'style': 'width: 100%; height: 100%;'}) );
				highlightarea.text=data;
			}.bind(this)
		}).get(path);
	},
	run: function(event) {
		var highlightarea = this.tab.childNodes[this.tab.selectedIndex].firstChild;

		Application.execute({
			source: highlightarea.text,
			newWindow: true
		});

/*
		var application = window.open('loadapp.html?id=$'.$(String.random(10)), "", "menubar=0, resizable=1, width=640, height=480");

		Timer.setTimeout(function() {
			if (application.document.getElementById('script')) {
				var highlightarea = this.tab.childNodes[this.tab.selectedIndex].firstChild;
				application.document.getElementById('script').textContent = highlightarea.text;
			} else {
				Timer.setTimeout(arguments.callee.bind(this), 10);
			}
		}.bind(this), 10);
*/
		
	},
	document_new: function() {
		var item = this.tab.appendChild( new Tab.Item({
			'caption': 'Unsaved Document',
			'closable': true
		}) );
		var ha = item.appendChild( new Highlightarea({
			'style': 'width: 100%; height: 100%;',
			/*'text': ''*/
		}) );
		ha.setCursor({'x': 0, 'y': 0});
	},
	visual_new: function() {
		var table = new Div({'class': 'table', 'style': 'width: 100%; height: 100%;'});
		var row = table.appendChild( new Div() );

		this.visualdesigner = row.appendChild( new Div({
			'style': 'width: 100%; height: 100%; vertical-align: top;position: relative;',
			'ondragover': function(event) {
				event.stopPropagation();
				event.dataTransfer.effectAllowed = 'move';
				return false;
			},
			'ondrop': function(event) {
				var element = event.dataTransfer.getData('text/html');
				element = new window[element];
				element.text = 'Button #1';
				element.addEventListener('click', this.visualdesigner_selectobject.bind(this, element));
				this.visualdesigner.appendChild( element );
			}.bind(this),
			contextmenu: [
				{'text': 'View Generated Source', 'icon': 'document-edit-verify', 'onclick': function() {
					alert(this.getGeneratedSource(this.visualdesigner));
				}.bind(this) }
			]
		}) );

		row.appendChild( new Div({'style': 'min-width: 10px; border: solid black 1px;'}) );

		this.objectProperties = row.appendChild( new Div({
			'style': 'width: 300px; overflow: auto;'
		}) );

		var accordion = this.objectProperties.appendChild( new Accordion() );
		this.selectedobject_properties = accordion.appendChild( new Accordion.Item({'caption': 'Properties'}) );
		this.selectedobject_style = accordion.appendChild( new Accordion.Item({'caption': 'Style', 'style':'overflow-y: auto; overflow-x: hidden; max-height: 300px;'}) );
		this.selectedobject_events = accordion.appendChild( new Accordion.Item({'caption': 'Events', 'style':'overflow-y: auto; overflow-x: hidden; max-height: 300px;'}) );

		var item = this.tab.appendChild( new Tab.Item({
			'caption': 'Unsaved Document',
			'closable': true,
		}) );

		item.appendChild( table );

	},
	visualdesigner_selectobject: function(event, element) {
		event.stopPropagation();
		event.preventDefault();
		element.style.border = 'dashed lightgrey 2px';
		this.selectedObject = this;

		this.selectedobject_properties.html = '';
		this.selectedobject_style.html = '';

//		while (this.selectedobject_properties.hasChildNodes())
//			this.selectedobject_properties.removeChild(this.selectedobject_properties.firstChild);

		var table = this.selectedobject_properties.appendChild( new Div({'class': 'table'}) );
		var row;

		['text', 'icon'].forEach(function(property) {
			var row = table.appendChild( new Div() );
			row.appendChild( new Div({
				'text': property
			}) );
			row.appendChild( new Textbox({
				'text': element[property],
				'style': 'width: 200px; margin-left: 5px;',
				'onkeyup': function(event) {
					element[property] = event.target.text;
				}.bind(element, property)
			}) );
		}, this);

		var table = this.selectedobject_style.appendChild( new Div({'class': 'table'}) );
		var row;

		this.styleAttributes.forEach(function(property) {
			var row = table.appendChild( new Div() );
			row.appendChild( new Div({
				'text': property
			}) );
			row.appendChild( new Textbox({
				'text': element[property]?element[property]:'',
				'style': 'width: 200px; margin-left: 5px;',
				'onkeyup': function(event) {
					if (event.target.text=='') {
						element.style.removeProperty(property);
					} else {
						element.style[property] = event.target.text;
					}
				}.bind(element, property)
			}) );
		}, this)

		var table = this.selectedobject_events.appendChild( new Div({'class': 'table'}) );
		var row;

		this.objectEvents.forEach(function(property) {
			var row = table.appendChild( new Div() );
			row.appendChild( new Div({
				'text': property
			}) );
			row.appendChild( new Textbox({
				'text': element[property],
				'style': 'width: 200px; margin-left: 5px;',
				'onkeyup': function(event) {
					element.style[property] = event.target.text;
				}.bind(element, property)
			}) );
		}, this)

	},
	about: function() {
		var dialog = new Dialog.information({
			'style': 'width: 500px;',
			'caption': 'About examples',
			'html': '<center><font style="font-weight: bold; font-size: x-large;">jDesktop Developer</font><br>jDesktop Developer is a development tool for jDesktop JavaScript library<br><br>Copyright &#169; 2011 Guttmann Krisztián<br><br><a target="_blank" href="http://www.jdesktop.com">http://www.jdesktop.com</a></center>'
		});
		dialog.show();
	},
	getGeneratedSource: function(node) {
		var src = '';
		DOM.traverse(node, function(node) {
			if (node.name)
				src += 'this.appendChild( new $)\n'.$(node.name);
			return(true);
		});
		return(src);
	},
	styleAttributes: [
		/* Box Properties */
		'border',
		'borderBottom',
		'borderBottomWidth',
		'borderColor',
		'borderImage',
		'borderLeft',
		'borderLeftWidth',
		'borderRadius',
		'borderRight',
		'borderRightWidth',
		'borderStyle',
		'borderTop',
		'borderTopWidth',
		'borderWidth',
		'boxShadow',
		'clear',
		'float',
		'height',
		'margin',
		'marginBottom',
		'marginLeft',
		'marginRight',
		'marginTop',
		'opacity',
		'overflow',
		'padding',
		'paddingBottom',
		'paddingLeft',
		'paddingRight',
		'paddingTop',
		'width',
		/* Positioning */
		'position',
		'top',
		'left',
		'right',
		'bottom',
		/* Background and Color Properties */
		'background',
		'backgroundAttachment',
		'backgroundColor',
		'backgroundImage',
		'backgroundPosition',
		'backgroundRepeat',
		'color',
		/* Classification  Properties */
		'display',
		'listStyle',
		'listStyleImage',
		'listStyleType',
		'listStylePosition',
		'whitespace',
		/* Font Properties */
		'font',
		'fontFamily',
		'fontSize',
		'fontStyle',
		'fontVariant',
		'fontWeight',
		/* Text Properties */
		'letterSpacing',
		'lineHeight',
		'textAlign',
		'textDecoration',
		'textIndent',
		'textOverflow',
		'textShadow',
		'textTransform',
		'verticalAlign',
		'wordSpacing',
		/* Animation */
		'transition',
		'transformation'
	].sort(),
	objectEvents: [
		'onclick',
		'ondblclick',
		'onmousedown',
		'onmouseup',
		'onmouseover',
		'onmousemove',
		'onmouseout',
		'onkeydown',
		'onkeypress',
		'onkeyup',
		'onload',
		'onunload',
		'onabort',
		'onerror',
		'onresize',
		'onscroll',
		'onselect',
		'onchange',
		'onsubmit',
		'onreset',
		'onfocus',
		'onblur'
	]
}))();
