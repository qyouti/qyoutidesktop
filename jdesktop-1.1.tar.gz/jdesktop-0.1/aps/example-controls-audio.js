new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		/* example not yet implemented */
		
	}
}))();
