/* LESSON 6: instances                                          */
/* The instanceof operator tests whether an object has in       */
/* its prototype chain the prototype property of a constructor. */

var Guy = Div.extend({
	init: function() {
		Div.prototype.init.apply(this, arguments);

		this.addClassName('icon');
		this.setAttribute('context', 'emotes');
		this.setAttribute('size', '48');
		this.setAttribute('name', 'face-plain');
		this.style.float='left';
		this.style.display='inline-block';
	},
	plain: function() {
		this.setAttribute('name', 'face-plain');
	},
	smile: function() {
		if (this.timer) Timer.clearTimeout(this.timer);
		this.setAttribute('name', 'face-smile');
		this.timer = Timer.setTimeout(this.plain.bind(this), 1000);
	},
	laugh: function() {
		if (this.timer) Timer.clearTimeout(this.timer);
		this.setAttribute('name', 'face-laugh');
		this.timer = Timer.setTimeout(this.smile.bind(this), 1000);
	},
	sad: function() {
		if (this.timer) Timer.clearTimeout(this.timer);
		this.setAttribute('name', 'face-sad');
		this.timer = Timer.setTimeout(this.plain.bind(this), 1000);
	},
	click_handler: function(event) {
		this.smile();
	},
	dblclick_handler: function(event) {
		this.laugh();
	}
});

var EmoGuy = Guy.extend({
	init: function() {
		Guy.prototype.init.apply(this, arguments);
	},
	smile: function() {
		/* here we redefine the base method         */
		/* emos never smile                         */
		/* this.setAttribute('name', 'face-smile'); */
		this.sad();
	},
	laugh: function() {
		/* here we redefine the base method         */
		/* emos never laugh                         */
		/* this.setAttribute('name', 'face-laugh'); */
		this.sad();
	}
});

var Alien = Div.extend({
	init: function() {
		Guy.prototype.init.apply(this, arguments);

		this.addClassName('icon');
		this.setAttribute('context', 'actions');
		this.setAttribute('size', '48');
		this.setAttribute('name', 'im-user');
		this.style.float='left';
		this.style.display='inline-block';

		this.style.transition = 'opacity 0.1s linear';
	},
	hide: function() {
		if (this.timer) Timer.clearTimeout(this.timer);
		this.style.opacity = '0';
		this.timer = Timer.setTimeout(this.reveal.bind(this), 1000);
	},
	reveal: function() {
		this.style.opacity = '1';		
	},
	click_handler: function(event) {
		this.hide();
	}
})


                                                              
new (Application.extend({
	init: function() {
		/* here we call the base constructor */
		Application.prototype.init.apply(this, arguments);

		this.appendChild( new Guy() );
		this.appendChild( new EmoGuy() );
		this.appendChild( new Guy() );
		this.appendChild( new Alien() );

		this.fieldset = this.appendChild( new Fieldset({
			'legend': 'Instructions',
			'style': 'width: 250px; height: 100%; float: right;'
		}) );
	},
	mousemove_handler: function(event) {
		if (event.target instanceof Guy)
			this.fieldset.text = 'He is a human';
		else if (event.target instanceof Alien)
			this.fieldset.text = 'He is an alien';
		else 
			this.fieldset.text = 'Click on somebody';

		/* other examples to make things clear for sure */
		/* new Guy() instanceof EmoGuy    -> false      */
		/* new Guy() instanceof Guy       -> true       */
		/* new Guy() instanceof Div       -> true       */
		/* new Guy() instanceof Alien     -> false      */
		/* new EmoGuy() instanceof EmoGuy -> true       */
		/* new EmoGuy() instanceof Guy    -> true       */
		/* new EmoGuy() instanceof Div    -> true       */
		/* new EmoGuy() instanceof Alien  -> false      */
		/* new Alien() instanceof EmoGuy  -> false      */
		/* new Alien() instanceof Guy     -> false      */
		/* new Alien() instanceof Div     -> true       */
		/* new Alien() instanceof Alien   -> true       */
	}
}))();


