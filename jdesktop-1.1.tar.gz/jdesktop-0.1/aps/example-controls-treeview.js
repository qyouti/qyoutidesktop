new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		var tw = this.appendChild( new TreeView() );

		var subdir = new TreeView.RootItem({'text': 'msdos', 'icon': 'places folder'});
		subdir.appendChild( new TreeView.ListItem({'text': 'msdos.com', 'icon': 'mimetypes application-x-executable'}) );
		subdir.appendChild( new TreeView.ListItem({'text': 'chkdsk.exe', 'icon': 'mimetypes application-x-executable'}) );

		var subdir3 = new TreeView.RootItem({'text': 'system', 'icon': 'places folder-important'});
		subdir3.appendChild( new TreeView.ListItem({'text': 'rundll.dll', 'icon': 'mimetypes application-x-executable'}) );
		subdir3.appendChild( new TreeView.ListItem({'text': 'system.dll', 'icon': 'mimetypes application-x-executable'}) );
		subdir3.appendChild( new TreeView.ListItem({'text': 'config.txt', 'icon': 'mimetypes text-plain'}) );

		var subdir2 = new TreeView.RootItem({'text': 'windows', 'icon': 'places folder'});
		subdir2.appendChild( subdir3 );
		subdir2.appendChild( new TreeView.ListItem({'text': 'win.com', 'icon': 'mimetypes application-x-executable'}) );
		subdir2.appendChild( new TreeView.ListItem({'text': 'calculator.exe', 'icon': 'mimetypes application-x-executable'}) );
		subdir2.appendChild( new TreeView.ListItem({'text': 'explorer.exe', 'icon': 'mimetypes application-x-executable'}) );

		var root = tw.appendChild( new TreeView.RootItem({'text': 'root', 'icon': 'places folder-red'}) );
		root.appendChild( subdir );
		root.appendChild( subdir2 );
		root.appendChild( new TreeView.ListItem({'text': 'autoexec.bat', 'icon': 'mimetypes application-x-executable-script'}) );
		root.appendChild( new TreeView.ListItem({'text': 'config.sys', 'icon': 'mimetypes text-plain'}) );
		root.appendChild( new TreeView.ListItem({'text': 'image.bmp', 'icon': 'mimetypes image-x-generic'}) );
	}
}))();


