/* LESSON 1 */
/* jDesktop applications can be created by extending the Application class. */
/* Once we have our own Application class we have to instantiate it. */
new (Application.extend({
init: function() {
/* This is our constructor. */
/* Constructor gets called whenever we instantiate a class. */
/* We have to call the base constructor in order our base class could do its job. */
Application.prototype.init.apply(this, arguments);
/* here comes your code ... */
this.bubble = null;
var button = this.appendChild( new Button({
'style': 'margin-top: 100px;',
'text': 'Press me to show up a bubble',
'onmousedown': function(event) {
this.bubble = this.appendChild( new Bubble({
'text': 'this button is pressed'
}) );
this.bubble.style.position='fixed';
this.bubble.style.top = '$px'.$(button.positionY-button.offsetHeight-this.bubble.offsetHeight-2);
this.bubble.style.left = '$px'.$(button.positionX);
}.bind(this)
}) );
},
onmouseup: function(event) {
try {
this.removeChild(this.bubble);
} catch(e) {};
}
}))();

