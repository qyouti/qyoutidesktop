new (Application.extend({
	init: function(p) {
		/* Constructor call */
		Application.prototype.init.call(this, {
			"label": "Example - Cellular Automata"
			 /* /css/example-skeleton.css will be loaded */
		});

		var tab = this.appendChild( new Tab({
			'style': 'height: 100%'
		}) );
		
		this.tab1 = tab.appendChild( new Tab.Item({
			"caption": "1 dimensional"
		}) );

		this.tab1.canvas = this.tab1.appendChild( new Canvas({
			'style': 'float: left; border: solid black 1px; margin-right: 1em;',
			"width": "640",
			"height": "480"
		}) );

		this.tab1.fieldset = this.tab1.appendChild( new Fieldset({
			'style': 'width: auto;',
			'legend': 'Control'
		}) );

		this.tab1.fieldset.numberpicker = this.tab1.fieldset.appendChild( new NumberPicker({
			"value": 30,
			"onchange": this.canvas_update.bind(this)
		}) );

		this.tab2 = tab.appendChild( new Tab.Item({
			"caption": "2 dimensional"
		}) );

		this.canvas_update();
	},
	canvas_update: function() {
		var ctx = this.tab1.canvas.getContext("2d");
		ctx.fillStyle = "black";
		ctx.fillRect(320, 0, 1, 1);
		var imageData = ctx.getImageData(0, 0, 640, 480);
		var pix = imageData.data;
		for (var y=1; y<imageData.height; y++) {
			for (var x=1, pattern = 0; x<imageData.width-1; x++) {
				pattern = 0;
				pattern |= 1&pix[(((y-1)*(imageData.width*4)) + ((x+1)*4)) + 3];
				pattern |= 2&pix[(((y-1)*(imageData.width*4)) + ((x  )*4)) + 3];
				pattern |= 4&pix[(((y-1)*(imageData.width*4)) + ((x-1)*4)) + 3];
				pix[((y*(imageData.width*4)) + (x*4)) + 3] = Math.pow(2, pattern)&this.tab1.fieldset.numberpicker.value?255:0;
			}
		}
		ctx.putImageData(imageData, 0, 0);
	}
}))();
