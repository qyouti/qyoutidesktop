new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		var msgbox = this.appendChild( new Div() )
		this.button1 = this.appendChild( new DateButton({
			'text': 'Select Date',
			'onchange': function(event, date) {
			}.bind(this)
		}) );

		this.button2 = this.appendChild( new DateButton({
			'text': 'Select Date',
			'onchange': function(event) {
			}.bind(this)
		}) );
	}
}))();
