/* LESSON 2: variables, methods, properties (getter/setter)                   */
/* You can define new methods, variables, properties to your Class like below */
                                                              
new (Application.extend({
	init: function() {
		/* here we call the base constructor */
		Application.prototype.init.apply(this, arguments);

		/* variables can be accessed simply like this               */
		this.variable = 'Hy ';

		/* properties may define a getter and setter mechanism      */
		/* when we read the content of our property,                */
                /* its 'get' method will be called by the JavaScript engine */
		/* when we set the content of our property,                 */
                /* its 'set' method will be called by the JavaScript engine */
		this.property += 'there!';

		/* calling a method */
		this.method(this.property);
	},
	variable: '',
	method: function(str) {
		/* 'text' is also a property but we inherited it */
                /* from one of our ancestors                     */
		this.text = str;
	},
	property: {
		get: function() {
			return(this.variable);
		},
		set: function(value) {
			this.variable = value;
		}
	}
}))();

