new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);
		CSS.load('css/mail.css');
		this.setAttribute('id', 'mail');

		var fm = this.appendChild( new FileMenu() );

		var filemenu = fm.appendChild( new FileMenu.Item({'text': 'File'}) );
		var editmenu = fm.appendChild( new FileMenu.Item({'text': 'Edit'}) );
		var helpmenu = fm.appendChild( new FileMenu.Item({'text': 'Help'}) );

		filemenu = filemenu.appendChild( new DropdownMenu() );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-new', 'text': 'New', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'download', 'text': 'Download', 'title': 'Download application for offline usage', 'shortcut': 'Ctrl+D', 'onclick': this.download.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'application-exit', 'text': 'Quit', 'title': 'Quit the application', 'shortcut': 'Ctrl+Q', 'onclick': this.close.bind(this)}) );

		editmenu = editmenu.appendChild( new DropdownMenu() );
		var preferences = editmenu.appendChild( new DropdownMenu.Item({'icon': 'preferences-activities', 'text': 'Preferences'}) );

		helpmenu = helpmenu.appendChild( new DropdownMenu() );
		helpmenu.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		preferences = preferences.appendChild( new DropdownMenu() );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		var im = this.appendChild( new IconMenu() );
		im.appendChild( new Button({'text': 'New', 'icon': 'mail-message-new', 'onclick': this.document_new.bind(this)}) );
		im.appendChild( new Button({'text': 'Reply', 'icon': 'mail-reply-sender', 'onclick': this.document_reply.bind(this)}) );
		im.appendChild( new Button({'text': 'Reply to All', 'icon': 'mail-reply-all', 'onclick': this.document_reply_all.bind(this)}) );
		im.appendChild( new Button({'text': 'Forward', 'icon': 'mail-forward', 'onclick': this.document_reply_all.bind(this)}) );

		var table = this.appendChild( new Div({'class': 'table', 'style': 'height: 100%;'}) );
		var row = table.appendChild( new Div() );

		var folders = row.appendChild( new Div({'class': 'folders'}) );
		row.appendChild( new Div({'class': 'resizer'}) );
		this.messages = row.appendChild( new Div({'class': 'messages'}) );

		var tw = folders.appendChild( new TreeView() );
		root = tw.appendChild( new TreeView.RootItem({'text': 'on jDesktop', 'icon': 'places folder'}) );
		root.appendChild( new TreeView.ListItem({'text': 'Inbox', 'icon': 'places mail-folder-inbox', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Draft', 'icon': 'actions document-edit', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Junk', 'icon': 'actions mail-mark-junk', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Outbox', 'icon': 'places mail-folder-outbox', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Sent', 'icon': 'places mail-folder-sent', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Templates', 'icon': 'mimetypes text-plain', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );
		root.appendChild( new TreeView.ListItem({'text': 'Trash', 'icon': 'places user-trash', 'onclick': this.mailbox_open.bind(this, 'inbox')}) );

		this.websocket = new WebSocket('ws://$:8002'.$(top.location.host));
		this.websocket.onopen = this.websocket_onopen.bind(this);
		this.websocket.onerror = this.websocket_onerror.bind(this);
		this.websocket.onclose = this.websocket_onclose.bind(this);
		this.websocket.onmessage = this.websocket_onmessage.bind(this);

	},
	websocket_onopen: function() {
		this.request_login('username', 'password');
	},
	websocket_onerror: function(data) {
		this.dialog = new Dialog.error({
			'caption': 'Connection failed',
			'text': 'The connection was aborted $'.$(this.websocket.url)
		});
		this.dialog.show();
	},
	websocket_onclose: function(data) {
		this.dialog = new Dialog.error({
			'caption': 'Connection failed',
			'html': '<b>Could not connect to server at $</b><br><br>Your browser may not support the required WebSocket version (version 8 or higher)'.$(this.websocket.url)
		});
		this.dialog.show();
	},
	websocket_onmessage: function(data) {
		data = JSON.parse(data.data);
		if (typeof this[data['method']] == 'function')
			this[data['method']].apply(this, data['arguments']);
	},
	request_login: function(username, password) {
		var json = {};
		json.method = 'request_login';
		json.arguments = [username, password];
		this.websocket.send(JSON.stringify(json));
	},
	response_login: function(result) {
		if (result) {
			this.request_getmessagelist();
		}
	},
	request_getmessagelist: function() {
		var json = {};
		json.method = 'request_getmessagelist';
		json.arguments = [];
		this.websocket.send(JSON.stringify(json));
	},
	response_getmessagelist: function(messagelist) {
		var table = this.messages.appendChild( new Div({'class': 'table'}) ), row;

		messagelist.forEach(function(mail) {
			row = table.appendChild( new Div() );
			row.appendChild( new Div({'class': 'icon', 'size': '16', 'context': 'actions', 'name': 'mail-mark-read'}) );
			row.appendChild( new Div({'class': 'icon', 'size': '16', 'context': 'status', 'name': 'mail-attachment'}) );
			row.appendChild( new Div({'class': 'icon', 'size': '16', 'context': 'actions', 'name': 'mail-mark-important'}) );
			row.appendChild( new Div({'text': mail.From}) );
			row.appendChild( new Div({'text': mail.Subject}) );
			row.appendChild( new Div({'text': new Date(mail.Date).format('yyyy-mm-dd hh:mm')}) );
		},this);
	},
	download: function(event) {
	},
	document_new: function(event) {
	},
	document_reply: function(event) {
	},
	document_reply_all: function(event) {
	},
	document_forward: function(event) {
	},
	mailbox_open: function(event, which) {
	}
}))();
