new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);
		new Ajax({
			'onload': this.ajax_onload.bind(this),
			'onerror': this.ajax_onerror.bind(this)
		}).get('index.html');
	},
	ajax_onload: function(data) {
		this.text = data;
	},
	ajax_onerror: function(data) {
		alert(data);
	}
}))();
