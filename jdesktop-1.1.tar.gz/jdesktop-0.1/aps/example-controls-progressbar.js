new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		var progressbar = this.appendChild( new Progressbar() );
		Timer.setInterval(function(progressbar) {
			if (progressbar.value == 100) {
				progressbar.value = 0;
			}
			progressbar.value += 1;
		}.bind(this, progressbar), 100);
	}
}))();
