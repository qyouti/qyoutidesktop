/* LESSON 1                                                                 */
/* jDesktop applications can be created by extending the Application class. */
/* Once we have our own Application class we have to instantiate it.        */

new (Application.extend({
	init: function() {
		/* This is our constructor.                                                       */
		/* Constructor gets called whenever we instantiate a class.                       */
		/* We have to call the base constructor in order our base class could do its job. */
		Application.prototype.init.apply(this, arguments);

		/* here comes your code ...                                                       */
		this.text = 'Hello world!';
	}
}))();


