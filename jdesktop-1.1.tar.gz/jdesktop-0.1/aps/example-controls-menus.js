new (Application.extend({
	init: function() {
		Application.prototype.init.call(this);

		var fm = this.appendChild( new FileMenu() );

		var filemenu = fm.appendChild( new FileMenu.Item({'text': 'File'}) );
		var editmenu = fm.appendChild( new FileMenu.Item({'text': 'Edit'}) );
		var helpmenu = fm.appendChild( new FileMenu.Item({'text': 'Help'}) );

		filemenu = filemenu.appendChild( new DropdownMenu() );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-new', 'text': 'New', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'document-open', 'text': 'Open...', 'shortcut': 'Ctrl+O', 'onclick': this.document_open.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'download', 'text': 'Download', 'title': 'Download application for offline usage', 'shortcut': 'Ctrl+D', 'onclick': this.download.bind(this)}) );
		filemenu.appendChild( new DropdownMenu.Item({'icon': 'application-exit', 'text': 'Quit', 'title': 'Quit the application', 'shortcut': 'Ctrl+Q', 'onclick': this.close.bind(this)}) );

		editmenu = editmenu.appendChild( new DropdownMenu() );
		editmenu.appendChild( new DropdownMenu.Item({'icon': 'preferences-activities', 'text': 'menu'}) );		
		var preferences = editmenu.appendChild( new DropdownMenu.Item({'icon': 'preferences-activities', 'text': 'Preferences'}) );

		helpmenu = helpmenu.appendChild( new DropdownMenu() );
		helpmenu.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		preferences = preferences.appendChild( new DropdownMenu() );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );
		preferences.appendChild( new DropdownMenu.Item({'icon': 'help-about', 'text': 'About', 'shortcut': 'Ctrl+N', 'onclick': this.document_new.bind(this)}) );

		var im = this.appendChild( new IconMenu() );
		im.appendChild( new Button({'icon': 'document-new', 'onclick': this.document_new.bind(this)}) );
		im.appendChild( new Button({'text': 'Open', 'icon': 'document-open'}) );
		im.appendChild( new Button({'text': 'Save', 'icon': 'document-save'}) );


	},
	download: function(event) {
	},
	document_new: function(event) {
		new this.constructor();
	},
	document_open: function(event) {
	}
}))();
