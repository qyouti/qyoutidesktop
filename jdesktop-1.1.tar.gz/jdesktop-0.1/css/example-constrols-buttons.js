new (Application.extend({
	init: function() {
		/* This is our constructor.                                                       */
		/* Constructor gets called whenever we instantiate a class.                       */
		/* We have to call the base constructor in order our base class could do its job. */
		Application.prototype.init.apply(this, arguments);

		var btn = this.appendChild( new Button.RefreshButton({
			'text': 'Refresh view',
			'onclick': function() {
				btn.loading = !btn.loading;
				btn.text = btn.loading?'Cancel request':'Refresh view';
			}
		}) );

		var btn2 = this.appendChild( new Button.DatePicker({
			'text': 'Refresh view',
			'onchange': function() {
				tb.text = btn2.selectedDate.format('yyyy-mm-dd');
			}
		}) );

		var tb = this.appendChild( new Textbox() );

	}
}))();
