var div = new DivWrapper();
div.setAttribute('style', 'width: 100%; height: 100%; background-color: blue;');
div.text = '0000';
div.style.backgroundColor = 'green';
div.style.color='white';
div.style.textAlign = 'right';
div.style.transition = 'all 1s linear';
div.onmousemove = function(event) {
this.text = event.offsetX;
}.bind(div)

div.onclick = function(event) {
	this.style.color = 'red';
	alert(event.target);
}.bind(div)

document.body.appendChild(div.element);

document.body.appendChild(new FieldsetWrapper({
	legend: 'dslkfhalks',
	text: 'dfasdffasf',
	onclick: function(event) {
		alert(event.target);
		//event.target.checked = !event.target.checked;
	}
}).element);


