var Cls1 = (Class.extend({
	init: function() {
		Class.prototype.init.call(this);
		alert("Cls1.init");
	},
	property: {
		set: function(value) {
			alert('Cls1.property');
		}
	}
}))();

/*
var Cls2 = Cls1.extend({
	init: function() {
		Cls1.prototype.init.call(this);
		alert("Cls2.init");
	},
	property: {
		set: function(value) {
			Object.getOwnPropertyDescriptor(Cls1.prototype, 'property').set.call(this);
			alert('Cls2.property');
		}
	}
})




new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		var cls2 = new Cls2();
		cls2.property = '10';

	}
}))();
*/
