new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);

		var accordion = this.appendChild( new Accordion({
			'onchange': function() { /* FAIL nem keletkezik esemény */
				alert(accordion.selectedIndex); /* itt majd pl 0-át kell kiírni ha az választom ki */
				alert(accordion.childNodes[accordion.selectedIndex] == item1); /* itt ha az item1-et választom akkor true-t kell kiírni */
			}
		}) ); /* OK */

		var item1 = accordion.appendChild(new Accordion.Item() );
		item1.appendChild( new Div({'text': 'item1 tartalma'}) ); /* FAIL */
		item1.caption = 'item1';  /* FAIL */

		var item2 = accordion.appendChild(new Accordion.Item({'html':'item2 tartalma', 'caption':'item2'}));
		item2.html += '<br>item2 további tartalma'; /* OK, hozzáadja ugyan az új tartalmat de a régi méretre nyitja ki, az új tartalmat mintha már nem érzékelné hogy benne van*/

		var item3 = accordion.appendChild(new Accordion.Item({'html':'item3 tartalma', 'caption':'item3'}));
		item3.text += 'item3 további tartalma<br>'; /* OK */
	}
}))();

