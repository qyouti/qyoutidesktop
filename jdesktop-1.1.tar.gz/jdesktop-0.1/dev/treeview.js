/* LESSON 1 */
/* jDesktop applications can be created by extending the Application class. */
/* Once we have our own Application class we have to instantiate it. */
new (Application.extend({
init: function() {
/* This is our constructor. */
/* Constructor gets called whenever we instantiate a class. */
/* We have to call the base constructor in order our base class could do its job. */
Application.prototype.init.apply(this, arguments);
/* here comes your code ... */

	var tw2 = new TreeView({'label': 'subdir'});
	tw2.appendChild( new TreeView.Item({'text': 'item1'}) );
	tw2.appendChild( new TreeView.Item({'text': 'item2'}) );
	tw2.appendChild( new TreeView.Item({'text': 'item3'}) );

	var tw3 = new TreeView({'label': 'subdir2'});
	tw3.appendChild( new TreeView.Item({'text': 'item1'}) );
	tw3.appendChild( new TreeView.Item({'text': 'item2'}) );
	tw3.appendChild( new TreeView.Item({'text': 'item3'}) );

	var tw4 = new TreeView({'label': 'subdir3'});
	tw4.appendChild( new TreeView.Item({'text': 'item1'}) );
	tw4.appendChild( new TreeView.Item({'text': 'item2'}) );
	tw4.appendChild( new TreeView.Item({'text': 'item3'}) );


	var tw = this.appendChild( new TreeView({'label': 'root'}) );
	tw.appendChild( new TreeView.Item({'text': 'item1'}) );
	tw.appendChild( new TreeView.Item({'text': 'item2'}) );
	tw.appendChild( tw2 );
	tw.appendChild( new TreeView.Item({'text': 'item3'}) );
	tw.appendChild( tw3 );
	tw3.appendChild( tw4 );



/*
	var tw4 = this.appendChild( new Ul({'text': 'subdir3', 'style': 'list-style: circle'}) );
	tw4.appendChild( new Li({'text': 'item1', 'style': 'list-style: circle'}) );
	tw4.appendChild( new Li({'text': 'item2'}) );
	tw4.appendChild( new Li({'text': 'item3'}) );
*/


}
}))();

