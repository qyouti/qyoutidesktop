new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);
		var div = this.appendChild( new Div() );
		div.innerHTML = 'lédfjasléfjdslkfjaskldjf';

	}
}))();

