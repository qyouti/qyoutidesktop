/* LESSON 1                                                                 */
/* jDesktop applications can be created by extending the Application class. */
/* Once we have our own Application class we have to instantiate it.        */

new (Application.extend({
	init: function() {
		/* This is our constructor.                                                       */
		/* Constructor gets called whenever we instantiate a class.                       */
		/* We have to call the base constructor in order our base class could do its job. */
		Application.prototype.init.apply(this, arguments);
		CSS.load('dev/example-table.css');

		/* here comes your code ...                                                       */
		var table = this.appendChild( new Table({'rows': '10', 'cells': '10'}) );

		table.range(0,0,9,9).type = 'number';
		table.range(0,0,9,9).format = '0.00';

		table.cells[9][0].format = '0.0 MWh';


		table.range(0,0,8,0).onchange = function() {
			table.cells[9][0].value = table.range(0,0,8,0).sum();
		}

		table.range(0,0,8,9).value = 10.34563;

		
	}
}))();


