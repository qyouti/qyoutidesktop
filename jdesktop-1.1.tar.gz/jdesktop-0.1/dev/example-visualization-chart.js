/* LESSON 1                                                                 */
/* jDesktop applications can be created by extending the Application class. */
/* Once we have our own Application class we have to instantiate it.        */

var Types = Select.extend({
	init: function(p) {
		Select.prototype.init.call(this, p);
		this.appendChild( new Option({'text': 'Line Chart'}) );
		this.appendChild( new Option({'text': 'Area Chart'}) );
		this.appendChild( new Option({'text': 'Bar Chart'}) );
		this.appendChild( new Option({'text': 'Pie Chart'}) );
		this.appendChild( new Option({'text': 'Hidden'}) );
	}
});

new (Application.extend({
	init: function() {
		Application.prototype.init.apply(this, arguments);
		CSS.load('dev/example-chart.css');

		var table = new DataTable({
			'style': 'float: left; margin-left: 20px;',
			'rows': 4,
			'cells': 6,
			'contenteditable': 'true'
		});

		table.cells[0][0].value = '2008 January';
		table.cells[0][1].value = '2008 February';
		table.cells[0][2].value = '2008 March';
		table.cells[0][3].value = '2008 April';
		table.cells[0][4].value = '2008 May';


		table.cells[1][5].style.minWidth = '150px';
		table.cells[2][5].style.minWidth = '150px';
		table.cells[3][5].style.minWidth = '150px';
		table.cells[1][5].style.maxWidth = '150px';
		table.cells[2][5].style.maxWidth = '150px';
		table.cells[3][5].style.maxWidth = '150px';


		table.cells[1][5].appendChild( new Types({'onchange': update}) );
		table.cells[2][5].appendChild( new Types({'onchange': update}) );
		table.cells[3][5].appendChild( new Types({'onchange': update}) );

		table.range(1, 0, 3, 4).editable = true;
		table.range(0, 0, 3, 4).type = 'number';
		table.range(0, 0, 3, 4).format = '0.#';

		var value;
		for(var i=1; i<4; i++) {
			for(var j=0; j<5; j++) {
				value = Math.random()*100
				table.cells[i][j].setAttribute('title', value);
				table.cells[i][j].value = value;
			}
		}

		var chart = new Chart({
			'style': 'float: left',
			'width': '600',
			'height': '500'
		});

		chart.label.text = 'Production by Year';
		chart.legend.values = ['Company #1', 'Company #2', 'Company #3'];
		chart.xaxis.values = table.range(0, 0, 0, 4).toArray();
		chart.xaxis.label = 'Month';
		chart.xaxis.angel = -45;
		chart.yaxis.maximum = 100;
		chart.yaxis.steps = 11;
		chart.yaxis.format = '0';
		chart.yaxis.label = 'Production [MW]';

		var seriese1 = chart.appendChild( new Chart.Series() );
		var seriese2 = chart.appendChild( new Chart.Series() );
		var seriese3 = chart.appendChild( new Chart.Series() );


		function update() {
			seriese1.values = table.range(1, 0, 1, 4).toArray();
			seriese2.values = table.range(2, 0, 2, 4).toArray();
			seriese3.values = table.range(3, 0, 3, 4).toArray();

			var types = ['line', 'area', 'bar', 'pie', 'hidden'];
			seriese1.type = types[table.cells[1][5].firstChild.selectedIndex];
			seriese2.type = types[table.cells[2][5].firstChild.selectedIndex];
			seriese3.type = types[table.cells[3][5].firstChild.selectedIndex];

			chart.draw();
		}

		table.range(0, 0, 3, 4).onchange = update;

		this.appendChild( chart );
		this.appendChild( table );

		update();
	}
}))();


