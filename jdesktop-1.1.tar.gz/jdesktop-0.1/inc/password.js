var Password = JDESKTOPInputElement.extend({
	init: function(p) {
		JDESKTOPInputElement.prototype.init.call(this, p);
		this.setAttribute('type', 'password');
	},
	text: {
		set: function(value) {
			this.value = value
		},
		get: function(value) {
			return(this.value);
		}
	}
});

