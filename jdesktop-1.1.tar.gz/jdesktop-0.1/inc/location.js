var Location = new (Class.extend({
	init: function() {
	},
	getValue: function(option) {
		var url = top.location.toString();
		url = url.toString();
		if (url.split("?").length == 1) return(null);
		var options = url.split("?")[1].split("&");
		for (var i=0; i<options.length; i++)
			if (options[i].split("=")[0] == option)
				return(options[i].split("=")[1]);
		return(null);
	}
}))();

/*

*/
