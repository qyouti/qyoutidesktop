var TreeView = Ul.extend({
	static: {
		Item: Li.extend({
			init: function() {	
			}
		})
	},
	init: function(p) {
		this.addClassName('treeview');
		this.appendChild( new Li() );

		Ul.prototype.init.call(this, p);
	},
	label: {
		get: function() {
			return(this.firstChild.text);
		},
		set: function(value) {
			this.firstChild.text = value;
		}
	}
});

