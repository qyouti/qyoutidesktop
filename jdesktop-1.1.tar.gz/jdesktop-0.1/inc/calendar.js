var Calendar = Div.extend({
	init: function(p) {
		var p = p ? p : {};
		this.selectedDate = new Date();
		Div.prototype.init.call(this, p);
		this.addClassName('calendar')
		this.__build(null, p.date ? p.date : new Date());
	},
	__build: function(event, dt) {
		var t = [];
		while (this.hasChildNodes())
			this.removeChild(this.firstChild);
		
		var head = this.appendChild( new Div({
			"class": "head",
			"text": dt.format("yyyy mmmm")
		}) );

		head.appendChild( new Div({
			"class": "prev",
			"text": "<",
			"onclick": this.__build.bind(this, new Date(dt.getFullYear(), dt.getMonth()-1, dt.getDate()) )
		}) );

		head.appendChild( new Div({
			"class": "next",
			"text": ">",
			"onclick": this.__build.bind(this, new Date(dt.getFullYear(), dt.getMonth()+1, dt.getDate()) )
		}) );

		var table = new Div({"class": "table"});
		var row = table.appendChild( new Div() );
		row.appendChild( new Div({"text": "Su"}) );
		row.appendChild( new Div({"text": "Mo"}) );
		row.appendChild( new Div({"text": "Th"}) );
		row.appendChild( new Div({"text": "We"}) );
		row.appendChild( new Div({"text": "Th"}) );
		row.appendChild( new Div({"text": "Fr"}) );
		row.appendChild( new Div({"text": "Sa"}) );

                var dt = new Date(dt.getFullYear(), dt.getMonth(), 1);
                var today = new Date();

                for(var i=dt.getMonth(), w=dt.getWeek(); i==dt.getMonth(); dt.setDate(dt.getDate() + 1)) {
			if (table.childNodes[dt.getWeek()-w+1] === undefined) {
				row = table.appendChild( new Div() );
				for (var j=0; j<8; j++)
					row.appendChild( new Div({"style": "padding: 1px;"}) );

			}

			table.childNodes[dt.getWeek()-w+1].childNodes[dt.getDay()].appendChild( new Div({
				"class": dt==today?"currday":"day",
				"text": dt.getDate(),
				"onclick": function(event, dt) {
					this.selectedDate = dt;
					if (typeof this.onchange=="function")
						this.onchange();
				}.bind(this, new Date(dt))
			}) );
                }
		this.appendChild( table );
	}
});

