var Dialog = Div.extend({
	init: function(p) {

		this.__header = Div.prototype.appendChild.call(this, new Div() );
		this.__header = this.__header.appendChild( new Div({'class': 'header'}) );

		this.__header_icon = this.__header.appendChild( new Div({'class': 'icon', 'context': 'status', 'size': '22'}) );
		this.__header_text = this.__header.appendChild( new Div({'class': 'text'}) );

		this.__content = Div.prototype.appendChild.call(this, new Div() );
		this.__content = this.__content.appendChild( new Div({'class': 'content'}) );

		this.__buttons = Div.prototype.appendChild.call(this, new Div() );
		this.__buttons = this.__buttons.appendChild( new Div({'class': 'buttons'}) );

		if (p&&p.buttons) {
			this.setAttribute('hasbuttons', '');
			p.buttons.split(' ').forEach(function(text) {
				this.__buttons.appendChild( new Button({
					'text': text,
					'icon': ('dialog-'+text).toLowerCase(),
					'onclick': function(event, text) {
						if (typeof this.onchange=='function') {
							this.onchange(event, text);
						}
					}.bind(this, text)
				}) );
			}, this);
		}

		Div.prototype.init.call(this, p);
		this.addClassName('dialog');
	},
	caption: {
		set: function(value) {
			this.__header_text.text = value
		},
		get: function(value) {
			return(this.__header_text.text);
		}
	},
	icon: {
		set: function(value) {
			this.__header_icon.style.display = 'block';
			this.__header_icon.setAttribute('name', value);
		},
		get: function(value) {
			return(this.__header_icon.getAttribute('name'));
		}
	},
	text: {
		set: function(value) {
			this.__content.text = value
		},
		get: function(value) {
			return(this.__content.text);
		},
		configurable: true
	},
	html: {
		set: function(value) {
			this.__content.html = value
		},
		get: function(value) {
			return(this.__content.html);
		},
		configurable: true
	},
	appendChild: function(child) {
		return(this.__content.appendChild(child));
	},
	removeChild: function(child) {
		return(this.__content.removeChild(child));
	},
	show: function() {
		me.shadow = document.body.appendChild( new Div({'class': 'modal'}) );
		me.modalwrap = document.body.appendChild( new Div({'class': 'modalwrap'}) );
		me.dialog = me.modalwrap.appendChild(this);
		return(this);
	},
	close: function() {
		document.body.removeChild(me.modalwrap);
		document.body.removeChild(me.shadow);
	}
});


Dialog.information = Dialog.extend({
	init: function(p) {
		var p=p?p:{};
		p.buttons = 'Ok';
		p.icon = 'dialog-information';
		p.onchange = this.close.bind(this);
		Dialog.prototype.init.call(this, p);
	}
});

Dialog.warning = Dialog.extend({
	init: function(p) {
		var p=p?p:{};
		p.buttons = 'Ok';
		p.icon = 'dialog-warning';
		p.onchange = this.close.bind(this);
		Dialog.prototype.init.call(this, p);
	}
});

Dialog.error = Dialog.extend({
	init: function(p) {
		var p=p?p:{};
		p.buttons = 'Ok';
		p.icon = 'dialog-error';
		p.onchange = this.close.bind(this);
		Dialog.prototype.init.call(this, p);
	}
});

Dialog.password = Dialog.extend({
	init: function(p) {
		var p=p?p:{};

		this.__username = new Textbox({
			'style': 'margin-bottom: 0.5em',
			'onchange': function(event) {
				event.stopPropagation();
			}
		});

		this.__password = new Password({
			'onchange': function(event) {
				event.stopPropagation();
			}
		});

		p.buttons = 'Ok Cancel';
		p.type = 'password';
		p.caption = 'Authentication required';
		p.icon = 'dialog-password';

		Dialog.prototype.init.call(this, p);

		this.appendChild( new Div({
			'style': 'margin-bottom: 1em; clear: both;',
			'text': 'Authentication is required to access the application.'
		}) );

		this.appendChild( new Div({
			'class': 'icon',
			'context': 'status',
			'size': '128',
			'name': 'security-medium',
			'style': 'float: right; margin-left: 1em;'
		}) );

		var wrap = this.appendChild( new Div({'style': 'float: left;'}) );

		wrap.appendChild( new Div({'text': 'username:'}) );
		wrap.appendChild( this.__username );

		wrap.appendChild( new Div({'text': 'password:'}) );
		wrap.appendChild( this.__password );
	},
	username: {
		get: function() {
			return(this.__username.text);
		},
		set: function(value) {
			this.__username.text = value;
		}
	},
	password: {
		get: function() {
			return(this.__password.text);
		},
		set: function(value) {
			this.__password.text = value;
		}
	}
});

Dialog.loader = Dialog.extend({
	init: function(p) {
		var p=p?p:{};

		this.setAttribute('type', 'loader');

		p.buttons = 'Cancel';
		p.type = 'loader';
		p.icon = 'user-away';

		this.__message = new Div({'class': 'message'});

		Dialog.prototype.init.call(this, p);

		this.appendChild(this.__message);
		this.appendChild( new Div({'class': 'ajax-loader-wrap'}) ).appendChild( new Div({'class': 'ajax-loader'}) );
	},
	text: {
		set: function(value) {
			this.__message.text = value
		},
		get: function(value) {
			return(this.__message.text);
		}
	},
	html: {
		set: function(value) {
			this.__message.html = value
		},
		get: function(value) {
			return(this.__message.html);
		}
	},

});

Dialog.fileBrowser = Dialog.extend({
	init: function(p) {
		var p=p?p:{};

		p.buttons = 'Ok Cancel';
		p.type = 'filebrowser';
		p.icon = 'user-away';


		Dialog.prototype.init.call(this, p);

		var top = this.appendChild( new Div({'class': 'top'}) );
		top.appendChild( new Div({'class': 'label', 'text': 'Look in:'}) );
		top.appendChild( new Div({'class': 'btns'}) );

	},
	text: {
		set: function(value) {
			this.__message.text = value
		},
		get: function(value) {
			return(this.__message.text);
		}
	},
	html: {
		set: function(value) {
			this.__message.html = value
		},
		get: function(value) {
			return(this.__message.html);
		}
	},

});

