var Fieldset = JDESKTOPFieldsetElement.extend({
	init: function(p) {
		this.__legend = JDESKTOPFieldsetElement.prototype.appendChild.call(this, new Legend());
		this.__div = JDESKTOPFieldsetElement.prototype.appendChild.call(this, new Div());
		JDESKTOPFieldsetElement.prototype.init.call(this, p);
	},
	childNodes: {
		get: function() {
			return(this.__div.childNodes);
		}
	},
	hasChildNodes: function() {
		return(this.__div.hasChildNodes());
	},
	appendChild: function(child) {
		return(this.__div.appendChild(child));
	},
	removeChild: function(child) {
		this.__div.removeChild(child);
	},
	firstChild: {
		get: function() {
			return(this.__div.firstChild);
		}
	},
	lastChild: {
		get: function() {
			return(this.__div.lastChild);
		}
	},
	text: {
		set: function(value) {
			this.__div.textContent = value
		},
		get: function(value) {
			return(this.__div.textContent = value);
		}
	},
	legend: {
		set: function(value) {
			this.__legend.textContent = value
		},
		get: function(value) {
			return(this.__legend.textContent);
		}
	}
});

