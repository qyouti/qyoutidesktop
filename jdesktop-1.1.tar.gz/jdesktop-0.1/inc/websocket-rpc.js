var WebSocketRPC = Class.extend({
	init: function(p) {
		this.websocket = new WebSocket(p.host);
		Class.prototype.init.call(this, p);
		this.websocket.onmessage = this.onmessage.bind(this);
		this.websocket.onopen = this.websocket_onopen.bind(this);

	},
	websocket_onopen: function() {
	},
	rcall: function() {
		var args = Array.prototype.slice.call(arguments);
		var method = args.pop();
		var rcall = {
			'method': method,
			'params': args 
		};
		
		//alert(JSON.stringify(rcall));
		this.websocket.send(JSON.stringify(rcall));
	},
	side: 'client',
	onmessage: function(data) {
		if (this.schema) {
			var rcall = JSON.parse(data.data);

			var result = JSON.validate(rcall.params, {
				'type': 'array',
				'items': this.remoteMethodSchemas[rcall.method]
			});

			if (typeof this[rcall.method] == 'function')
				this[rcall.method].apply(this, rcall.params);

		} else {
			this.schema = JSON.parse(data.data);
			this.remoteMethodSchemas = {}
			this.schema.forEach(function(e) {
				if (this.side==e.side) {
					this.remoteMethodSchemas[e.method] = e.params;
				} else {
					this[e.method] = this.rcall.bind(this, e.method);
				}
			},this);

			if (typeof this.onopen == 'function')
				this.onopen();
		}

		//var json = JSON.parse(data.data);

/*		alert(rcall.method);
		alert(JSON.stringify(this.remoteMethodSchemas[rcall.method]));*/
		//alert(result.errors.length);

		/*alert(json.params[0]);
		alert(result.errors[0].message);*/
	},
	onerrormessage: function() {
	}
});

/*
var esocket = new MyWebSocketRPC();
esocket.signIn('userid', 'password');
esocket.onmessage('{"method": "signInResult", "params": [true]}');
*/

