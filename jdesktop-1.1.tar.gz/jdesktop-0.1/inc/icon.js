var Icon = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('icon');
	}
});

