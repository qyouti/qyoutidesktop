

var DataTable = Div.extend({
	static: {
		Cell: Div.extend({
			init: function(p) {
				Div.prototype.init.call(this, p);
			},
			value: {
				set: function(value) {
					switch(this.type) {
						case 'string':
							this.__value = new String(value);
							this.text = this.__value;
						break;
						case 'number':
							this.__value = new Number(value);
							this.text = this.__value.format(this.format);
						break;
						case 'date':
							this.__value = new Date(value);
							this.text = this.__value.format(this.format);
						break;
					}

					if (typeof this.onchange=='function') {
						this.onchange();
					}
				},
				get: function() {
					return(this.__value);
				}
			},
			onmousedown: function(event) {
				if (!this.editable) {
					return;
				}
				if (this.getAttribute('contenteditable') == 'true') { return; }
				this.setAttribute('contenteditable', 'true');
			},
			onblur: function() {
				if (!this.editable) {
					return;
				}

				this.setAttribute('contenteditable', 'false');
				this.value = this.text;
			},
			__value: '',
			type: 'string',
			format: '',
			editable: false
		}),
		Range: Class.extend({
			init: function(parent, row1, cell1, row2, cell2) {
				this.cells = [];
				for (var i=row1;i<=row2;i++) {
					var row = [];
					this.cells.push(row);
					for (var j=cell1;j<=cell2;j++) {
						row.push(parent.cells[i][j]);
					}
				}
			},
			toArray: function() {
				var array = [];
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						array.push(e.value);
					});
				});
				return(array);
			},
			value: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.value = value;
						});
					});
				}
			},
			type: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.type = value;
						});
					});
				}
			},
			format: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.format = value;
						});
					});
				}
			},
			editable: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.editable = value;
						});
					});
				}
			},
			sum: function() {
				var sum = 0;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						sum += e.value?e.value:0;
					});
				});
				return(sum);
			},
			avg: function() {
				return(this.sum/(this.cells.length*this.cells[0].length));
			},
			max: function() {
				var max = 0;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						if (e.value>max) {
							max = e.value;
						}
					});
				});
				return(max);
			},
			min: function() {
				var min = 99999999999999;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						if (e.value<min) {
							min = e.value;
						}
					});
				});

				return(min);
			},
			/* events */
			onchange: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.onchange = value;
						});
					});
				}
			}
		})

	},
	init: function(p) {
		if (p&&p.contenteditable) {
			this.editable = true;
			delete p.contenteditable;
		}
		Div.prototype.init.call(this, p);
		this.addClassName('table');

		var rows = p.rows;
		var cells = p.cells;

		this.cells=[];
		for(var i=0; i<rows; i++) {
			var row = this.appendChild( new Div() );
			var rowArray = [];
			this.cells.push(rowArray);
			for(var j=0, cell; j<cells; j++) {
				cell = row.appendChild( new DataTable.Cell() );
				rowArray.push(cell);
			}
		}
	},
	range: function(row1, cell1, row2, cell2) {
		return(new DataTable.Range(this, row1, cell1, row2, cell2));
	}
});


