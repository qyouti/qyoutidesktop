var Div = JDESKTOPDivElement.extend({
	init: function(p) {
		JDESKTOPDivElement.prototype.init.call(this, p);
	}/*,
	text: {
		set: function(value) {
			this.textContent = value
		},
		get: function(value) {
			return(this.textContent);
		}
	}*/
});

