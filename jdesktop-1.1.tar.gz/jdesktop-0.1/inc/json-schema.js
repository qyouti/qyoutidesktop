JSON.validate = function(json, schema) {
	var env = JSV.createEnvironment('json-schema-draft-03');
	return(env.validate(json, schema));
}


