var Highlightarea = Div.extend({
	static: {
		init: function() {
			document.addEventListener("keydown", this.keydown.bind(this), false);
			//document.addEventListener("keypress", this.keypress.bind(this), false);
			//document.addEventListener("keyup", this.keyup.bind(this), false);
		},
		keydown: function(event) {
			if (document.activeElement.constructor!==Highlightarea)
				return;

			var ha = document.activeElement;
			ha.delkey = false;
			ha.__enableHighlighting = false;
			switch (event.which) {
				case 9: /* TAB */
					document.execCommand("insertHTML", false, "\t");
					event.preventDefault();
					event.stopPropagation();
					return(false);
				break;
				case 46:
					ha.delkey = true;
				break;
				case 8: /* BACKSPACE */
					ha.delkey = true;
/*
					var cursor = ha.getCursor();

					if (!cursor.y&&!cursor.x) {
						event.preventDefault();
						event.stopPropagation();
						return(false);
					}

					if (cursor.x == 0) {
						var line0 = ha.childNodes[cursor.y-1].text;
						var line1 = ha.childNodes[cursor.y].text;
						ha.childNodes[cursor.y-1].html = ha.highlight(line0 + line1);
						ha.removeChild(ha.childNodes[cursor.y]);

						cursor.y--;
						cursor.x = line0.length;
						ha.setCursor(cursor);
						event.preventDefault();
						event.stopPropagation();
					}
*/
				break;
				case 13: /* ENTER */
					var cursor = ha.getCursor();
					var pre = ha.insertBefore(new Div(), ha.childNodes[cursor.y].nextSibling);
					var line = ha.childNodes[cursor.y].textContent;
					ha.childNodes[cursor.y].innerHTML = ha.highlight(line.substring(0, cursor.x));

					var indent = Highlightarea.__repeat("\t", /^(\t*)/.exec(line)[0].length);
					pre.innerHTML = ha.highlight(indent+line.substring(cursor.x));
					ha.setCursor({"x": indent.length, "y": cursor.y+1});

					event.preventDefault();
					event.stopPropagation();
					ha.__enableHighlighting = true;
					return(false);
				break;
			}
			ha.__enableHighlighting = true;
		},
		keypress: function(event) {
			if (!document.activeElement.isHighlightarea)
				return;
			if (event.which == 9 && event.which==13) {
				event.preventDefault();
				event.stopPropagation();
				event.returnValue = false;
				return(false);
			}
		},
		keyup: function(event) {
			if (document.activeElement.constructor!==Highlightarea)
				return;

			if ([13,15,16,18,33,34,35,36,37,38,39,40].contains(event.which))
				return;

/*
			var ha = document.activeElement;

			var cursor = ha.getCursor();
			ha.childNodes[cursor.y].innerHTML = ha.highlight(ha.childNodes[cursor.y].textContent);
			ha.setCursor(cursor);
*/
		},
		__repeat: function(c, n) {
			var str="";
			for(var i=0;i<n;i++)
				str+=c;
			return(str);
		}
	},
	"init": function(p) {

		if (p&&p.oncursormove) {
			this.oncursormove = p.oncursormove;
			delete p.oncursormove;
		}

		Div.prototype.init.apply(this, arguments);
		this.addClassName("highlightarea");
		this.setAttribute("contenteditable", "true");
		this.setAttribute("spellcheck", "false");
	
		this.DOMSubtreeModified_handler_function = this.DOMSubtreeModified_handler.bind(this);
		this.addEventListener('DOMSubtreeModified', this.DOMSubtreeModified_handler_function, false);

		if (Environment.layoutengine=='presto')
			document.addEventListener('keyup', this.DOMSubtreeModified_handler_function, true);

		this.disable = false;

		this.text = '';
	},
	__enableHighlighting: {
		set: function(value) {
			if (value) {
				this.addEventListener('DOMSubtreeModified', this.DOMSubtreeModified_handler_function, false);
			} else {
				this.removeEventListener('DOMSubtreeModified', this.DOMSubtreeModified_handler_function, false);
			}
		}
	},
	DOMSubtreeModified_handler: function(event) {
		this.__enableHighlighting = false;
		var cursor = this.getCursor();

		var line = this.childNodes[cursor.y];
/*
		if (!(line instanceof Div)) {
			do {
				line = line.parentNode;
			} while(!(line instanceof Div));
		}
*/

		line.html = this.highlight(line.text);
		if (Environment.layoutengine == 'gecko'&&!this.delkey) cursor.x++;
		this.setCursor(cursor);
		this.__enableHighlighting = true;
	},
	text: {
		get: function() {
			var str = ""
			for (var i=0, len=this.childNodes.length; i<len; i++)
				str += this.childNodes[i].textContent + "\n";
			return(str);
		},
		set: function(value) {
			this.__enableHighlighting = false;
			while (this.hasChildNodes()) {
				this.removeChild(this.firstChild);
			}

			value.split("\n").forEach(function(e, i) {
				/*var pre = document.createElement('pre');
				pre.innerHTML = this.highlight(e);
				this.appendChild( pre );*/
				this.appendChild( new Div({'html': this.highlight(e)}) );
			}, this);

			/* last line */
			this.appendChild( new Div() );

			this.__enableHighlighting = true;
		}		
	},
	highlight: function(text) {
		var regexps = [
			/"(?:\\"|.)*?"/g,
			/'(?:\\'|.)*?'/g,
			/* comments */
			/\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*\/+/g,
			/* reserved keywords */
			/\b(break|continue|do|for|new|this|void|case|default|else|function|in|return|typeof|while|delete|if|switch|var|with|length|self|init|static|instanceof|try|catch|get|set|value|writable|configurable|enumerable)\b/g,
			/* properties */
			/\b(prototype|constructor)\b/g,
			/* built in methods */
			/\b(toExponential|toFixed|toLocaleString|toPrecision|toString|valueOf|charCodeAt|concat|indexOf|lastIndexOf|localeCompare|match|replace|search|slice|split|substr|substring|toLocaleLowerCase|toLocaleUpperCase|toLowerCase|toString|toUpperCase|valueOf|anchor|big|blink|bold|fixed|fontcolor|fontsize|italics|link|small|strike|sub|sup|concat|every|filter|forEach|indexOf|join|lastIndexOf|map|pop|push|reduce|reduceRight|reverse|shift|slice|some|toSource|sort|splice|toString|unshift|Date|getDate|getDay|getFullYear|getHours|getMilliseconds|getMinutes|getMonth|getSeconds|getTime|getTimezoneOffset|getUTCDate|getUTCDay|getUTCFullYear|getUTCHours|getUTCMilliseconds|getUTCMinutes|getUTCMonth|getUTCSeconds|getYear|setDate|setFullYear|setHours|setMilliseconds|setMinutes|setMonth|setSeconds|setTime|setUTCDate|setUTCFullYear|setUTCHours|setUTCMilliseconds|setUTCMinutes|setUTCMonth|setUTCSeconds|setYear|toDateString|toGMTString|toLocaleDateString|toLocaleFormat|toLocaleString|toLocaleTimeString|toSource|toString|toTimeString|toUTCString|valueOf|abs|acos|asin|atan|atan2|ceil|cos|exp|floor|log|max|min|pow|random|round|sin|sqrt|tan|exec|test|bind|extend|call|apply)\b/g,
			/* classes */
			/\b(Object|Class|Element|Div|Tab|Textbox|Calendar|Checkbox|Password|Textarea|Messagebox|Button|Richbox|Dialog|File|FileHandler|Slot|Applet|Application)\b/g
			/* strings */
		]

		var classes = [
			"string",
			"string",
			"comment",
			"reserved",
			"property",
			"method",
			"class"
		];

		text = text.replace(/\</g, "&lt;");

		for (var i=0, e=[], x; i<regexps.length; i++) {
			text=text.replace(regexps[i], function(s) {
				return("<span class=\"highlight\" id=\"$\">$</span>".$(classes[i], s));
			} );
		}

		return(text);
	},
	cursorY: {
		get: function() {
			for (var i=0, childNodes=this.childNodes; i<childNodes.length; i++) {
				var cursorPos = this.getCursorPos(childNodes[i]);
				if (typeof cursorPos == 'number')
					return(i);
			}
		}
	},
	cursorX: {
		get: function() {
			return(this.getCursorPos(this.childNodes[this.cursorY]));
		}
	},
	getCursorPos: function(node) {
		var selObj = window.getSelection();
		var obj = selObj.anchorNode;
		var cursorPos = 0;
		var ret = null;
		DOM.traverse(node, function(node) {
			if (node==obj) {
				cursorPos += selObj.anchorOffset;
				ret = cursorPos;
				return(false);
			} else {
				if (node.nodeType == Node.TEXT_NODE) {
					cursorPos += node.textContent.length;
				}
				return(true);
			}
		});
		return(ret);
	},
	setCursor: function(cursor) {
		var sel = window.getSelection();
		var lineNode = this.childNodes[cursor.y];
		if (!lineNode.hasChildNodes()) {
			/* set the cursor on the div node */
			sel.collapse(lineNode, 0)
		} else {
			DOM.traverse(this.childNodes[cursor.y], function(node) {
				if (node.nodeType != Node.TEXT_NODE) return(true);

				if(node.textContent.length>=cursor.x) {
					sel.collapse(node, cursor.x);
					return(false);
				} else {
					cursor.x -= node.textContent.length;
					return(true);
				}
			});
		}
	},
	getCursor: function() {
		return({
			"x": this.cursorX,
			"y": this.cursorY
		});
	},
	mark: function(line) {
		this.childNodes[line].setAttribute("marked", "true");
	},
	unmark: function(line) {
		Array.prototype.slice.call(this.childNodes).forEach(function(e) {
			e.setAttribute("marked", "false");
		}, this);
	},
	insertCode: function(code) {
		var cursor = this.getCursor();
		code.split("\n").forEach(function(e, i) {
			var pre = i?this.insertBefore(document.createElement("pre"), this.childNodes[cursor.y].nextSibling):this.childNodes[this.getCursor().y];
			pre.innerHTML = this.highlight(pre.textContent + e);
			cursor.y++;
		}, this);
	},
	isHighlightarea: true
});

