var DateButton = Button.extend({
	static: {
		init: function() {
			//me.addEventListener('mousedown', this.click, false);
			document.addEventListener('mousedown', this.mousedown, false);
		},
		mousedown: function(event) {
			if (window.me&&window.me.calendar) {
				if (!event.hasTarget(me.calendar)) {
					me.removeChild(me.calendar);
					delete me.calendar;
				}
			}
		}
	},
	init: function(p) {
		Button.prototype.init.call(this, p);
		this.icon = 'view-calendar';
	},
	click_handler: function(event) {
		me.calendar = me.appendChild( new Calendar({
			'text': 'Select Date',
			'style': 'position: fixed; top: $px; left: $px'.$(this.positionY+this.offsetHeight, this.positionX),
			'onchange': function(event) {
				this.text=me.calendar.selectedDate.format('yyyy-mm-dd');
				this.selectedDate = me.calendar.selectedDate;
				if (typeof this.onchange=='function') {
					this.onchange(event);
				}
				me.removeChild(me.calendar);
				delete me.calendar;
			}.bind(this)
		}) );
	}
});

