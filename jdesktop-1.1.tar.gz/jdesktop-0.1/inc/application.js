var Application = JDESKTOPDivElement.extend({
	static: {
		execute: function(p) {
			if (p.source) {
				this.__execute(p.source, p);
			};

			if (p.path) {
				var ajax = new Ajax({
					onload: function(source) {
						this.__execute(source, p);
					}.bind(this)
				});

				ajax.get(p.path);
			};

		},
		__execute: function(source, p) {
			source = '(function(){var mine={};'+source+'})();';

			if (p.newWindow) {
				var application = window.open('loadapp.html?id=$'.$(String.random(10)), "", "menubar=0, resizable=1, width=640, height=480");
				Timer.setTimeout(function() {
					if (application.document.getElementById('script')) {
						application.document.getElementById('script').textContent = source;
					} else {
						Timer.setTimeout(arguments.callee, 10);
					}
				}, 10);
			} else {
				eval(source);
				if (typeof p.onload=='function') {
					p.onload();
				}
			}
		}
	},
	init: function(p) {
		if (window.me) {
			window.open('$?id=$'.$(top.location, String.random(10)), "", "menubar=0, resizable=1, width=350, height=250");
		} else {
			JDESKTOPDivElement.prototype.init.call(this, p);
			this.addClassName('application');
			document.body.appendChild(this);
			this.__content = JDESKTOPDivElement.prototype.appendChild.call(this, new Div({'class': 'content'}) );
			me = this;
		}

		this.contextmenu = [
			{
				'icon': 'go-previous',
				'text': 'Back',
				'onclick': function() {
					window.history.back();
			} },
			{
				'icon': 'go-next',
				'text': 'Forward',
				'onclick': function() {
					window.history.forward();
			} },
			{
				'icon': 'view-refresh',
				'text': 'Reload',
				'onclick': function() {
					window.history.go(0);
			} },
			{
				'icon': 'document-print',
				'text': 'Print...',
				'onclick': function() {
					window.print();
			} },
			{
				'icon': 'document-edit-verify',
				'text': 'View Application Source',
				'onclick': function() {
					var dialog = new Dialog.information({
						'style': 'width: 98%;',
						'caption': 'Application Source'
					});

					var highlightarea = dialog.appendChild( new Highlightarea() );
					highlightarea.text = 'TODO';

					dialog.show();
			} },
		];

	},
	appendChild: function(child) {
		if (child instanceof FileMenu) this.setAttribute('filemenu', 'true');
		if (child instanceof IconMenu) this.setAttribute('iconmenu', 'true');
		if ((child instanceof FileMenu) || (child instanceof IconMenu)) {
			JDESKTOPDivElement.prototype.appendChild.call(this, child);
		} else {
			this.__content.appendChild(child);
		}
		return(child);
	},
	removeChild: function(child) {
		if (child instanceof FileMenu) this.removeAttribute('filemenu');
		if (child instanceof IconMenu) this.removeAttribute('iconmenu');
		if ((child instanceof FileMenu) || (child instanceof IconMenu)) {
			JDESKTOPDivElement.prototype.removeChild.call(this, child);
		} else {
			this.__content.removeChild(child);
		}
		return(child);
	},
	text: {
		set: function(value) {
			this.__content.text = value
		},
		get: function() {
			return(this.__content.text);
		}
	},
	html: {
		set: function(value) {
			this.__content.html = value
		},
		get: function() {
			return(this.__content.html);
		}
	},
	moveTo: function(x, y) {
		window.moveTo(x, y);
	},
	resizeTo: function(w ,h) {
		window.resizeTo(w, h);
	},
	close: function() {
		window.close();
	},
	onkeydown: {
		set: function(value) {
			document.onkeydown = value.bind(this);
		},
		get: function(value) {
			return(document.onkeydown);
		}
	},
	onkeyup: {
		set: function(value) {
			document.onkeyup = value.bind(this);
		},
		get: function(value) {
			return(document.onkeyup);
		}
	},
	onkeypress: {
		set: function(value) {
			document.onkeypress = value.bind(this);
		},
		get: function(value) {
			return(document.onkeypress);
		}
	},
	onmousemove: {
		set: function(value) {
			document.onmousemove = value.bind(this);
		},
		get: function(value) {
			return(document.onmousemove);
		}
	}
});

