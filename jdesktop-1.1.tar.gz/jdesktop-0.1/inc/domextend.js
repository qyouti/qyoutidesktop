elements = ['HTMLBodyElement', 'HTMLDivElement', 'HTMLButtonElement', 'HTMLInputElement', 'HTMLLegendElement', 'HTMLFieldsetElement', 'HTMLLabelElement', 'HTMLCanvasElement', 'HTMLSelectElement', 'HTMLOptionElement', 'HTMLULElement', 'HTMLLIElement'];

elements.forEach(function(element) {
	var JDESKTOP = element.replace('HTML', 'JDESKTOP');
	var DOM = element.replace('HTML', '').replace('Element', '').toLowerCase();

	window[JDESKTOP] = function(p) {
		var element = document.createElement(arguments.callee.element);
/*TODO remove sztem ez nem kell ide, init() ben van */
		for (var key in p) {
			if (key.match("^on")) {
				element[key] = p[key];
			} else if (Object.getOwnPropertyNames(element).contains(key)) {
				element[key] = p[key];
			} else {
				element.setAttribute(key, p[key]);
			}
		}


		return(element);
	}

	window[JDESKTOP].element = DOM;
	window[JDESKTOP].prototypes = [];
	window[JDESKTOP].prototype = document.createElement(DOM);

	window[JDESKTOP].prototype.init = function(p) {
		for (key in this) {
			if (key.endsWith('_handler') && typeof this[key] == 'function') {
				var event = 'on'+key.replace('_handler', '');
				this[event] = this[key];
			}
		}


		for (var key in p) {
			if (key.match("^on")) {
				this[key] = p[key];
			/* TODO this[key]!==undefined:  ha a gettersetter-nem nincs get definiálva akkor az undefinedet ad vissza, így olyan mintha
			   az nem is lenne, közben van!!!
			*/
			} else if (this[key]!==undefined && key!=='style')/*((Object.getOwnPropertyNames(Element.prototype).contains(key) || Object.getOwnPropertyNames(this).contains(key)) && (key!='style'))*/ {
				this[key] = p[key];
			} else {
				this.setAttribute(key, p[key]);
			}
		}
	}

	window[JDESKTOP].extend = function(p) {
		function Cls() {
			var element = document.createElement(arguments.callee.element);
			element.__proto__ = arguments.callee.prototype;

			arguments.callee.prototypes.forEach(function(prototype) {
				for (var key in prototype) {
					if (!prototype.hasOwnProperty(key)) continue;
					/* 
					if (key.match("^on")) {
						element[key] = prototype[key];
					}*/
					if ((prototype[key]) && (prototype[key].get || prototype[key].set)) {
						/* safari div.onclick property is not configurable */
						try {
							Object.defineProperty(element, key, prototype[key]);
						} catch(e) {}
					}
				}
			}, this);
			element.constructor = arguments.callee;
			if (typeof element.init == "function") element.init.apply(element, arguments);
			return(element);
		}

		for (var key in p['static']) {
			if ((p['static'][key]) && (p['static'][key].get || p['static'][key].set)) {
				Object.defineProperty(Cls, key, p['static'][key]);
			} else {
				Cls[key] = p['static'][key];
			}
		}

		Cls.extend = arguments.callee;
		p.__proto__ = this.prototype;
		Cls.prototype = p;
		Cls.prototypes = this.prototypes.concat([Cls.prototype]);
		Cls.element = this.element;

		if (p['static']&&typeof p['static']['init'] == 'function') {
			p['static']['init'].call(Cls);
		}

		return Cls;
	}
});
