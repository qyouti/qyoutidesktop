var LocalStorage = new (Class.extend({
	init: function() {
		if (!window.localStorage) {
			localStorage = {}
		}
	},
	getItem: function(item) {
		return(localStorage[item]);
	},
	setItem: function(item, value) {
		localStorage[item] = value;
	},
	removeItem: function(item) {
		delete localStorage[item];
	}
}))();

