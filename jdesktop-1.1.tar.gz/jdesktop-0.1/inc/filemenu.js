var FileMenu = Div.extend({
	static: {
		Item: Div.extend({
			init: function(p) {
				Div.prototype.init.call(this, p);
				Div.prototype.appendChild.call(this, new Div({'class': 'dropdown'}) );
			},
			appendChild: function(child) {
				this.lastChild.appendChild(child);
				return(child);
			}
		}),
		submenu: null,
		show: false
	},
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('filemenu');
	}
});

