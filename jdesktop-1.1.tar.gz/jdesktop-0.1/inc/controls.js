var Controls = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('controls');
		if (!(p&&p.buttons)) {
			this.buttons = this.button_list;
		}
	},
	execCommand: function(event, command) {
		document.execCommand(command, null, false);
	},
	button_object: function(button) {
		return({
			'bold': new Button({'transparent': '', 'icon': 'format-text-bold', 'onclick': this.execCommand.bind(this, 'bold')}),
			'italic': new Button({'transparent': '', 'icon': 'format-text-italic', 'onclick': this.execCommand.bind(this, 'italic')}),
			'underline': new Button({'transparent': '', 'icon': 'format-text-underline', 'onclick': this.execCommand.bind(this, 'underline')}),
			'strikeThrough': new Button({'transparent': '', 'icon': 'format-text-strikethrough', 'onclick': this.execCommand.bind(this, 'strikeThrough')}),
			'justifyLeft': new Button({'transparent': '', 'icon': 'format-justify-left', 'onclick': this.execCommand.bind(this, 'left')}),
			'justifyCenter': new Button({'transparent': '', 'icon': 'format-justify-center', 'onclick': this.execCommand.bind(this, 'center')}),
			'justifyRight': new Button({'transparent': '', 'icon': 'format-justify-right', 'onclick': this.execCommand.bind(this, 'right')}),
			'justifyFill': new Button({'transparent': '', 'icon': 'format-justify-fill', 'onclick': this.execCommand.bind(this, 'fill')}),
			'insertOrderedList': new Button({'transparent': '', 'icon': 'format-list-ordered', 'onclick': this.execCommand.bind(this, 'insertOrderedList')}),
			'insertUnorderedList': new Button({'transparent': '', 'icon': 'format-list-unordered', 'onclick': this.execCommand.bind(this, 'insertUnorderedList')}),
			'indent': new Button({'transparent': '', 'icon': 'format-indent-more', 'onclick': this.execCommand.bind(this, 'indent')}),
			'outdent': new Button({'transparent': '', 'icon': 'format-indent-less', 'onclick': this.execCommand.bind(this, 'outdent')}),
			'undo': new Button({'transparent': '', 'icon': 'edit-undo', 'onclick': this.execCommand.bind(this, 'undo')}),
			'redo': new Button({'transparent': '', 'icon': 'edit-redo', 'onclick': this.execCommand.bind(this, 'redo')}),
			'verticalRuler': new Vr()
		}[button]);
	},
	button_list: [
		'bold',	
		'italic',
		'underline',
		'strikeThrough',
		'verticalRuler',
		'justifyLeft',
		'justifyCenter',
		'justifyRight',
		'justifyFill',
		'verticalRuler',
		'insertOrderedList',
		'insertUnorderedList',
		'verticalRuler',
		'indent',
		'outdent',
		'verticalRuler',
		'undo',
		'redo'
	],
	buttons: {
		set: function(buttons) {
			buttons.forEach(function(button) {
				this.appendChild(this.button_object(button));
			}, this);
		}
	}
});

