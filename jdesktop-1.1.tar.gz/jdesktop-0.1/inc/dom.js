var DOM = new (Class.extend({
	init: function() {
		Class.prototype.init.apply(this, arguments);
	},
	traverse: function(node, f) {
		var nodes = [node];

		do {
			if (!f(nodes[0])) break;
			var oldNode = nodes.shift();
			if (oldNode.hasChildNodes()) {
				var newNodes = Array.prototype.slice.call(oldNode.childNodes);
				nodes.unshift.apply(nodes, newNodes);
			}
		} while(nodes.length);
	},
	offsetX: function(node, ancestor) {
		var curleft = 0;
		if (node.offsetParent) {
			do {
				curleft += node.offsetLeft-node.scrollLeft;
			} while ((node!=ancestor)&&(node = node.offsetParent));
		}
		return curleft;
	}
}))();

