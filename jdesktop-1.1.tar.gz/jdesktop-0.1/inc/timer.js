/* https://bugzilla.mozilla.org/show_bug.cgi?id=10637 */
/* bug is WONTFIX */
/* firefox has an extra lateness parameter, Opera and Chrome do not have */

var Timer = new (Class.extend({
	init : function() {},
	setTimeout: function(func, delay) {
		var func = Environment.browser=="Firefox" ? function(lateness, func) { func.call(self); }.bind(self, func) : func;
		return(setTimeout(func, delay));
	},
	clearTimeout: function(timeoutID) {
		clearTimeout(timeoutID);
	},
	setInterval: function(func, delay) {
		var func = Environment.browser=="Firefox" ? function(lateness, func) { func.call(self); }.bind(self, func) : func;
		return(setInterval(func, delay));
	},
	clearInterval: function(timeoutID) {
		clearInterval(timeoutID);
	}
}))();

