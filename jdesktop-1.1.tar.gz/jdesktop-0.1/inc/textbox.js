var Textbox = JDESKTOPInputElement.extend({
	init: function(p) {
		JDESKTOPInputElement.prototype.init.call(this, p);
		this.setAttribute('type', 'text');
	},
	text: {
		set: function(value) {
			this.value = value
		},
		get: function(value) {
			return(this.value);
		}
	}
});

