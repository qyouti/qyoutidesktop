var DropdownMenu = Div.extend({
	static: {
		Item: Div.extend({
			init: function(p) {
				for (key in p) {
					if (key.startsWith('on')) {
						this.addEventListener(key.substring(2), p[key], false);
					}
					delete p.key;
				}
				Div.prototype.init.call(this);
				if (p.title)
					this.title = p.title;
				var icon = (p.icon instanceof Icon) ? p.icon : new Icon({'context': 'actions', 'size': '16', 'name': p.icon});
				Div.prototype.appendChild.call(this,  icon);
				Div.prototype.appendChild.call(this, new Div({'text': p.text?p.text:''}) );
				Div.prototype.appendChild.call(this, new Div({'text': p.shortcut?p.shortcut:''}) );
				Div.prototype.appendChild.call(this, new Div() );
			},
			appendChild: function(child) {
				if (child instanceof DropdownMenu) {
					this.childNodes[2].text = '>';
					this.childNodes[3].appendChild(child);
					return(child);
				} else {
					//error
				}
			}
		})
	},
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('dropdownmenu');
	}/*,
	appendChild: function(child) {
		if (child.constructor == Hr) {
			var row = Div.prototype.appendChild.call(this, new Div() );
			row.appendChild(child);
		} else {
			Div.prototype.appendChild.call(this, child);
		}
		return(child);
	}*/
});

