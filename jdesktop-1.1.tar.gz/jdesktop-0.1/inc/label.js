var Label = JDESKTOPLabelElement.extend({
	init: function(p) {
		JDESKTOPLabelElement.prototype.init.call(this, p);
	},
	text: {
		set: function(value) {
			this.textContent = value
		},
		get: function(value) {
			return(this.textContent);
		}
	}
});

