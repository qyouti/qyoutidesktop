var Vr = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('vr');
	}
});

