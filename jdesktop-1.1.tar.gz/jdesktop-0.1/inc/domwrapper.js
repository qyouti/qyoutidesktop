/* experimental */

var Event = Class.extend({
	init: function(event) {
		this.event = event;
		this.target = event.target?Element.Elements[event.target.getAttribute('jdesktopID')]:null;
		this.relatedTarget = event.relatedTarget?Element.Elements[event.relatedTarget.getAttribute('jdesktopID')]:null;
		this.clientX = event.clientX;
		this.clientY = event.clientY;
		this.offsetX = event.offsetX;
		this.offsetY = event.offsetY;
	},
	stopPropagation: function() {
		this.event.stopPropagation();
	},
	preventDefault: function() {
		this.event.preventDefault();
	},
	toString: function() {
		return('[object Event]');
	}
});

var CSSStyleDeclaration = Class.extend({
	static: {
		init: function() {
			this.Attributes.forEach(function(attribute) {
				Object.defineProperty(this.prototype, attribute, {
					set: function(value) {
						this.style[attribute] = value;
					},
					get: function() {
						return(this.style[attribute]);
					}
				});
			}.bind(this));
		},
		Attributes: [
			/* Box Properties */
			'border',
			'borderBottom',
			'borderBottomWidth',
			'borderColor',
			'borderImage',
			'borderLeft',
			'borderLeftWidth',
			'borderRadius',
			'borderRight',
			'borderRightWidth',
			'borderStyle',
			'borderTop',
			'borderTopWidth',
			'borderWidth',
			'boxShadow',
			'clear',
			'float',
			'height',
			'margin',
			'marginBottom',
			'marginLeft',
			'marginRight',
			'marginTop',
			'opacity',
			'overflow',
			'padding',
			'paddingBottom',
			'paddingLeft',
			'paddingRight',
			'paddingTop',
			'width',
			/* Background and Color Properties */
			'background',
			'backgroundAttachment',
			'backgroundColor',
			'backgroundImage',
			'backgroundPosition',
			'backgroundRepeat',
			'color',
			/* Classification  Properties */
			'display',
			'listStyle',
			'listStyleImage',
			'listStyleType',
			'listStylePosition',
			'whitespace',
			/* Font Properties */
			'font',
			'fontFamily',
			'fontSize',
			'fontStyle',
			'fontVariant',
			'fontWeight',
			/* Text Properties */
			'letterSpacing',
			'lineHeight',
			'textAlign',
			'textDecoration',
			'textIndent',
			'textOverflow',
			'textShadow',
			'textTransform',
			'verticalAlign',
			'wordSpacing',
			/* Animation */
			'transition',
			'transformation'

		]
	},
	init: function(style) {
		this.style = style
	},
	toString: function() {
		return('[object CSSStyleDeclaration]');
	}
})

var Element = Class.extend({
	static: {
		init: function() {
/*			this.Events.forEach(function(event) {
				Object.defineProperty(this.prototype, event, {
					configurable: true,
					set: function(value) {
						this['__'+event] = this.__event.bind(this, value);
						//if (!this.event) this.event = {};
						//if (!this.element) { this.events[event] = value; return(value); }
						//this.element[event] = this.__event.bind(this, value);
						//alert(this.event);
					},
					get: function() {
						return(this['__'+event]);
					}
				});
			}.bind(this));*/
		},
		Elements: {
		},
		Events: [
			'onclick',
			'ondblclick',
			'onmousedown',
			'onmouseup',
			'onmouseover',
			'onmousemove',
			'onmouseout',
			'onkeydown',
			'onkeypress',
			'onkeyup',
			'onload',
			'onunload',
			'onabort',
			'onerror',
			'onresize',
			'onscroll',
			'onselect',
			'onchange',
			'onsubmit',
			'onreset',
			'onfocus',
			'onblur'
		]
	},
	init: function(element, p) {
		this.element = document.createElement(element);

		this.style = new CSSStyleDeclaration(this.element.style);
		this.event = {'onclick': null};

		var jdesktopID = String.random(8);
		this.element.setAttribute('jdesktopID', jdesktopID);
		Element.Elements[jdesktopID] = this;

		if(p&&typeof p.style=='string') {
			this.setAttribute('style', p.style);
			delete p.style;
		}

		/* Activate Events */
		//this.element.onclick = this.__event.bind(this, this.onclick);
		//this.element.onclick = this.__event.bind(this, this.__onclick);

/*		for (event in this.events) {
			this.element.onclick = this.event.onclick;
		}*/

		Class.prototype.init.call(this, p);
	},
	/* method */
	appendChild: function(child) {
		this.element.appendChild(child.element);
		return(child);
	},
	removeChild: function(child) {
		this.element.removeChild(child.element)
		return(child);
	},
	insertBefore: function(newElement, referenceElement) {
		this.element.insertBefore(newElement, referenceElement);
		return(newElement);
	},
	setAttribute: function(attribute, value) {
		return(this.element.setAttribute(attribute, value));
	},
	getAttribute: function(attribute) {
		return(this.element.getAttribute(attribute));
	},
	removeAttribute: function(attribute) {
		return(this.element.removeAttribute(attribute));
	},
	addEventListener: function(type, listener, usecapture) {
		return(this.element.addEventListener(type, this.__event.bind(this, listener), usecapture));
	},
	removeEventListener: function(type, listener, usecapture) {
		return(this.element.removeEventListener(type, listener, usecapture));
	},
	hasChildNodes: function() {
		return(this.element.hasChildNodes());
	},
	hasClassName: function(name) {
		return new RegExp("(?:^|\\s+)" + name + "(?:\\s+|$)").test(this.element.className);
	},
	addClassName: function(name) {
		if (!this.hasClassName(name)) {
			this.element.className = this.element.className ? [this.element.className, name].join(' ') : name;
		}
	},
	removeClassName: function(name) {
		if (this.hasClassName(name)) {
			var c = this.element.className;
			this.element.className = c.replace(new RegExp("(?:^|\\s+)" + name + "(?:\\s+|$)", "g"), "");
		}
	},
	/* properties */
	firstChild: {
		get: function() {
			return(this.element.firstChild);
		},
		set: function(value) {
			this.element.firstChild = value;
		}
	},
	lastChild: {
		get: function() {
			return(this.element.lastChild);
		},
		set: function(value) {
			this.element.lastChild = value;
		}
	},
	childNodes: {
		get: function() {
			return(this.element.childNodes);
		}
	},
	nodeType: {
		get: function() {
			return(this.element.nodeType);
		}
	},
	innerHTML: {
		get: function() {
			return(this.element.innerHTML);
		},
		set: function(value) {
			this.element.innerHTML = value;
		}
	},
	innerText: {
		get: function() {
			return(this.element.innerText);
		},
		set: function(value) {
			this.element.innerText = value;
		}
	},
	textContent: {
		get: function() {
			return(this.element.textContent);
		},
		set: function(value) {
			this.element.textContent = value;
		}
	},
	text: {
		get: function() {
			return(this.element.innerText);
		},
		set: function(value) {
			this.element.innerText = value;
		}
	},
	html: {
		get: function() {
			return(this.element.innerHTML);
		},
		set: function(value) {
			this.element.innerHTML = value;
		}
	},
	/* events */
	__event: function(event, f) {
		f.call(this, new Event(event));
	}
});

var Div = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'div', p);
	},
	toString: function() {
		return('[object Div]');
	}
});

var Span = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'span', p);
	},
	toString: function() {
		return('[object Span]');
	}
});


var Input = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'input', p);
	},
	toString: function() {
		return('[input Input]');
	},
	disabled: {
		get: function() {
			return(this.element.disabled);
		},
		set: function(value) {
			this.element.disabled = value;
		}
	}
});

var Button = Input.extend({
	init: function(p) {
		Input.prototype.init.call(this, p);
		this.setAttribute('type', 'button');
	},
	toString: function() {
		return('[button Button]');
	}
});

var Textbox = Input.extend({
	init: function(p) {
		Input.prototype.init.call(this, p);
		this.setAttribute('type', 'text');
	},
	toString: function() {
		return('[textbox Textbox]');
	}
});

var Password = Input.extend({
	init: function(p) {
		Input.prototype.init.call(this, p);
		this.setAttribute('type', 'password');
	},
	toString: function() {
		return('[password Password]');
	}
});

var Checkbox = Input.extend({
	init: function(p) {
		Input.prototype.init.call(this, p);
		this.setAttribute('type', 'checkbox');
	},
	toString: function() {
		return('[checkbox Checkbox]');
	},
	checked: {
		get: function() {
			return(this.element.checked);
		},
		set: function(value) {
			this.element.checked = value;
		}
	}
});

var Radio = Input.extend({
	init: function(p) {
		Input.prototype.init.call(this, p);
		this.setAttribute('type', 'radio');
	},
	toString: function() {
		return('[radio Radio]');
	},
	checked: {
		get: function() {
			return(this.element.checked);
		},
		set: function(value) {
			this.element.checked = value;
		}
	}
});

var Select = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'select', p);
	},
	toString: function() {
		return('[select Select]');
	}
});

var Option = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'option', p);
	},
	toString: function() {
		return('[option Option]');
	}
});

/* */

var Legend = Element.extend({
	init: function(p) {
		Element.prototype.init.call(this, 'legend', p);
	},
	toString: function() {
		return('[legend legend]');
	}
});


var Fieldset = Element.extend({
	init: function(p) {
		this.__legend = new Legend();
		Element.prototype.init.call(this, 'fieldset', p);
		this.appendChild(this.__legend);
	},
	toString: function() {
		return('[fieldset Fieldset]');
	},
	legend: {
		get: function() {
			return(this.__legend.text);
		},
		set: function(value) {
			this.__legend.text = value;
		}
	}
});


