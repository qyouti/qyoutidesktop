/*http://particletree.com/features/rediscovering-the-button-element/*/

var Button = JDESKTOPButtonElement.extend({
	init: function(p) {
		this.appendChild( new Div({'class': 'icon', 'context': 'actions', 'size': '16'}) );
		this.appendChild( new Div() );
		JDESKTOPButtonElement.prototype.init.call(this, p);
		this.name = 'Button';
	},
	text: {
		set: function(value) {
			this.childNodes[1].textContent = value
		},
		get: function(value) {
			return(this.childNodes[1].textContent);
		}
	},
	icon: {
		set: function(value) {
			this.setAttribute('icon', 'true');
			this.childNodes[0].setAttribute('name', value);
		},
		get: function(value) {
			return(this.childNodes[0].getAttribute('name'));
		}
	},
	name: 'Button'
});

Button.RefreshButton = Button.extend({
	init: function(p) {
		Button.prototype.init.call(this, p);
		this.icon = 'view-refresh';
		this.setAttribute('id', 'refresh');
	},
	loading: {
		set: function(value) {
			if (value) {
				this.setAttribute('loading', '');
			} else {
				this.removeAttribute('loading');
			}
		},
		get: function() {
			return(this.hasAttribute('loading'));
		}
	}
});


Button.DatePicker = Button.extend({
	static: {
		init: function() {
			document.addEventListener('mousedown', this.mousedown, false);
		},
		mousedown: function(event) {
			if (window.me&&Button.calendar) {
				if (!event.hasTarget(Button.calendar)) {
					me.removeChild(Button.calendar);
					delete Button.calendar;
				}
			}
		}
	},
	init: function(p) {
		Button.prototype.init.call(this, p);
		this.icon = 'view-calendar';
	},
	click_handler: function(event) {
		Button.calendar = me.appendChild( new Calendar({
			'text': 'Select Date',
			'style': 'position: fixed; top: $px; left: $px'.$(this.positionY+this.offsetHeight, this.positionX),
			'onchange': function(event) {
				this.text=Button.calendar.selectedDate.format('yyyy-mm-dd');
				this.selectedDate = Button.calendar.selectedDate;
				if (typeof this.onchange=='function') {
					this.onchange(event);
				}
				me.removeChild(Button.calendar);
				delete me.calendar;
			}.bind(this)
		}) );
	}
});


