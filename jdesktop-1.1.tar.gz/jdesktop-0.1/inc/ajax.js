var Ajax = Class.extend({
	init: function(p) {
		if (p&&p.onload) this.onload=p.onload;
		if (p&&p.onerror) this.onerror=p.onerror;
		this.xrequest = new XMLHttpRequest();
	},
	get: function(path) {
		this.xrequest.open('GET', path, true);
		this.xrequest.onreadystatechange = this.__onreadystatechange.bind(this);
		this.xrequest.send(null);
	},
	post: function(path, data) {
		this.xrequest.open('POST', path, true);
		this.xrequest.onreadystatechange = this.__onreadystatechange.bind(this);
		this.xrequest.send(data);
	},
	load: function(path, newwindow) {
		if (newwindow) {
			window.open('index.html?loadapp='+path, 'mywindow', 'menubar=0, resizable=1, width=640, height=480');
		} else {
			this.onload = this.__startapp.bind(this);
			this.get(path);
		}
	},
	__startapp: function(data) {
		eval(data);
	},
	__onreadystatechange: function() {
		if (this.xrequest.readyState==4) {
			if (this.xrequest.status==200) {
				if (typeof this.onload=='function') {
					this.onload(this.xrequest.responseText);
				}
			} else {
				if (typeof this.onerror=='function') {
					this.onerror(this.xrequest.status);
				}
			}
		}
	}
});

/*

*/
