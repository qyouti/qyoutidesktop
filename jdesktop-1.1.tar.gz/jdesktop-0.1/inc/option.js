var Option = JDESKTOPOptionElement.extend({
	init: function(p) {
		JDESKTOPOptionElement.prototype.init.call(this, p);
	},
	text: {
		set: function(value) {
			this.textContent = value
		},
		get: function(value) {
			return(this.textContent);
		}
	}
});

