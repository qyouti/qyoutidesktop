var IconMenu = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('iconmenu');
	},
	appendChild: function(child) {
		if (child instanceof Button) {
			child.setAttribute('transparent', '');
		}
		return(Div.prototype.appendChild.call(this, child));
	}
});

