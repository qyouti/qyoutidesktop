var Accordion = Div.extend({
	static: {
		Item: Div.extend({
			init: function(p) {
				var p=p?p:{};

				this.__caption = new Div({
					'onclick': this.select.bind(this),
					'text': p.caption
				});

				
				this.__content = new Div(p);

				Div.prototype.init.call(this);
				this.addClassName('item');

				Div.prototype.appendChild.call(this, this.__caption);
				Div.prototype.appendChild.call(this, this.__content);

				this.__content.addEventListener('DOMSubtreeModified', this.resize.bind(this));
			},
			caption: {
				set: function(value) {
					this.__caption.text = value;
				},
				get: function() {
					return(this.__caption.text);
				}
			},
			html: {
				set: function(value) {
					this.__content.html = value;
				},
				get: function() {
					return(this.__content.html);
				}
			},
			text: {
				set: function(value) {
					this.__content.text = value;
				},
				get: function() {
					return(this.__content.text);
				}
			},
			select: function(event) {
				var items = this.parentNode.childNodes;
				if (items[this.parentNode.selectedIndex]==this) return;
				for (var i=0; i<items.length; i++) {
					items[i].style.height='1.4em';
					items[i].removeAttribute('id');
				}

				this.setAttribute('id', 'selected');

				if (typeof this.parentNode.onchange == 'function') {
					this.parentNode.onchange(event);
				}

				this.style.height = (this.__caption.offsetHeight+this.__content.offsetHeight)+'px';
			},
			selected: function() {
				return(this.getAttribute('id') == 'selected' ? true : false);
			},
			resize: function() {
				if (!this.selected()) return;
				this.style.height = (this.__caption.offsetHeight+this.__content.offsetHeight)+'px';
			},
			appendChild: function(child) {
				this.__content.appendChild(child);
				return(child);
			},
			removeChild: function(child) {
				this.__content.removeChild(child);
				return(child);
			}
		})
	},
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('accordion');
	},
	appendChild: function(child) {
		Div.prototype.appendChild.call(this, child);
		return(child);
	},
	selectedIndex: {
		set: function(value) {
			this.childNodes[value].select();
		},
		get: function() {
			var items = this.childNodes;
			for (var i=0; i<items.length; i++) {
				if (items[i].getAttribute('id') == 'selected') return(i);
			}
		}
	}
});

