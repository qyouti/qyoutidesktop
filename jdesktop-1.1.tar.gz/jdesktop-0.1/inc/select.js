var Select = JDESKTOPSelectElement.extend({
	init: function(p) {
		JDESKTOPSelectElement.prototype.init.call(this, p);
	}
});

