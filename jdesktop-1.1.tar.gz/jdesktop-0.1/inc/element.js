function Element(name, p) {
	var element = document.createElement(name);
	for (key in p) {
		if element[key] {
			element.key = p[key]
		} else {
			element.setAttribute(key, p[key]);
		}
	}
}

