var Checkbox = Div.extend({
	init: function(p) {
		var id = String.random(8)
		this.__cb = this.appendChild( new JDESKTOPInputElement({'type': 'checkbox', 'id': id}) );
		this.__label = this.appendChild( new Label({'for': id}) );
		Div.prototype.init.call(this, p);
		this.setAttribute('type', 'checkbox');
	},
	label: {
		set: function(value) {
			this.__label.text = value;
		},
		get: function() {
			return(this.__label.text);
		}
	},
	checked: {
		set: function(value) {
			this.__cb.checked = value;
		},
		get: function() {
			return(this.__cb.checked);
		}
	}
});

