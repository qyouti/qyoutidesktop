﻿var NumberPicker = Div.extend({
	init: function(p) {
		this.appendChild( new Textbox({
			"value": p&&p.value?p.value:0,
			"onkeydown": this.validate.bind(this)
		}) );
		var buttons = this.appendChild( new Div() );
		buttons.appendChild( new Div({"text": "▲", "onclick": this.up.bind(this)}) );
		buttons.appendChild( new Div({"text": "▼", "onclick": this.down.bind(this)}) );

		Div.prototype.init.apply(this, arguments);

		this.addClassName('numberpicker');
	},
	up: function(event) {
		this.childNodes[0].value = parseInt(this.childNodes[0].value) + 1;
		if (typeof this.onchange=="function") this.onchange(event, this.value);
	},
	down: function(event) {
		this.childNodes[0].value = parseInt(this.childNodes[0].value) - 1;
		if (typeof this.onchange=="function") this.onchange(event, this.value);
	},
	value: {
		get: function() {
			return(parseFloat(this.childNodes[0].value));
		},
		set: function(value) {
			parseFloat(value);
			this.childNodes[0].value = value;
		}
	},
	validate: function(event) {
		var c = event.which;
		if (c > 31 && (c < 48 || c > 57))
			return false;
		return true;
	}
});
