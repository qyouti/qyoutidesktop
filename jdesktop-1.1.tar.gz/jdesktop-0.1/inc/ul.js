var Ul = JDESKTOPULElement.extend({
	init: function(p) {
		JDESKTOPULElement.prototype.init.call(this, p);
	}
});

