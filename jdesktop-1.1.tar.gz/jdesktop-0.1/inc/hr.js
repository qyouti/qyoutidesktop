var Hr = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('hr');
	}
});

