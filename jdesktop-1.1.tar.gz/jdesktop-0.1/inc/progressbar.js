var Progressbar = Div.extend({
	init: function(p) {
		this.addClassName("progressbar");
		Div.prototype.init.apply(this, arguments);
		this.__percentage = this.appendChild( new Div({"class": "percentage"}) );
		this.__value = this.appendChild( new Div({"class": "value"}) );
		this.__percentage.style.width = "0%";
		this.__value.innerText = "0%";
	},
	value: {
		get: function() {
			return(parseInt(this.__percentage.style.width));
		},
		set: function(value) {
			this.__percentage.style.width = value+"%";
			this.__value.innerText = (Math.round(value*100)/100)+"%";
		}
	}
});

