var Chart = Canvas.extend({
	static: {
		Series: Class.extend({
			init: function(p) {
				Class.prototype.init.call(this, p);
			},
			values: false,
			color: false,
			type: 'line'
		})
	},
	init: function(p) {
		var p=p?p:{};
		this.serieses = [];

		Canvas.prototype.init.call(this, p);
		this.addClassName('chart');
		this.ctx = this.getContext('2d');
	},
	initialize: function() {
		this.lineSerieses = [];
		this.barSerieses = [];
		this.areaSerieses = [];
		this.pieSerieses = [];

		this.serieses.forEach(function(e) {
			if (e.type!=='hidden') {
				this[e.type+'Serieses'].push(e);
			}
		}, this);


		if (this.label.text != '') {
			this.ctx.font = '20px Arial';

			this.label.width = this.ctx.measureText(this.text).width;
			this.label.height = 60;
		}

		if (this.legend.values.length) {
			this.ctx.font = '15px Arial';

			var width = []
			this.legend.values.forEach(function(e, i, a) {
				width.push(this.ctx.measureText(String.fromCharCode(9724)+' '+e.toString()).width);
			},this);

			this.legend.width = width.max();
			this.legend.height = this.height;			
		}

		if (this.xaxis.values.length || this.xaxis.values.length) {
			var heights = []
			var height;
			this.xaxis.values.forEach(function(e, i, a) {
				height = this.ctx.measureText(e.toString()).width;
				height *= Math.abs(Math.sin(this.xaxis.angel*Math.PI/180));
				heights.push(height);
			},this);

			this.xaxis.width = this.width;
			this.xaxis.height = heights.max();
		}

		if (this.xaxis.label != '' && this.xaxis.values.length) {
			this.xaxis.width = this.width;
			this.xaxis.height += 30;
		}

		this.ctx.font = '15px Arial';
		var width = [];
		var step = (this.yaxis.maximum-this.yaxis.minimum)/(this.yaxis.steps-1);
		for (var i=0; i<this.yaxis.steps; i++) {
			width.push(this.ctx.measureText((i*step).format(this.yaxis.format)).width);
		}
		this.yaxis.width = width.max();

		if (this.yaxis.label !== '') {
			this.yaxis.width += 20;
		}

	},
	label: {
		text: '',
		width: 0,
		height: 0
	},
	legend: {
		values: [],
		width: 0,
		height: 0
	},
	xaxis: {
		values: [],
		label: '',
		width: 0,
		height: 0,
		angel: 0
	},
	yaxis: {
		steps: 5,
		maximum: 100,
		minimum: 0,
		label: '',
		format: '',
		width: 0,
		height: 0
	},
	draw: function() {
		this.initialize();

		this.ctx.clearRect(0, 0, this.width, this.height);

		this.drawLabel();
		this.drawLegend();
		
		if (!this.pieSerieses.length) {
			this.drawYAxis();
			this.drawXAxis();
		}

		this.drawSerieses();
	},
	drawLabel: function() {
		var left = 10+this.yaxis.width;
		var top = 0;

		this.ctx.font = '20px Arial';
		this.ctx.textAlign = 'left';
		this.ctx.textBaseline = 'top';
		this.ctx.fillStyle='black';

		if (this.label.text) {
			this.ctx.fillText(this.label.text, left, top);
		}		
	},
	drawLegend: function() {
		var right = this.width;
		var top = this.label.height;
		if (this.legend) {
			this.ctx.font = '15px Arial';
			this.ctx.textAlign = 'left';
			this.ctx.textBaseline = 'top';
			this.ctx.fillStyle='black';

			var width = this.ctx.measureText(String.fromCharCode(9724)+' ').width;
			this.legend.values.forEach(function(e, i, a) {
				this.ctx.fillStyle=(this.serieses[i]&&this.serieses[i].color)?this.serieses[i].color:this.colors[i];
				this.ctx.fillText(String.fromCharCode(9724), right-this.legend.width, top+i*20);

				this.ctx.fillStyle='black';
				this.ctx.fillText(e.toString(), right-this.legend.width+width, top+i*20);
			},this);

		}
	},
	drawXAxis: function() {
		var right = this.width;
		var bottom = this.height;
		var top = 0;
		var width = this.width-this.yaxis.width-this.legend.width;
		var left = 0+this.yaxis.width;

		this.ctx.font = '15px Arial';
		this.ctx.textAlign = 'center';
		this.ctx.textBaseline = 'bottom';
		this.ctx.fillStyle='black';

		if (this.xaxis.label) {
			this.ctx.fillText(this.xaxis.label, width/2+this.yaxis.width, bottom);
		}

		var step = width/this.xaxis.values.length;
		this.xaxis.values.forEach(function(e, i, a) {
			this.ctx.save();
			this.ctx.translate(left+i*step+(step/2), bottom-this.xaxis.height+15);
			this.ctx.rotate(this.xaxis.angel*Math.PI/180);
			this.ctx.textAlign = "right";
			if (this.xaxis.angel>-45) this.ctx.textAlign = 'center';
			this.ctx.textBaseline = "middle";
			this.ctx.fillText(e.toString(), 0, 0);
			this.ctx.restore();

			//this.ctx.fillText(e.toString(), left+i*step+(step/2), bottom-20);
		},this);
	},
	drawYAxis: function() {
		var left = 0+this.yaxis.width;
		var top = 10+this.label.height;
		var bottom = this.height-this.xaxis.height;
		var right = this.width-this.legend.width;
		var height = bottom-top;
		var middle = (bottom-top)/2;

		if (this.yaxis.label !== '') {
			this.ctx.save();
			this.ctx.translate(10, this.height/2);
			this.ctx.rotate(-Math.PI/2);
			this.ctx.textAlign = "center";
			this.ctx.textBaseline = "middle";
			this.ctx.fillText(this.yaxis.label, 0, 0);
			this.ctx.restore();
		}

		/* Draw Y Axis */;
		var stepheight = height/(this.yaxis.steps-1);
		var step = (this.yaxis.maximum-this.yaxis.minimum)/(this.yaxis.steps-1);

		this.ctx.font = '15px Arial';
		this.ctx.textAlign = 'right';
		this.ctx.textBaseline = 'middle';
		this.ctx.fillStyle='black';
		this.ctx.lineWidth = 1;
		this.ctx.strokeStyle = 'lightgrey';

		this.ctx.beginPath();
		for (var i=0; i<this.yaxis.steps; i++) {
			this.ctx.fillText((i*step).format(this.yaxis.format), left, bottom-stepheight*i);
			this.ctx.moveTo(left+10, bottom-stepheight*i);
			this.ctx.lineTo(right-10, bottom-stepheight*i);
		}
		this.ctx.stroke();
	},
	drawSerieses: function(values) {
		if (this.pieSerieses.length) this.drawPieSerieses();
		if (this.lineSerieses.length) this.drawLineSerieses();
		if (this.barSerieses.length) this.drawBarSerieses();
		if (this.areaSerieses.length) this.drawAreaSerieses();
	},
	drawBarSerieses: function() {
		var width = this.width-this.yaxis.width-this.legend.width-10;
		var height = this.height-this.label.height-this.xaxis.height-10;
		var left = 0+this.yaxis.width;
		var bottom = this.height-this.xaxis.height;

		this.barSerieses.forEach(function(seriese, i) {
			var barpadding = 20;
			var stepwidth = width/this.xaxis.values.length;

			var barwidth = (stepwidth-barpadding)/this.barSerieses.length;
			var barMarginLeft = left+i*barwidth;

			this.xaxis.values.forEach(function(e, i, a) {
				this.ctx.fillStyle = seriese.color?seriese.color:this.colors[this.serieses.indexOf(seriese)];

				var barheight = seriese.values[i]*(height/this.yaxis.maximum);
				var barLeft = i*stepwidth+barpadding/2+barMarginLeft+2;
				var barTop = bottom-barheight;
				this.ctx.fillRect(barLeft+2, barTop, barwidth-2, barheight);
			}, this);
		}, this);
	},
	drawLineSerieses: function(values) {
		var width = this.width-this.yaxis.width-this.legend.width-10;
		var height = this.height-this.label.height-this.xaxis.height-10;
		var left = 0+this.yaxis.width;
		var bottom = this.height-this.xaxis.height;

		var x, y;
		this.ctx.lineWidth = 2;
		this.ctx.lineJoin = 'round';
		this.lineSerieses.forEach(function(seriese, i) {
			var stepwidth = width/this.xaxis.values.length;
			var step = stepwidth/2;

			this.ctx.beginPath();
			this.ctx.strokeStyle = seriese.color?seriese.color:this.colors[this.serieses.indexOf(seriese)];
			this.xaxis.values.forEach(function(e, i, a) {
				x = left+step+i*stepwidth;
				y = bottom-seriese.values[i]*(height/this.yaxis.maximum);
				if (i) {
					this.ctx.lineTo(x, y);
				} else {
					this.ctx.moveTo(x, y);
				}
			}, this);
			this.ctx.stroke();
		}, this);
	},
	drawAreaSerieses: function(values) {
		var width = this.width-this.yaxis.width-this.legend.width-10;
		var height = this.height-this.label.height-this.xaxis.height-10;
		var left = 0+this.yaxis.width;
		var bottom = this.height-this.xaxis.height;

		var x, y;
		this.ctx.lineWidth = 2;
		this.ctx.lineJoin = 'round';
		this.areaSerieses.forEach(function(seriese, i) {
			var stepwidth = width/this.xaxis.values.length;
			var step = stepwidth/2;

			this.ctx.beginPath();
			this.ctx.strokeStyle = seriese.color?seriese.color:this.colors[this.serieses.indexOf(seriese)];
			this.xaxis.values.forEach(function(e, i, a) {
				x = left+step+i*stepwidth;
				y = bottom-seriese.values[i]*(height/this.yaxis.maximum);
				if (i) {
					this.ctx.lineTo(x, y);
				} else {
					this.ctx.moveTo(x, y);
				}
			}, this);
			this.ctx.stroke();

			/* Fill */
			this.ctx.beginPath();
			this.ctx.fillStyle = seriese.color?seriese.color:this.colors[this.serieses.indexOf(seriese)];
			this.ctx.fillStyle = this.ctx.fillStyle.replace('0.7', '0.3');
			this.xaxis.values.forEach(function(e, i, a) {
				x = left+step+i*stepwidth;
				y = bottom-seriese.values[i]*(height/this.yaxis.maximum);
				if (i) {
					this.ctx.lineTo(x, y);
				} else {
					this.ctx.moveTo(x, bottom);
					this.ctx.lineTo(x, y);
				}
			}, this);
			this.ctx.lineTo(x, bottom);
			this.ctx.closePath();
			this.ctx.fill();
		}, this);
	},
	drawPieSerieses: function() {
		/* TODO http://www.phpied.com/canvas-pie/ */
		// get canvas this.ctx., determine radius and center
		var width = this.width-this.legend.width-50;
		var height = this.height-this.label.height-50;
		var radius = Math.min(width, height) / 2;
		var center = width/2+25;
		var middle = height/2+this.label.height/2+25;
		var sofar = 0; // keep track of progress

		// loop the data[]
		data = this.pieSerieses[0].values;

		data.forEach(function(e, i, a) {

		    var thisvalue = e / a.sum();

		    this.ctx.beginPath();
		    this.ctx.moveTo(center, middle); // center of the pie
		    this.ctx.arc(  // draw next arc
			center,
			middle,
			radius,
			Math.PI * (- 0.5 + 2 * sofar ), // -0.5 sets set the start to be top
			Math.PI * (- 0.5 + 2 * (sofar + thisvalue)),
			false
		    );

		    this.ctx.lineTo(center, middle); // line back to the center
		    this.ctx.closePath();
		    this.ctx.fillStyle = this.colors[i];    // color
                    this.ctx.fill();

		    sofar += thisvalue; // increment progress tracker
		}, this);

   	        this.ctx.strokeStyle = 'white';
		this.ctx.fillStyle = 'black';
		this.ctx.lineWidth = 1;
		this.ctx.textBaseline = 'middle';
		this.ctx.textAlign = 'center';

		/* stroke */
		data.forEach(function(e, i, a) {

		    var thisvalue = e / a.sum();

		    this.ctx.beginPath();
		    this.ctx.moveTo(center, middle); // center of the pie
		    this.ctx.arc(  // draw next arc
			center,
			middle,
			radius,
			Math.PI * (- 0.5 + 2 * sofar), // -0.5 sets set the start to be top
			Math.PI * (- 0.5 + 2 * (sofar + thisvalue)),
			false
		    );

		    var angel = (Math.PI * (- 0.5 + 2 * sofar) + Math.PI * (- 0.5 + 2 * (sofar + thisvalue)))/2+90*Math.PI/180;
		    var x = center+Math.sin(angel)*radius*0.8;
		    var y = middle-Math.cos(angel)*radius*0.8;

		    this.ctx.fillText((e*100 / a.sum()).format('0.0 %'), x, y);


		    this.ctx.lineTo(center, middle); // line back to the center
		    this.ctx.closePath();
                    this.ctx.stroke();

		    sofar += thisvalue; // increment progress tracker
		}, this);

	},
	appendChild: function(child) {
		if (child instanceof Chart.Series) {
			this.serieses.push(child);
		}
		return(child);
	},
	__width: 300,
	__height: 150,
	width: {
		set: function(value) {
			this.__width = value;
			this.setAttribute('width', value);
		},
		get: function() {
			return(this.__width);
		}
	},
	height: {
		set: function(value) {
			this.__height = value;
			this.setAttribute('height', value);
		},
		get: function() {
			return(this.__height);
		}
	},
	serieses: null,
	lineSeriese: null,
	barSerieses: null,
	areaSerieses: null,
	pieSerieses: null,
	colors: [
		'rgba(0, 0, 255, 0.7)',
		'rgba(255, 0, 0, 0.7)',
		'rgba(0, 255, 0, 0.7)',
		'rgba(255, 255, 0, 0.7)',
		'rgba(0, 255, 255, 0.7)',
		'rgba(0, 0, 127, 0.7)',
	]
});

