﻿var NumberPicker = Div.extend({
	init: function(p) {
		Div.prototype.init.apply(this, arguments);
		this.addClassName('number');
		this.appendChild( new Textbox({
			"value": p&&p.value?p.value:0,
			"onkeydown": this.validate.bind(this)
		}) );
		var buttons = this.appendChild( new Div() );
		buttons.appendChild( new Div({"text": "▲", "onclick": this.up.bind(this)}) );
		buttons.appendChild( new Div({"text": "▼", "onclick": this.down.bind(this)}) );
	},
	up: function(event) {
		this.childNodes[0].value = parseInt(this.childNodes[0].value) + 1;
		if (typeof this.onchange=="function") this.onchange(event, this.value);
	},
	down: function(event) {
		this.childNodes[0].value = parseInt(this.childNodes[0].value) - 1;
		if (typeof this.onchange=="function") this.onchange(event, this.value);
	},
	value: {
		get: function() {
			return(parseInt(this.childNodes[0].value));
		}
	},
	validate: function(event) {
		var c = event.which;
		if (c > 31 && (c < 48 || c > 57))
			return false;
		return true;
	}
});
