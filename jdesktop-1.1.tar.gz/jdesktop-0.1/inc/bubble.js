var Bubble = Div.extend({
	init: function(p) {
		this.setAttribute('type', 'isosceles');
		Div.prototype.init.call(this, p);
		this.addClassName('bubble');
	}
});

