var Li = JDESKTOPLIElement.extend({
	init: function(p) {
		JDESKTOPLIElement.prototype.init.call(this, p);
	}
});

