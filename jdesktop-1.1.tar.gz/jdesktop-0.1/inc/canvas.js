var Canvas = JDESKTOPCanvasElement.extend({
	init: function(p) {
		JDESKTOPCanvasElement.prototype.init.call(this, p);
		this.setAttribute('type', 'text');
	}
});

