var TreeView = Div.extend({
	static: {
		ListItem: Li.extend({
			init: function(p) {
				if (p&&p.opener) {
					this.__open = this.appendChild( new Div({'class': 'opener'}) );
				}
				if (p&&p.icon) {
					this.__icon = this.appendChild( new Div({'class': 'icon', 'size': '16'}) );
				}
				this.__text = this.appendChild( new Div({'class': 'text'}) );
				Li.prototype.init.call(this, p);
			},
			icon: {
				set: function(value) {
					this.__icon.setAttribute('context', value.split(' ')[0]);
					this.__icon.setAttribute('name', value.split(' ')[1]);
				}
			},
			text: {
				set: function(value) {
					this.__text.text = value;
				},
				get: function() {
					return(this.__text.text);
				}
			}

		}),
		RootItem: Ul.extend({
			init: function(p) {
				var p=p?p:{};
				this.setAttribute('state', 'open');
				p.opener = true;
				this.appendChild( new TreeView.ListItem(p) );
				this.firstChild.onclick = this.__toggle.bind(this);
				Ul.prototype.init.call(this);
			},
			text: {
				get: function() {
					return(this.firstChild.text);
				},
				set: function(value) {
					this.firstChild.text = value;
				}
			},
			__toggle: function(event) {
				this.setAttribute('state', this.getAttribute('state')=='open'?'closed':'open');
			}

		}),
	},
	init: function(p) {
		this.addClassName('treeview');
		Div.prototype.init.call(this, p);
	}
});

