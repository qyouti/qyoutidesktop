var Environment = new (Class.extend({
	init: function(p) {
		
		/* Detect browser */
		var ua=navigator.userAgent;

		var ua = navigator.userAgent;
		if (ua.indexOf("Firefox") != -1) {
			this.browser = "Firefox";
			this.layoutengine = "gecko";
		} else if (ua.indexOf("Iceweasel") != -1) {
			this.browser = "Firefox";
			this.layoutengine = "gecko";
		} else if (ua.indexOf("IceCat") != -1) {
			this.browser = "Firefox";
			this.layoutengine = "gecko";
		} else if (ua.indexOf("Minefield") != -1) {
			this.browser = "Firefox";
			this.layoutengine = "gecko";
		} else if (ua.indexOf("Opera") != -1) {
			this.browser = "Opera";
			this.layoutengine = "presto";
		} else if (ua.indexOf("MSIE") != -1) {
			this.browser = "MSIE";
			this.layoutengine = "trident";
		} else if (ua.indexOf("Chrome") != -1) {
			this.browser = "Chrome";
			this.layoutengine = "webkit";
		} else if (ua.indexOf("Safari") != -1) {
			this.browser = "Safari";
			this.layoutengine = "webkit";
		} else {
			this.browser = "unknown";
			this.layoutengine = "unknown";
		} 

		/* Detect version */
		this.version = parseFloat(ua.substring(this.browser.length+1+ua.indexOf(this.browser)));

		/* Detect os */
		if (ua.indexOf("Linux") != -1)
			this.os = "Linux";
		else if (ua.indexOf("Apple") != -1)
			this.os = "Apple";
		else if (ua.indexOf("Windows") != -1)
			this.os = "Windows";
		else
			this.os = "Unknown";

		/* Check native supports */
		this.nativeCanvas = this.browser == "MSIE" ? false : true;
		this.nativeCanvasText = this.nativeCanvas && document.createElement("canvas").getContext("2d").font ? true : false;
		this.nativeJSON = window.JSON ? true : false;
		this.nativeAudio = document.createElement("audio").play ? true : false;
		this.nativeVideo = document.createElement("video").play ? true : false;
	},
	getScrollBarWidth: function () {
		var inner = document.createElement('p');
		inner.style.width = "100%";
		inner.style.height = "200px";

		var outer = document.createElement('div');
		outer.style.position = "absolute";
		outer.style.top = "0px";
		outer.style.left = "0px";
		outer.style.visibility = "hidden";
		outer.style.width = "200px";
		outer.style.height = "150px";
		outer.style.overflow = "hidden";
		outer.appendChild (inner);

		document.body.appendChild (outer);
		var w1 = inner.offsetWidth;
		outer.style.overflow = 'scroll';
		var w2 = inner.offsetWidth;
		if (w1 == w2) w2 = outer.clientWidth;

		document.body.removeChild (outer);

		return (w1 - w2);
	}
}))();

