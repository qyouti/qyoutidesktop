

var DataTable = Div.extend({
	static: {
		Row: Div.extend({
			init: function(p) {
				Div.prototype.init.call(this, p);
			},
			selected: {
				set: function(value) {
					if (value) {
						/* deselect all */
						this.table.__selectedItems.forEach(function(row) {
							row.selected = false
						}, this);

						this.setAttribute('selected', '');
						this.table.__selectedItems.push(this);
					} else {
						this.removeAttribute('selected');
						this.table.__selectedItems.remove(this);
					}
				},
				get: function() {
					return(this.hasAttribute('selected'));
				}
			}
		}),
		Cell: Div.extend({
			init: function(p) {
				Div.prototype.init.call(this, p);
			},
			type: {
				set: function(value) {
					this.setAttribute('type', value);
					this.__type = value;
				},
				get: function() {
					return(this.__type);
				}
			},
			value: {
				set: function(value) {
					switch(this.type) {
						case 'string':
							this.__value = new String(value);
							this.text = this.__value;
						break;
						case 'number':
							this.__value = new Number(value);
							this.text = this.__value.format(this.format);
						break;
						case 'date':
							this.__value = new Date(value);
							this.text = this.__value.format(this.format);
						break;
					}

					if (typeof this.onchange=='function') {
						this.onchange();
					}
				},
				get: function() {
					return(this.__value);
				}
			},
			mousedown_handler: function(event) {
				if (!this.editable) {
					return;
				}
				if (this.getAttribute('contenteditable') == 'true') { return; }
				this.setAttribute('contenteditable', 'true');
			},
			blur_handler: function() {
				if (!this.editable) {
					return;
				}

				this.setAttribute('contenteditable', 'false');
				this.value = this.text;
			},
			__value: '',
			__type: 'string',
			format: '',
			editable: false
		}),
		Range: Class.extend({
			init: function(parent, row1, cell1, row2, cell2) {
				this.cells = [];
				for (var i=row1;i<=row2;i++) {
					var row = [];
					this.cells.push(row);
					for (var j=cell1;j<=cell2;j++) {
						row.push(parent.cells[i][j]);
					}
				}
			},
			toArray: function() {
				var array = [];
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						array.push(e.value);
					});
				});
				return(array);
			},
			value: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.value = value;
						});
					});
				}
			},
			type: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.type = value;
						});
					});
				}
			},
			format: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.format = value;
						});
					});
				}
			},
			editable: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.editable = value;
						});
					});
				}
			},
			sum: function() {
				var sum = 0;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						sum += e.value?e.value:0;
					});
				});
				return(sum);
			},
			avg: function() {
				return(this.sum()/(this.cells.length*this.cells[0].length));
			},
			max: function() {
				var max = 0;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						if (e.value>max) {
							max = e.value;
						}
					});
				});
				return(max);
			},
			min: function() {
				var min = 99999999999999;
				this.cells.forEach(function(e) {
					e.forEach(function(e) {
						if (e.value<min) {
							min = e.value;
						}
					});
				});

				return(min);
			},
			/* events */
			onchange: {
				set: function(value) {
					this.cells.forEach(function(e) {
						e.forEach(function(e) {
							e.onchange = value;
						});
					});
				}
			}
		})

	},
	init: function(p) {
		if (p&&p.contenteditable) {
			this.editable = true;
			delete p.contenteditable;
		}


		Div.prototype.init.call(this, p);
		this.addClassName('datatable');

		var headWrap = this.appendChild( new Div({'class': 'head'}) );

		this.__head = headWrap.appendChild( new Div({'class': 'table'}) );

		var bodyWrap = this.appendChild( new Div({
			'class': 'body'
		}) );

		this.__table = bodyWrap.appendChild( new Div({
			'class': 'table',
		}) );

		var rows = p.rows;
		var cells = p.cells;

		this.cells=[];
		for(var i=0; i<rows; i++) {
			var row = this.__table.appendChild( new DataTable.Row() );
			row.table = this;
			var rowArray = [];
			this.cells.push(rowArray);
			for(var j=0, cell; j<cells; j++) {
				cell = row.appendChild( new DataTable.Cell() );
				rowArray.push(cell);
			}
		}
	},
	__mousemove_handler_: function(event) {
		if ((event.target.offsetWidth-event.offsetX)<4) {
			document.body.style.cursor = 'w-resize';
		} else if(!this.resizecell) {
			document.body.style.cursor = '';
		}

		if (this.resizecell) {
			var width = (this.cellwidth+event.clientX-this.clientx)+'px';

			if (this.fixedheader) this.__head.firstChild.childNodes[this.which].style.width = width;
			this.__table.firstChild.childNodes[this.which].style.width = width;
		}
	},
	__mousedown_handler_: function(event) {
		if ((event.target.offsetWidth-event.offsetX)<4) {
			var which = null;
			var row = event.target.parentNode;
			var cell = event.target;

			for (var i=0, cells=row.childNodes; i<cells.length; i++) {
				if (which==null) {
					this.__table.firstChild.childNodes[i].style.width = this.__table.firstChild.childNodes[i].offsetWidth + 'px';
					if (this.fixedheader) this.__head.firstChild.childNodes[i].style.width = this.__table.firstChild.childNodes[i].offsetWidth + 'px';
				} else {
					this.__table.firstChild.childNodes[i].style.width = '';
					if (this.fixedheader) this.__head.firstChild.childNodes[i].style.width = '';
				}
				if (cell==cells[i]) which = i;
			}

			this.cellwidth = this.__table.childNodes[0].childNodes[which].offsetWidth;
			this.clientx = event.clientX;
			this.resizecell = true;
			this.which = which;
			event.stopPropagation();
			event.preventDefault();
		}
	},
	__mouseup_handler_: function(event) {
		this.resizecell = false;
	},
	cell: function(row, cell) {
		return(this.__table.childNodes[row].childNodes[cell]);
	},
	row: function(row) {
		if (row<this.__head.childNodes.length)
			return(Array.prototype.slice.call(this.__head.childNodes[row]));
		else
			return(Array.prototype.slice.call(this.__body.childNodes[row-this.__head.childNodes.length]));
	},
	range: function(row1, cell1, row2, cell2) {
		return(new DataTable.Range(this, row1, cell1, row2, cell2));
	},
	fixedheader: {
		set: function(value) {
			if (value) {
				this.setAttribute('fixedheader', '');
				this.__head.style.visibility = 'visible';
				this.__head.appendChild( this.__table.firstChild );

				for (var i=0, headerCells=this.__head.childNodes[0].childNodes, bodyCells=this.__table.childNodes[0].childNodes; i<headerCells.length; i++)
					headerCells[i].style.width = bodyCells[i].offsetWidth + 'px';
			} else {
				this.removeAttribute('fixedheader');
				this.__head.style.visibility = 'hidden';
				this.__table.insertBefore(this.__head.firstChild, this.__table.firstChild);
			}
		},
		get: function() {
			return(this.hasAttribute('fixedheader'));
		}
	},
	selectedIndex: {
		get: function() {
		},
		set: function(value) {
		}
	},
	__resizeable: false,
	resizeable: {
		get: function() {
			return(this.__resizeable);
		},
		set: function(value) {
			if(value&&!this.__resizeable) {
				this.__resizeable = true;
				this.__mousedown_handler_func = this.__mousedown_handler_.bind(this);
				this.__mousemove_handler_func = this.__mousemove_handler_.bind(this);
				this.__mouseup_handler_func = this.__mouseup_handler_.bind(this);

				this.addEventListener('mousedown', this.__mousedown_handler_func, false);
				this.addEventListener('mousemove', this.__mousemove_handler_func, false);
				document.addEventListener('mouseup', this.__mouseup_handler_func, false);
			} else if(!value&&this.__resizeable) {
				this.__resizeable = false;
				document.body.style.cursor = '';

				this.removeEventListener('mousedown', this.__mousedown_handler_func, false);
				this.removeEventListener('mousemove', this.__mousemove_handler_func, false);
				document.removeEventListener('mouseup', this.__mouseup_handler_func, false);
			}
		}
	},
	/* Stuffs of selectable functionalaty */
	__selectedItems: null,
	__mousedown_selectable_: function(event) {
		var obj = event.target;
		do {
			obj = obj.parentNode;
		} while(!(obj instanceof DataTable.Row));
		obj.selected = true;
	},
	__selectable: false,
	selectable: {
		get: function() {
			return(this.__selectable);
		},
		set: function(value) {
			if(value&&!this.__selectable) {
				this.__mousedown_selectable_func = this.__mousedown_selectable_.bind(this);
				this.addEventListener('mousedown', this.__mousedown_selectable_func, false);
				this.__selectedItems = [];
				this.__selectable = true;
			} else if(!value&&this.__selectable) {
				this.removeEventListener('mousedown', this.__mousedown_selectable_func, false);
				this.selectedItems = [];
				this.__selectable = false;
			}
		}
	},
	selectedItems: {
		set: function(value) {
			while (this.selectedItems.length)
				this.selectedItems[0].selected = false;

			value.forEach(function(i) {
				this.childNodes[i].selected = true;
			}, this);
		},
		get: function(value) {
			return(this.__selectedItems);
		}
	}
});


