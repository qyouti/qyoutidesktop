var Tab = Div.extend({
	static: {
		Item: Class.extend({
			init: function(p) {
				var p=p?p:{};

				var p1 = Object.copy(p);
				delete p1.text;
				delete p1.html;
				this.__caption = new Div(p1);

				delete p.title;
				this.__content = new Div(p);

				this.__caption.addEventListener('click', this.onclick_handler.bind(this), false);
				this.__caption_icon = this.__caption.appendChild( new Div({'class': 'icon', 'context': 'actions', 'size': '16', 'name': 'tab-close'}) );
				this.__caption_text = this.__caption.appendChild( new Div({'text': 'tab1'}) );
				this.__caption_close = this.__caption.appendChild( new Div({'class': 'icon', 'context': 'actions', 'size': '16', 'name': 'tab-close', 'onclick': this.remove.bind(this)}) );

				Class.prototype.init.call(this, p);
			},
			onclick_handler: function() {
				this.select();
			},
			remove: function(event) {
				this.__parent.removeChild(this);
				event.stopPropagation();
			},
			appendChild: function(child) {
				return(this.__content.appendChild(child));
			},
			removeChild: function(child) {
				return(this.__content.removeChild(child));
			},
			firstChild: {
				get: function() {
					return(this.__content.firstChild);
				}
			},
			lastChild: {
				get: function() {
					return(this.__content.lastChild);
				}
			},
			childNodes: {
				get: function() {
					return(this.__content.childNodes);
				}
			},
			closable: {
				set: function(value) {
					this.__caption_close.style.display = value?'block':'none';
				},
				get: function() {
					return(this.__caption_close.style.display=='block'?true:false);
				}
			},
			caption: {
				set: function(value) {
					this.__caption_text.text = value;
				},
				get: function() {
					return(this.__caption_text.text);
				}
			},
			select: function() {
				this.__parent.items.forEach(function(e) {
					e.__content.removeAttribute('selected');
					e.__caption.removeAttribute('selected');						
				}, this)

				this.__content.setAttribute('selected', '');
				this.__caption.setAttribute('selected', '');

				if (typeof this.__parent.onchange == 'function')
					this.__parent.onchange();
			},
			selected: function() {
				return(this.__content.hasAttribute('selected'));
			},
			text: {
				set: function(value) {
					this.__content.text = value;
				},
				get: function() {
					return(this.__content.text);
				}
			},
			html: {
				set: function(value) {
					this.__content.html = value;
				},
				get: function() {
					return(this.__content.html);
				}
			},
			style: {
				get: function() {
					return(this.__content.style);
				}
			},
			__parent: null
		})
	},
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('tab');
		this.__head = Div.prototype.appendChild.call(this,  new Div({'class': 'head'}) );
		this.__content = Div.prototype.appendChild.call(this, new Div({'class': 'body'}) );
	},
	appendChild: function(child) {
		if (child instanceof Tab.Item) {
			child.__parent = this;

			this.__head.appendChild(child.__caption);
			this.__content.appendChild(child.__content);

			this.items.push(child);

			child.select();
		} else {
			throw new TypeError('Tab control accepts only Tab.Item object');
		}
		return(child);
	},
	removeChild: function(child) {
		if (child instanceof Tab.Item) {
			var index = this.items.indexOf(child);

			this.__head.removeChild(child.__caption);
			this.__content.removeChild(child.__content);
			this.items.remove(child);

			if (this.childNodes.length) {
				if (index==this.childNodes.length) {					
					this.selectedIndex = index-1;
				} else {
					this.selectedIndex = index;
				}
			}
		} else {
			throw new TypeError('Tab control accepts only Tab.Item object');
		}
		return(child);
	},
	childNodes: {
		get: function() {
			return(this.items);
		}
	},
	selectedIndex: {
		get: function() {
			for (var i=0; i<this.items.length; i++) {
				if (this.items[i].selected()) {
					return(i);
				};
			}
			return(null);
		},
		set: function(value) {
			this.items[value].select();
		}
	},
	items: []
});

