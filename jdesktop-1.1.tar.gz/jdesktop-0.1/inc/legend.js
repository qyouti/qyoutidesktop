var Legend = JDESKTOPLegendElement.extend({
	init: function(p) {
		JDESKTOPLegendElement.prototype.init.call(this, p);
	},
	text: {
		set: function(value) {
			this.textContent = value
		},
		get: function(value) {
			return(this.textContent);
		}
	}
});

