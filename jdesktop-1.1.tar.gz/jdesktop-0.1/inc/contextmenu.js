var Contextmenu = new (Class.extend({
	init: function() {
		Class.prototype.init.apply(this, arguments);
		document.addEventListener('mousedown', this.mousedown_handler.bind(this), true);
	},
	contextmenu_handler: function(event) {
	},
	mousedown_handler: function(event) {
		if (Contextmenu.contextmenu&&event.which==3) {
			me.removeChild(Contextmenu.contextmenu);
			delete Contextmenu.contextmenu;
			return;
		}

		if (Contextmenu.contextmenu&&!event.target.isDescendantNodeOf(Contextmenu.contextmenu)) {
			me.removeChild(Contextmenu.contextmenu);
			delete Contextmenu.contextmenu;
			return;
		}

		if (event.which == 3) {
			/* if no contextmenu and right click -> build ctx menu */
			var cmo = false;
			var obj = event.target;
			do {
				if (obj.hasOwnProperty('contextmenu')) cmo = obj.contextmenu;
			} while(!cmo && (obj = obj.parentNode));

			if (typeof cmo == 'function')
				cmo = cmo();
	
			if (cmo) {
				Contextmenu.contextmenu = me.appendChild( new DropdownMenu({
					'style': 'position: fixed; z-index: 999;top: $px; left: $px'.$(event.clientY, event.clientX)
				}) );
				cmo.forEach(function(e) {
					//if (e&&e.onclick) e.onclick = this.item_onclick.bind(self, e.onclick);
					var item = Contextmenu.contextmenu.appendChild( new DropdownMenu.Item(e) );
					item.addEventListener('click', function() {
						me.removeChild(Contextmenu.contextmenu);
						delete Contextmenu.contextmenu;
					}, true);
				},this);
				event.preventDefault();
				return(false);
			}
		}
	},
	item_onclick: function(event, f) {
		f(event);
		me.removeChild(Contextmenu.contextmenu);
		delete Contextmenu.contextmenu;
	}
}))();

