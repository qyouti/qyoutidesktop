(function(){
  var initializing = false;

  // The base Class implementation (does nothing)
  this.Class = function() {
  };
  this.Class.prototype.toString = function() {return "[class Class]"}
  this.Class.prototype.init = function(p) {
	for (var key in p) {
		if (!p.hasOwnProperty(key)) { continue; };
		this[key] = p[key];
	}
  }

  // Create a new Class that inherits from this class
  Class.extend = function(prop) {
/*    var base = this.prototype;*/
   
    // Instantiate a base class (but only create the instance,
    // don't run the init constructor)
    initializing = true;
    var prototype = new this();
    initializing = false;

    // Call static constructor if we have
   
    // The dummy class constructor
    var Class = function () {
      // All construction is actually done in the init method
      if ( !initializing && this.init ) {
        this.__class__ = arguments.callee;
        this.init.apply(this, arguments);
	}
    }
   
    // Populate our constructed prototype object
    Class.prototype = prototype;
   
    // Enforce the constructor to be what we expect
    Class.constructor = Class;

    // And make this class extendable
    Class.extend = arguments.callee;

    // Copy the properties over onto the new prototype
    for (var name in prop) {
	if (!prop.hasOwnProperty(name)) continue;
	if ((prop[name])&&(prop[name].hasOwnProperty("get") || prop[name].hasOwnProperty("set"))) {
		Object.defineProperty(Class.prototype, name, prop[name]);
	} else {
		prototype[name] = prop[name];

/*		prototype[name] = typeof prop[name] == 'function' && typeof base[name] == "function" ? (function(fn, name) {
			return function() {
				this.base = base;
				return fn.apply(this, arguments);
			}
		})(prop[name], name) : prop[name];
*/

	}
    }

    // Static methods, variables ...
    for (var name in prop["static"]) {
      Class[name] = prop["static"][name];
    }

    if (prop["static"] && prop["static"]["init"]) {
      prop["static"]["init"].call(Class);
    }

    return Class;
  };
})();

