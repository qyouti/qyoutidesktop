var ColorPicker = Div.extend({
	init: function(p) {
		Div.prototype.init.call(this, p);
		this.addClassName('colorpicker');

		var canvas = this.appendChild( new Canvas({
			'width': '400',
			'height': '400',
			'style': 'border: solid lightgrey 1px'
		}) );
		this.ctx = canvas.getContext('2d');

		canvas = this.appendChild( new Canvas({
			'width': '30',
			'height': '400',
			'onclick': this.canvas_onclick.bind(this)
		}) );

		ctx = canvas.getContext('2d');

		var lingrad = ctx.createLinearGradient(0, 0, 30, 400);
		lingrad.addColorStop(0.00, '#FF0000');
		lingrad.addColorStop(0.17, '#FF00FF');
		lingrad.addColorStop(0.33, '#0000FF');
		lingrad.addColorStop(0.50, '#00FFFF');
		lingrad.addColorStop(0.66, '#00FF00');
		lingrad.addColorStop(0.83, '#FFFF00');
		lingrad.addColorStop(1.00, '#FF0000');

		ctx.fillStyle = lingrad;

		// draw shapes
		ctx.fillRect(0, 0, 30, 400);

		this.imgd = ctx.getImageData(0, 0, 30, 400);
		this.pix = this.imgd.data;


		//this.appendChild( new Div({'id': 'gradient'}) );
	},
	canvas_onclick: function(event) {
		var r = this.pix[((event.offsetY*(this.imgd.width*4)) + (event.offsetX*4)) + 0];
		var g = this.pix[((event.offsetY*(this.imgd.width*4)) + (event.offsetX*4)) + 1];
		var b = this.pix[((event.offsetY*(this.imgd.width*4)) + (event.offsetX*4)) + 2];

		var canvas = new Canvas({'width': '400','height': '1'});
		var ctx = canvas.getContext('2d');
		var lingrad = ctx.createLinearGradient(0, 0, 400, 1);
		lingrad.addColorStop(0.00, '#ffffff');
		lingrad.addColorStop(1.00, 'rgb($, $, $)'.$(r,g,b));
		ctx.fillStyle = lingrad;
		ctx.fillRect(0, 0, 400, 1);
		var imgd = ctx.getImageData(0, 0, 400, 1);
		var pix = imgd.data;
		
		for (var i=0; i<400; i++) {
			var r = pix[i*4 + 0];
			var g = pix[i*4 + 1];
			var b = pix[i*4 + 2];

			var lingrad = this.ctx.createLinearGradient(0, 0, 1, 400);
			lingrad.addColorStop(0.00, 'rgb($, $, $)'.$(r,g,b));
			lingrad.addColorStop(1.00, '#000000');
			this.ctx.fillStyle = lingrad;
			this.ctx.fillRect(0, i, 400, i);
		}
	}
});



