if (!Object.defineProperty) {
	Object.defineProperty = function(p1, p2, p3) {
		if (p3.get) p1.__defineGetter__(p2, p3.get);
		if (p3.set) p1.__defineSetter__(p2, p3.set);
	}
}

if (!Object.getOwnPropertyDescriptor) {
	Object.getOwnPropertyDescriptor = function(object, property) {
		var property_descriptor = {};
		if (object.__lookupGetter__(property)) property_descriptor.get=object.__lookupGetter__(property);
		if (object.__lookupSetter__(property)) property_descriptor.set=object.__lookupSetter__(property);
		if (property_descriptor.get||property_descriptor.set) {
			return(property_descriptor);
		}
	}
}


if (!Element.prototype.innerText) {
	Object.defineProperty(Element.prototype, "innerText", {
		get: function() {
			return(this.textContent);
		},
		set: function(value) {
			this.textContent = value;
		}
	});
}

if (!Element.prototype.text) {
	Object.defineProperty(Element.prototype, "text", {
		get: function() {
			return(this.innerText);
		},
		set: function(value) {
			this.innerText = value;
		}
	});
}

if (!Element.prototype.html) {
	Object.defineProperty(Element.prototype, "html", {
		get: function() {
			return(this.innerHTML);
		},
		set: function(value) {
			this.innerHTML = value;
		}
	});
}

Node.prototype.isDescendantNodeOf = function(node) {
	var thisnode = this;
	do {
		if (thisnode === node) return(true);
	} while(thisnode = thisnode.parentNode);
	return(false);
}

Element.prototype.hasClassName = function(name) {
  return new RegExp("(?:^|\\s+)" + name + "(?:\\s+|$)").test(this.className);
};

Element.prototype.addClassName = function(name) {
  if (!this.hasClassName(name)) {
    this.className = this.className ? [this.className, name].join(' ') : name;
  }
};

Element.prototype.removeClassName = function(name) {
  if (this.hasClassName(name)) {
    var c = this.className;
    this.className = c.replace(new RegExp("(?:^|\\s+)" + name + "(?:\\s+|$)", "g"), "");
  }
};

Element.prototype.contextmenu = false;

/* Google-chrome miscalculates offsetX if target element is a span or a div which is displayed as block */
if (!Event.prototype.offsetX) {
	Object.defineProperty(Event.prototype, "offsetX", {
		get: function() {
			var curleft = 0, obj = this.target;
			if (obj.offsetParent) {
				do {
					curleft += obj.offsetLeft-obj.scrollLeft;
				} while (obj = obj.offsetParent);
			}
			return this.clientX-curleft;
		}
	});
}

if (!Event.prototype.offsetY) {
	Object.defineProperty(Event.prototype, "offsetY", {
		get: function() {
			var curtop = 0, obj = this.target;
			if (obj.offsetParent) {
				do {
					curtop += obj.offsetTop-obj.scrollTop;
				} while (obj = obj.offsetParent);
			}
			return this.clientY-curtop;
		}
	});
}

Array.prototype.remove = function(element) {
	for (var i=0; i<this.length; i++) {
		if (this[i] == element) {
			this.splice(i, 1);
			break;
		}
	}
	return(this);
};

Array.prototype.contains = function(obj) {
  var i = this.length;
  while (i--) {
    if (this[i] === obj) {
      return true;
    }
  }
  return false;
}

if (!Array.prototype.map)
{
  Array.prototype.map = function(fun /*, thisp*/)
  {
    var len = this.length >>> 0;
    if (typeof fun != "function")
      throw new TypeError();

    var res = new Array(len);
    var thisp = arguments[1];
    for (var i = 0; i < len; i++)
    {
      if (i in this)
        res[i] = fun.call(thisp, this[i], i, this);
    }

    return res;
  };
}

if (!Array.prototype.filter)
{
  Array.prototype.filter = function(fun /*, thisp*/)
  {
    var len = this.length >>> 0;
    if (typeof fun != "function")
      throw new TypeError();

    var res = [];
    var thisp = arguments[1];
    for (var i = 0; i < len; i++)
    {
      if (i in this)
      {
        var val = this[i]; // in case fun mutates this
        if (fun.call(thisp, val, i, this))
          res.push(val);
      }
    }

    return res;
  };
}

if (!Array.prototype.forEach)
{
  Array.prototype.forEach = function(fun /*, thisp*/)
  {
    var len = this.length >>> 0;
    if (typeof fun != "function")
      throw new TypeError();

    var thisp = arguments[1];
    for (var i = 0; i < len; i++)
    {
      if (i in this)
        fun.call(thisp, this[i], i, this);
    }
  };
}

Array.prototype.last = function() {
	return(this.length?this[this.length-1]:null);
};

/* http://ejohn.org/blog/fast-javascript-maxmin/ */
Array.prototype.max = function( ){
    return Math.max.apply( Math, this );
};

Array.prototype.min = function( ){
    return Math.min.apply( Math, this );
};
Array.prototype.sum = function(){
	for(var i=0,sum=0;i<this.length;sum+=this[i++]);
	return sum;
};

Number.prototype.pad = function (totalDigits, pdChar) 
{
	var n = this.toString();
	var pd = '';
	pdChar = pdChar == undefined ? '0' : pdChar;
	if (totalDigits > n.length) {
		for (i=0; i < (totalDigits-n.length); i++) {
			pd += pdChar;
		}
	}
	return pd + n;
}

Number.prototype.readableSize = function() {
	var i = 0;
	var bytes = this;
	while(1023 < bytes){
		bytes /= 1024;
		++i;
	};
	return  i ? bytes.toFixed(2) + ["", " Kb", " Mb", " Gb", " Tb"][i] : bytes + " bytes";
}

/**
 * Formats the number according to the 'format' string; adherses to the american number standard where a comma is inserted after every 3 digits.
 *  note: there should be only 1 contiguous number in the format, where a number consists of digits, period, and commas
 *        any other characters can be wrapped around this number, including '$', '%', or text
 *        examples (123456.789):
 *          '0' - (123456) show only digits, no precision
 *          '0.00' - (123456.78) show only digits, 2 precision
 *          '0.0000' - (123456.7890) show only digits, 4 precision
 *          '0,000' - (123,456) show comma and digits, no precision
 *          '0,000.00' - (123,456.78) show comma and digits, 2 precision
 *          '0,0.00' - (123,456.78) shortcut method, show comma and digits, 2 precision
 *
 * @method format
 * @param format {string} the way you would like to format this text
 * @return {string} the formatted number
 * @public
 */
Number.prototype.format = function(format) {
	if (typeof format != 'string') { return(''); }
	var str = new String(this);
	if (format == '') { return(str); }
	var num = this;
	var num2 = this;
	var overflow = false;
	if (format.indexOf('.')==-1) {
		num = Math.round(num);
		format = format.replace(/0+/i, function(s) {
			return(num.pad(s.length));
		});
	} else {


		format = format.replace(/\.0+/i, function(s) {
			if (!(num-Math.floor(num))) {
				return('');
			}

			var precision = s.length-1;
			num = Math.round((num-Math.floor(num))*Math.pow(10, precision))/Math.pow(10, precision);
			if (num==1) overflow = true;
			return((num==0||num==1)?'':new String(num).replace('0.', '.'));
		});

		format = format.replace(/\.#+/i, function(s) {
			var precision = s.length-1;
			num = Math.round((num-Math.floor(num))*Math.pow(10, precision))/Math.pow(10, precision);
			if (num==1) overflow = true;
			str = (num==0||num==1)?'0.0':new String(num);
			str = str.replace('0.', '.');
			for (; str.length-1<precision;) {
				str += '0';
			}
			
			return(str);
		});

		format = format.replace(/0+/i, function(s) {
			if (overflow) num2++;
			return(Math.floor(num2).pad(s.length));
		});


	}
	return(format);
};


/* String extensions */
/* startsWith to check if a string starts with a particular character sequecnce */
String.prototype.startsWith = function(str) {
	return(this.match("^"+str)==str);
}

/* endsWith to check if a string ends with a particular character sequecnce */
String.prototype.endsWith = function(str) {
	return(this.match(str+"$")==str);
}

/* Trim function, trims all leading and trailing spaces */
String.prototype.trim = function() {
	return(this.replace(/^[\s\xA0]+/, "").replace(/[\s\xA0]+$/, ""));
}

String.prototype.$ = function() {
	var str = this;
	for (var i=0; i<arguments.length; i++) {
		str = str.replace("$", arguments[i]);
	}
	return(str);
}

String.prototype.replaceAt=function(index, char) {
	return this.substr(0, index) + char + this.substr(index+char.length);
}

String.prototype.insertAt=function(index, str) {
	return this.substr(0, index) + str + this.substr(index+str.length-1);
}
String.random = function(len) {
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = len;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	return(randomstring);
}

Date.fromUnixTimestamp = function(ts) {
	return(new Date(ts*1000));
}

/*Date.prototype.format = function(f) {
	var Months = new Array(
		{"uk": "January", "hu": "Január"},
		{"uk": "February", "hu": "Február"},
		{"uk": "March", "hu": "Március"},
		{"uk": "April", "hu": "Április"},
		{"uk": "May", "hu": "Május"},
		{"uk": "June", "hu": "Június"},
		{"uk": "July", "hu": "Július"},
		{"uk": "August", "hu": "Augusztus"},
		{"uk": "September", "hu": "Szeptember"},
		{"uk": "October", "hu": "Október"},
		{"uk": "November", "hu": "November"},
		{"uk": "December", "hu": "December"}
	);

	var Days = new Array(
		{"uk": "Sunday", "hu": "Vasárnap"},
		{"uk": "Monday", "hu": "Hétfõ"},
		{"uk": "Tuesday", "hu": "Kedd"},
		{"uk": "Wednesday", "hu": "Szerda"},
		{"uk": "Thursday", "hu": "Csütörtök"},
		{"uk": "Friday", "hu": "Péntek"},
		{"uk": "Saturday", "hu": "Szombat"}
	);

	function pad(s, p) {
		var str = s.toString();
		while (str.length < p) {
			str = "0" + str;
		}
		return(str);
	}
	JDE={}
	JDE.language='uk';
	f = f.replace(/isoDate/g,"YYYY-MM-DD");
	f = f.replace(/isoTime/g,"hh:mm:ss");

	f = f.replace(/Day3/g,Days[this.getDay()][JDE.language].substring(0,3));
	f = f.replace(/Day/g,Days[this.getDay()][JDE.language]);

	f = f.replace(/YYYY/g,this.getFullYear());
	f = f.replace(/MM/g,pad(this.getMonth()+1,2));
	f = f.replace(/DD/g,pad(this.getDate(),2));
	f = f.replace(/D/g,this.getDate());

	f = f.replace(/hh/g,pad(this.getHours(),2));
	f = f.replace(/mm/g,pad(this.getMinutes(),2));
	f = f.replace(/ss/g,pad(this.getSeconds(),2));

	f = f.replace(/Month3/g,Months[this.getMonth()][JDE.language].substring(0,3));
	f = f.replace(/Month/g,Months[this.getMonth()][JDE.language]);

	return(f);
};
*/

/*
 * Date Format 1.2.3
 * (c) 2007-2009 Steven Levithan <stevenlevithan.com>
 * MIT license
 *
 * Includes enhancements by Scott Trenda <scott.trenda.net>
 * and Kris Kowal <cixar.com/~kris.kowal/>
 *
 * Accepts a date, a mask, or a date and a mask.
 * Returns a formatted version of the given date.
 * The date defaults to the current date/time.
 * The mask defaults to dateFormat.masks.default.
 */

var dateFormat = function () {
	var	token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
		timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
		timezoneClip = /[^-+\dA-Z]/g,
		pad = function (val, len) {
			val = String(val);
			len = len || 2;
			while (val.length < len) val = "0" + val;
			return val;
		};

	// Regexes and supporting functions are cached through closure
	return function (date, mask, utc) {
		var dF = dateFormat;

		// You can't provide utc if you skip other args (use the "UTC:" mask prefix)
		if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
			mask = date;
			date = undefined;
		}

		// Passing date through Date applies Date.parse, if necessary
		date = date ? new Date(date) : new Date;
		if (isNaN(date)) throw SyntaxError("invalid date");

		mask = String(dF.masks[mask] || mask || dF.masks["default"]);

		// Allow setting the utc argument via the mask
		if (mask.slice(0, 4) == "UTC:") {
			mask = mask.slice(4);
			utc = true;
		}

		var	_ = utc ? "getUTC" : "get",
			d = date[_ + "Date"](),
			D = date[_ + "Day"](),
			m = date[_ + "Month"](),
			y = date[_ + "FullYear"](),
			H = date[_ + "Hours"](),
			M = date[_ + "Minutes"](),
			s = date[_ + "Seconds"](),
			L = date[_ + "Milliseconds"](),
			o = utc ? 0 : date.getTimezoneOffset(),
			flags = {
				d:    d,
				dd:   pad(d),
				ddd:  dF.i18n.dayNames[D],
				dddd: dF.i18n.dayNames[D + 7],
				m:    m + 1,
				mm:   pad(m + 1),
				mmm:  dF.i18n.monthNames[m],
				mmmm: dF.i18n.monthNames[m + 12],
				yy:   String(y).slice(2),
				yyyy: y,
				h:    H % 12 || 12,
				hh:   pad(H % 12 || 12),
				H:    H,
				HH:   pad(H),
				M:    M,
				MM:   pad(M),
				s:    s,
				ss:   pad(s),
				l:    pad(L, 3),
				L:    pad(L > 99 ? Math.round(L / 10) : L),
				t:    H < 12 ? "a"  : "p",
				tt:   H < 12 ? "am" : "pm",
				T:    H < 12 ? "A"  : "P",
				TT:   H < 12 ? "AM" : "PM",
				Z:    utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
				o:    (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
				S:    ["th", "st", "nd", "rd"][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
			};

		return mask.replace(token, function ($0) {
			return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
		});
	};
}();

// Some common format strings
dateFormat.masks = {
	"default":      "ddd mmm dd yyyy HH:MM:ss",
	shortDate:      "m/d/yy",
	mediumDate:     "mmm d, yyyy",
	longDate:       "mmmm d, yyyy",
	fullDate:       "dddd, mmmm d, yyyy",
	shortTime:      "h:MM TT",
	mediumTime:     "h:MM:ss TT",
	longTime:       "h:MM:ss TT Z",
	isoDate:        "yyyy-mm-dd",
	isoTime:        "HH:MM:ss",
	isoDateTime:    "yyyy-mm-dd'T'HH:MM:ss",
	isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
};

// Internationalization strings
dateFormat.i18n = {
	dayNames: [
		"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat",
		"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
	],
	monthNames: [
		"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
		"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"
	]
};

// For convenience...
Date.prototype.format = function (mask, utc) {
	return dateFormat(this, mask, utc);
};


Date.prototype.getWeek = function() {
        var onejan = new Date(this.getFullYear(),0,1);
        return Math.ceil((((this - onejan) / 86400000) + onejan.getDay()+1)/7);
};

/*Object.prototype.copy = function() {
	var newObj = (this instanceof Array) ? [] : {};
	for (i in this) {
		if (!this.hasOwnProperty(i)) continue;
		if (this[i] && typeof this[i] == "object") {
			newObj[i] = this[i].copy();
		} else newObj[i] = this[i]
	} return newObj;
};

Object.prototype.keys = function() {
	var keys=[];
	for(i in this) if (this.hasOwnProperty(i)) keys.push(i);
	return(keys);
};
*/
Function.prototype.bind = function() {
	var me = this;
	var args = Array.prototype.slice.call(arguments);
	var obj = args.shift();
	return function(event) {
		return me.apply(obj?obj:this, Array.prototype.slice.call(arguments).concat(args));
	}
}

Object.defineProperty(HTMLDivElement.prototype, "offsetRight", {
	get: function() { return(this.parentNode.offsetWidth-this.offsetLeft-this.offsetWidth); }
});

Object.defineProperty(HTMLDivElement.prototype, "offsetBottom", {
	get: function() { return(this.parentNode.offsetHeight-this.offsetTop-this.offsetHeight); }
});

/*http://www.quirksmode.org/js/findpos.html*/
Object.defineProperty(Element.prototype, "positionX", {
	get: function() {
		var obj = this;
		var curleft = curtop = 0;
		if (obj.offsetParent) {
			do {
				curleft += obj.offsetLeft;
				curtop += obj.offsetTop;
			} while (obj = obj.offsetParent);
		}
		return curleft;
	}
});

Object.defineProperty(Element.prototype, "positionY", {
	get: function() {
		var obj = this;
		var curleft = curtop = 0;
		if (obj.offsetParent) {
			do {
				curleft += obj.offsetLeft;
				curtop += obj.offsetTop;
			} while (obj = obj.offsetParent);
		}
		return curtop;
	}
});

Object.copy = function(obj) {
	var newObj = (obj instanceof Array) ? [] : {};
	for (i in obj) {
		if (!obj.hasOwnProperty(i)) continue;
		if (obj[i] && typeof obj[i] == "object") {
			newObj[i] = Object.copy(obj[i]);
		} else newObj[i] = obj[i]
	} return newObj;
};

/* TODO remove */
Event.prototype.hasTarget = function(element) {
	if (this.target===element) return true;
	var obj = this.target;
	if (obj.offsetParent) {
		do {
			if (obj===element) return true;
		} while (obj = obj.offsetParent);
	}
	return false;
};

if (!Object.getOwnPropertyNames) {
	Object.getOwnPropertyNames = function(obj) {
		var propertyNames=[];
		for (var key in obj) {
			if (Object.getOwnPropertyDescriptor(obj, key))
				propertyNames.push(key);
		}
		return(propertyNames);
	}
}

/* CSS3 properties */
if (!CSSStyleDeclaration.prototype.transition) {
	Object.defineProperty(CSSStyleDeclaration.prototype, 'transition', {
		get: function() {

		},
		set: function(value) {
			this.WebkitTransition = value;
			this.MozTransition = value;
			this.OTransition = value;
		}
	});
};

if (!CSSStyleDeclaration.prototype.transform) {
	Object.defineProperty(CSSStyleDeclaration.prototype, 'transform', {
		get: function() {

		},
		set: function(value) {
			this.WebkitTransform = value;
			this.MozTransform = value;
			this.OTransform = value;
		}
	});
};



