var ImageView = Canvas.extend({
	init: function() {
		Canvas.prototype.init.apply(this, arguments);
		this.ctx = this.getContext("2d");
		this.imageOffsetX = 0;
		this.imageOffsetY = 0;
		this.zoom = 1;
	},
	loadImage: function(path) {
		this.image = new Image();
		this.image.onload = function() {
			this.__canvas = new Canvas({'width': this.image.width, 'height': this.image.height});
			this.context = this.__canvas.getContext('2d');
			this.context.drawImage(this.image, 0, 0, this.image.width, this.image.height);
			this.ctx.drawImage(this.__canvas, 0, 0, this.width, this.height, 0, 0, this.width, this.height)
			if (typeof this.onload == 'function') {
				this.onload();
			}
			this.update();
		}.bind(this);
		this.image.src = path;
	},
	mousedown_handler: function(event) {
		this.scrollImage = true;
		this.offsetX = event.offsetX+this.imageOffsetX;
		this.offsetY = event.offsetY+this.imageOffsetY;
	},
	mousemove_handler: function(event) {
		if (this.scrollImage) {
			this.imageOffsetX = this.offsetX-event.offsetX;
			this.imageOffsetY = this.offsetY-event.offsetY;
			if (this.imageOffsetX<0) this.imageOffsetX = 0;
			if (this.imageOffsetY<0) this.imageOffsetY = 0;
			if (this.imageOffsetX>(this.__canvas.width-this.width)) this.imageOffsetX = this.__canvas.width-this.width;
			if (this.imageOffsetY>(this.__canvas.height-this.height)) this.imageOffsetY = this.__canvas.height-this.height;
			this.update();
		}
	},
	mouseup_handler: function(event) {
		this.scrollImage = false;
	},
	update: function() {
		this.ctx.drawImage(this.__canvas, this.imageOffsetX, this.imageOffsetY, this.width*this.zoom, this.height*this.zoom, 0, 0, this.width, this.height);
		if (typeof this.onupdate == 'function') {
			this.onupdate();
		}
	},
	mousewheel_handler: function(event) {
		if (event.wheelDeltaY>0) {
			this.zoom-=0.05;
		} else {
			this.zoom+=0.05;
		}
		this.update();
	},
	effects_flipVertical: function() {
		this.context.scale(1,-1);
		this.context.drawImage(this.image, 0, -this.image.height, this.image.width, this.image.height);
		this.update();
	},
	effects_greyscale: function() {
		var imgPixels = this.context.getImageData(0, 0, this.__canvas.width, this.__canvas.height);

		for(var y=0; y<imgPixels.height; y++){
		     for(var x=0; x<imgPixels.width; x++){
			  var i = (y * 4) * imgPixels.width + x * 4;
			  var avg = (imgPixels.data[i] + imgPixels.data[i + 1] + imgPixels.data[i + 2]) / 3;
			  imgPixels.data[i] = avg;
			  imgPixels.data[i + 1] = avg;
			  imgPixels.data[i + 2] = avg;
		     }
		}
		this.context.putImageData(imgPixels, 0, 0, 0, 0, imgPixels.width, imgPixels.height);
		this.update();
	},
	effects_invert: function() {
		var imgd = this.context.getImageData(0, 0, this.__canvas.width, this.__canvas.height), pix=imgd.data;

		// Loop over each pixel and invthis.update();ert the color.
		for (var i = 0, n = pix.length; i < n; i += 4) {
			pix[i  ] = 255 - pix[i  ]; // red
			pix[i+1] = 255 - pix[i+1]; // green
			pix[i+2] = 255 - pix[i+2]; // blue
			// i+3 is alpha (the fourth element)
		}

		// Draw the ImageData at the given (x,y) coordinates.
		this.context.putImageData(imgd, 0, 0, 0, 0, imgd.width, imgd.height);
		this.update();
	},
	effects_sepia: function() {
		var imgd = this.context.getImageData(0, 0, this.__canvas.width, this.__canvas.height), pix=imgd.data;

		// Loop over each pixel and invert the color.
		for (var i = 0, n = pix.length; i < n; i += 4) {
			var r = pix[i  ];
			var g = pix[i+1];
			var b = pix[i+2];

			pix[i  ] = (r * 0.393 + g * 0.769 + b * 0.189);
			pix[i+1] = (r * 0.349 + g * 0.686 + b * 0.168);
			pix[i+2] = (r * 0.272 + g * 0.534 + b * 0.131);

			if (pix[i  ] < 0) pix[i  ] = 0;
			if (pix[i+1] < 0) pix[i+1] = 0;
			if (pix[i+2] < 0) pix[i+2] = 0;

			if (pix[i  ] > 255) pix[i  ] = 255;
			if (pix[i+1] > 255) pix[i+1] = 255;
			if (pix[i+2] > 255) pix[i+2] = 255;
		}

		// Draw the ImageData at the given (x,y) coordinates.
		this.context.putImageData(imgd, 0, 0, 0, 0, imgd.width, imgd.height);		
		this.update();
	},
	effects_lighten: function() {
		var amount = 1.2;

		var imgd = this.context.getImageData(0, 0, this.__canvas.width, this.__canvas.height), pix=imgd.data;

		for (var i = 0, n = pix.length; i < n; i += 4) {
			var r = pix[i  ];
			var g = pix[i+1];
			var b = pix[i+2];

			if (amount < 0 ||true) {
				pix[i  ] += pix[i  ]*amount;
				pix[i+1] += pix[i+1]*amount;
				pix[i+2] += pix[i+2]*amount;
			} else if (amount > 0) {
				pix[i  ] += (255-pix[i  ])*amount;
				pix[i+1] += (255-pix[i+1])*amount;
				pix[i+2] += (255-pix[i+2])*amount;
			}

			if (pix[i  ] < 0) pix[i  ] = 0;
			if (pix[i+1] < 0) pix[i+1] = 0;
			if (pix[i+2] < 0) pix[i+2] = 0;

			if (pix[i  ] > 255) pix[i  ] = 255;
			if (pix[i+1] > 255) pix[i+1] = 255;
			if (pix[i+2] > 255) pix[i+2] = 255;
		}

		// Draw the ImageData at the given (x,y) coordinates.
		this.context.putImageData(imgd, 0, 0, 0, 0, imgd.width, imgd.height);
		this.update();
	}
});

