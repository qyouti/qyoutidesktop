<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<!--
	All rights reserved
-->
<html>
	<head>
		<title>Javascript Desktop Environment</title>
		<meta name="robots" content="noindex">
		<meta name="author" content="http://www.jdesktop.com">
		<meta name="description" content="jdesktop 0.1, all rights reserved, 2009">
		<meta name="keywords" content="javascript, web, desktop, environment, application" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<!-- applications' stylsheets will be loaded dynamically-->
		<link href="css/base.css" rel="stylesheet" type="text/css" />
		<link href="css/icons.css" rel="stylesheet" type="text/css" />
		<link href="css/button.css" rel="stylesheet" type="text/css" />
		<link href="css/textbox.css" rel="stylesheet" type="text/css" />
		<link href="css/progressbar.css" rel="stylesheet" type="text/css" />
		<link href="css/calendar.css" rel="stylesheet" type="text/css" />
		<link href="css/filemenu.css" rel="stylesheet" type="text/css" />
		<link href="css/iconmenu.css" rel="stylesheet" type="text/css" />
		<link href="css/dropdownmenu.css" rel="stylesheet" type="text/css" />
		<link href="css/application.css" rel="stylesheet" type="text/css" />
		
		<!-- Core Javascript extensions -->
		<script type="text/javascript" src="inc/base.js"></script>
		<script type="text/javascript" src="inc/class.js"></script>
		<script type="text/javascript" src="inc/ajax.js"></script>
		<script type="text/javascript" src="inc/location.js"></script>
		<script type="text/javascript" src="inc/localstorage.js"></script>
		<script type="text/javascript" src="inc/environment.js"></script>
		<script type="text/javascript" src="inc/domextend.js"></script>
		<script type="text/javascript" src="inc/timer.js"></script>

		<!-- Controls -->
		<script type="text/javascript" src="inc/div.js"></script>
		<script type="text/javascript" src="inc/button.js"></script>
		<script type="text/javascript" src="inc/textbox.js"></script>
		<script type="text/javascript" src="inc/checkbox.js"></script>
		<script type="text/javascript" src="inc/label.js"></script>
		<script type="text/javascript" src="inc/legend.js"></script>
		<script type="text/javascript" src="inc/fieldset.js"></script>
		<script type="text/javascript" src="inc/progressbar.js"></script>
		<script type="text/javascript" src="inc/calendar.js"></script>
		<script type="text/javascript" src="inc/datebutton.js"></script>
		<script type="text/javascript" src="inc/canvas.js"></script>
		<script type="text/javascript" src="inc/highlightarea.js"></script>
		<script type="text/javascript" src="inc/imageview.js"></script>
		<script type="text/javascript" src="inc/dropdownmenu.js"></script>
		<script type="text/javascript" src="inc/filemenu.js"></script>
		<script type="text/javascript" src="inc/iconmenu.js"></script>
		<script type="text/javascript" src="inc/application.js"></script>
	</head>
	<body oncontextmenu="javascript: return false;" onload="if (Location.getValue('loadapp')) new Ajax().load(Location.getValue('loadapp'));">
		<iframe id="download" src="" style="display: none;"></iframe>
		<iframe id="upload" src="" style="display: none;" name="upload_iframe"></iframe><?php
			function endsWith($str, $sub) {
				return(substr($str, strlen($str)-strlen($sub))===$sub);
			}

			$files = scandir("./aps");

			foreach ($files as $file) {
				if (endsWith($file, ".js")) {
					print "\t\t\t<div class=\"appstarticon\" onclick=\"window.open('loadapp.html?loadapp=aps/$file', 'mywindow', 'menubar=0, resizable=1, width=640, height=480');\">$file</div>\n";
				}
			}
		?>
	</body>
</html>
