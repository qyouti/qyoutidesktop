/*

   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package org.apache.batik.apps.svgbrowser;

import org.w3c.dom.Element;

/**
 * Provides the information to control the NodePickerPanel behaviour.
 *
 * @version $Id: NodePickerController.java 985243 2010-08-13 15:30:25Z helder $
 */
public interface NodePickerController {

    /**
     * Whether NodePickerPanel is should be editable.
     */
    boolean isEditable();

    /**
     * Whether the given element can be edited with the NodePickerPanel.
     *
     * @param el
     *            The given element
     * @return True if the given element can be edited by a NodePickerPanel
     */
    boolean canEdit(Element el);
}
