/*

   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package org.apache.batik.apps.rasterizer;

import java.io.IOException;
import java.io.InputStream;

/**
 * Interface used to handle both Files and URLs in the
 * <code>SVGConverter</code>
 *
 * @author <a href="mailto:vhardy@apache.org">Vincent Hardy</a>
 * @version $Id: SVGConverterSource.java 1372129 2012-08-12 15:31:50Z helder $
 */
public interface SVGConverterSource {
    /**
     * Returns the name of the source. That would be the
     * name for a File or URL
     */
    String getName();

    /**
     * Gets a <code>TranscoderInput</code> for that source
     */
    InputStream openStream() throws IOException;

    /**
     * Checks if same as source described by srcStr
     */
    boolean isSameAs(String srcStr);

    /**
     * Checks if source can be read
     */
    boolean isReadable();

    /**
     * Returns a URI string corresponding to this source
     */
    String getURI();
}

