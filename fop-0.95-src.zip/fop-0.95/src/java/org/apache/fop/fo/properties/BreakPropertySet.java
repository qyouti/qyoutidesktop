/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* $Id: BreakPropertySet.java 669118 2008-06-18 09:02:45Z jeremias $ */

package org.apache.fop.fo.properties;

/**
 * Defines property access methods for the break-before and break-after properties.
 */
public interface BreakPropertySet {

    /** @return the "break-after" property. */
    int getBreakAfter();

    /** @return the "break-before" property. */
    int getBreakBefore();
    
}
