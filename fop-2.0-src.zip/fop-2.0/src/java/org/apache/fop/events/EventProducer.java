/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* $Id: EventProducer.java 647742 2008-04-14 11:53:29Z jeremias $ */

package org.apache.fop.events;

/**
 * This is a marker interface which all event producer interfaces need to extend. These interfaces
 * must agree to the following convention:
 * <ul>
 *   <li>The first parameter of each method must be: <code>Object source</code>
 * </ul>
 */
public interface EventProducer {

}
